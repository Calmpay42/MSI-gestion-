'use strict';
/* Règles métier communes. Les références RG-… renvoient au cahier des charges MSI. */
const crypto = require('crypto');
const { pad, jourLocal, maintenant, jourDe, bornesJour, joursEntre, aammjj, norm, chiffres, err, texte, entier, date } = require('./outils');

const AVANCE = 'Avance du patient';
const MODES = ['Espèces', 'Orange Money', 'MTN MoMo', 'Moov Money', 'Wave', 'Carte bancaire', 'Chèque', 'Virement', AVANCE];
const COUPURES = [
  { k: 'b10000', v: 10000, l: 'Billets de 10 000' }, { k: 'b5000', v: 5000, l: 'Billets de 5 000' }, { k: 'b2000', v: 2000, l: 'Billets de 2 000' },
  { k: 'b1000', v: 1000, l: 'Billets de 1 000' }, { k: 'b500', v: 500, l: 'Billets de 500' }, { k: 'p500', v: 500, l: 'Pièces de 500' },
  { k: 'p250', v: 250, l: 'Pièces de 250' }, { k: 'p200', v: 200, l: 'Pièces de 200' }, { k: 'p100', v: 100, l: 'Pièces de 100' },
  { k: 'p50', v: 50, l: 'Pièces de 50' }, { k: 'p25', v: 25, l: 'Pièces de 25' }, { k: 'p10', v: 10, l: 'Pièces de 10' }, { k: 'p5', v: 5, l: 'Pièces de 5' }
];
const TYPES_PASSAGE = { consultation: 'Consultation', controle: 'Contrôle', urgence: 'Urgence', soins: 'Soins', labo: 'Laboratoire externe', pharma: 'Pharmacie externe', comptoir: 'Vente comptoir', reprise: 'Reprise de l’existant', hospitalisation: 'Hospitalisation' };
const CATEGORIES_DEPENSES = [
  { code: '60', l: '60 Achats et variations de stocks' }, { code: '61', l: '61 Transports' }, { code: '62', l: '62 Services extérieurs A' },
  { code: '63', l: '63 Services extérieurs B' }, { code: '64', l: '64 Impôts et taxes' }, { code: '65', l: '65 Autres charges' }, { code: '66', l: '66 Charges de personnel' }
];
const PARAMS_DEFAUT = {
  plafond_remise: '10', delai_controle: '15', seuil_ajustement: '20000', inactivite_min: '30',
  vacation_debut: '8', vacation_fin: '18', acte_urgence: 'CS-URG', formation: '0',
  /* v1.8 : paie. Valeurs indicatives, à faire confirmer par l'expert-comptable avant la première paie réelle. */
  rh_taux_cnps: '6.3', rh_plafond_cnps: '1647315', rh_cmu: '500', rh_cnps_employeur: '',
  raison: 'Maison de Santé Innov’Care', forme: 'SARL au capital de 8 000 000 FCFA', adresse: 'Bingerville, quartier Mamadou Coulibaly',
  rccm: 'RCCM CI-BJ-03-2023-M-25490', ncc: 'N° CC 2244030 F', telephone: '+225 07 49 81 57 63', slogan: 'Ensemble pour votre bien-être.'
};
const NUMERIQUES = ['plafond_remise', 'delai_controle', 'seuil_ajustement', 'inactivite_min', 'vacation_debut', 'vacation_fin', 'formation', 'rh_taux_cnps', 'rh_plafond_cnps', 'rh_cmu'];

function params(db) {
  const p = { ...PARAMS_DEFAUT };
  for (const r of db.prepare('SELECT cle, valeur FROM parametres').all()) p[r.cle] = r.valeur;
  for (const k of NUMERIQUES) p[k] = Number(p[k]);
  return p;
}
const ecrireParam = (db, cle, valeur) => db.prepare('INSERT INTO parametres(cle, valeur) VALUES (?, ?) ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur').run(cle, String(valeur));
function vacation(p, d = new Date()) {
  const h = d.getHours(), a = p.vacation_debut, b = p.vacation_fin;
  return h >= a && h < b ? `Permanence de jour (${pad(a, 2)} h–${pad(b, 2)} h)` : `Garde (${pad(b, 2)} h–${pad(a, 2)} h)`;
}

/* Numérotation continue : le compteur avance dans la même transaction que l'écriture (RG-CAI-4). */
const suivant = (db, nom) => db.prepare('INSERT INTO compteurs(nom, valeur) VALUES (?, 1) ON CONFLICT(nom) DO UPDATE SET valeur = valeur + 1 RETURNING valeur').get(nom).valeur;

/* Journal d'audit chaîné : chaque ligne scelle la précédente (verrou 6). */
const hashAudit = (prev, r) => crypto.createHash('sha256')
  .update([prev, r.t, r.utilisateur_id, r.login, r.poste, r.action, r.detail, r.avant, r.apres, r.niveau].map(x => (x == null ? '' : String(x))).join('\u241f'))
  .digest('hex');
function journal(db, u, poste, action, detail, o = {}) {
  const prev = db.prepare('SELECT hash FROM audit ORDER BY id DESC LIMIT 1').get();
  const r = {
    t: maintenant(), utilisateur_id: u ? u.id : null, login: u ? u.login : 'système', poste, action, detail: detail || null,
    avant: o.avant === undefined ? null : JSON.stringify(o.avant), apres: o.apres === undefined ? null : JSON.stringify(o.apres), niveau: o.niveau || null
  };
  r.hash = hashAudit(prev ? prev.hash : 'MSI', r);
  db.prepare('INSERT INTO audit(t, utilisateur_id, login, poste, action, detail, avant, apres, niveau, hash) VALUES (@t,@utilisateur_id,@login,@poste,@action,@detail,@avant,@apres,@niveau,@hash)').run(r);
}
function verifierJournal(db) {
  let prev = 'MSI', n = 0;
  for (const r of db.prepare('SELECT * FROM audit ORDER BY id').all()) {
    if (hashAudit(prev, r) !== r.hash) return { ok: false, lignes: n, rupture: r.id };
    prev = r.hash; n++;
  }
  return { ok: true, lignes: n };
}

/* Patients et couverture */
const COLS_PATIENT = 'id, ipp, nom, prenoms, sexe, naissance, telephone, commune, contact, assureur_id, num_assure, taux, validite, provisoire, fusionne_dans, cree_le';
const patient = (db, id) => (id ? db.prepare(`SELECT ${COLS_PATIENT} FROM patients WHERE id = ?`).get(id) || null : null);
const nomPatient = p => (p ? `${p.nom} ${p.prenoms}` : 'Client comptoir');
const passage = (db, id) => db.prepare('SELECT * FROM passages WHERE id = ?').get(id) || null;

function couverture(db, p, jour = jourLocal()) {
  if (!p || !p.assureur_id) return { etat: 'aucune' };
  const a = db.prepare('SELECT * FROM assureurs WHERE id = ?').get(p.assureur_id);
  if (!a) return { etat: 'aucune' };
  if (!a.actif) return { etat: 'inactive', assureur: a };
  if (!p.validite || p.validite < jour) return { etat: 'expiree', assureur: a };
  return { etat: 'valide', assureur: a, taux: p.taux || 0 };
}
/* RG-ASS-1 et RG-ACC-3 : part assureur seulement avec des droits valides à la date du passage ET un accord. */
function couvertureEffective(db, v) {
  if (!v || !v.patient_id || !v.accord) return null;
  const c = couverture(db, patient(db, v.patient_id), jourDe(v.cree_le));
  return c.etat === 'valide' ? { assureur_id: c.assureur.id, nom: c.assureur.nom, niveau: c.assureur.niveau, taux: c.taux } : null;
}
function montants(b) {
  const total = b.prix * b.quantite;
  const pa = b.taux ? Math.round(total * b.taux / 100) : 0;
  const pp = total - pa;
  const remise = Math.round(pp * (b.remise_pct || 0) / 100);
  return { total, pa, pp, remise, net: pp - remise };
}
function impaye(db, pid) {
  const [debut] = bornesJour(jourLocal());
  return db.prepare('SELECT * FROM bons WHERE patient_id = ? AND paye = 0 AND annule = 0 AND cree_le < ?').all(pid, debut).reduce((s, b) => s + montants(b).net, 0);
}
/* Solde d'avance du patient : dépôts − utilisations − remboursements. */
const soldeAvance = (db, pid) => db.prepare("SELECT COALESCE(SUM(CASE type WHEN 'depot' THEN montant ELSE -montant END), 0) s FROM avances WHERE patient_id = ?").get(pid).s;
function enrichirPatient(db, p) {
  const c = couverture(db, p);
  return { ...p, couverture: { etat: c.etat, assureur: c.assureur ? c.assureur.nom : null, niveau: c.assureur ? c.assureur.niveau : null }, impaye: impaye(db, p.id), avance: soldeAvance(db, p.id) };
}
function dateSaisie(q) {
  const m = String(q || '').trim().match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/);
  if (m) return `${m[3]}-${pad(m[2], 2)}-${pad(m[1], 2)}`;
  return /^\d{4}-\d{2}-\d{2}$/.test(String(q || '').trim()) ? String(q).trim() : null;
}
function rechercherPatients(db, q) {
  const s = norm(q), d = chiffres(q), dn = dateSaisie(q);
  const rows = !s
    ? db.prepare(`SELECT ${COLS_PATIENT} FROM patients WHERE fusionne_dans IS NULL ORDER BY id DESC LIMIT 20`).all()
    : db.prepare(`SELECT ${COLS_PATIENT} FROM patients WHERE fusionne_dans IS NULL AND (recherche LIKE @like OR ipp LIKE @ipp OR (@tel <> '' AND tel_chiffres LIKE @telLike) OR naissance = @dn) ORDER BY nom, prenoms LIMIT 30`)
      .all({ like: '%' + s + '%', ipp: '%' + String(q).trim().toUpperCase() + '%', tel: d.length >= 4 ? d : '', telLike: '%' + d + '%', dn: dn || '#' });
  return rows.map(p => enrichirPatient(db, p));
}
const cleRecherche = (nom, prenoms) => norm(nom + ' ' + prenoms) + ' | ' + norm(prenoms + ' ' + nom);

function lireCouverture(db, d) {
  if (!d.assureur_id) return { assureur_id: null, num_assure: null, taux: null, validite: null };
  const a = db.prepare('SELECT * FROM assureurs WHERE id = ?').get(Number(d.assureur_id));
  if (!a) throw err(400, 'Assureur inconnu.');
  return {
    assureur_id: a.id,
    num_assure: texte(d.num_assure, { label: 'N° d’assuré', max: 60, requis: true }),
    taux: entier(d.taux, { label: 'Taux de couverture', min: 0, max: 100 }),
    validite: date(d.validite, { label: 'Fin de validité des droits' })
  };
}
/* Prénoms : majuscule initiale à chaque prénom, y compris après un trait d'union ou une apostrophe (Marie-Josée, N’Guessan). */
const casse = s => (s ? String(s).toLocaleLowerCase('fr-FR').replace(/(^|[\s\-’'])(\p{L})/gu, (m, a, l) => a + l.toLocaleUpperCase('fr-FR')) : s);
/* Téléphone ivoirien : dix chiffres groupés par deux, indicatif +225 conservé ; tout autre format est gardé tel quel. */
function formaterTelephone(t) {
  if (!t) return t;
  const d = chiffres(t), deux = x => x.match(/.{1,2}/g).join(' ');
  if (d.length === 10) return deux(d);
  if (d.length === 13 && d.startsWith('225')) return '+225 ' + deux(d.slice(3));
  if (d.length === 15 && d.startsWith('00225')) return '+225 ' + deux(d.slice(5));
  return t;
}
function lireIdentite(d, provisoire) {
  const nom = texte(d.nom, { label: 'Nom', max: 80, requis: !provisoire }).toUpperCase() || 'INCONNU';
  const prenoms = casse(texte(d.prenoms, { label: 'Prénoms', max: 120, requis: !provisoire })) || ('Urgence ' + new Date().toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }));
  const sexe = ['F', 'M'].includes(d.sexe) ? d.sexe : null;
  if (!sexe && !provisoire) throw err(400, 'Sexe : champ obligatoire.');
  const naissance = date(d.naissance, { label: 'Date de naissance', requis: !provisoire });
  if (naissance && naissance > jourLocal()) throw err(400, 'Date de naissance dans le futur.');
  const telephone = formaterTelephone(texte(d.telephone, { label: 'Téléphone', max: 30, requis: !provisoire }));
  if (telephone && chiffres(telephone).length < 8) throw err(400, 'Téléphone : 8 chiffres au moins.');
  return { nom, prenoms, sexe, naissance, telephone, commune: texte(d.commune, { label: 'Commune', max: 80 }), contact: texte(d.contact, { label: 'Personne à prévenir', max: 120 }) };
}
/* RG-ACC-1 : doublon probable si mêmes nom et prénoms, ou même téléphone et même date de naissance. */
function chercherDoublon(db, id, { nom, prenoms, naissance, telephone }, exclure) {
  const tel = chiffres(telephone);
  return db.prepare(`SELECT ${COLS_PATIENT} FROM patients WHERE fusionne_dans IS NULL AND id <> @ex AND (recherche LIKE @r OR (@tel <> '' AND tel_chiffres = @tel AND naissance = @dn)) LIMIT 1`)
    .get({ r: norm(nom + ' ' + prenoms) + ' |%', tel, dn: naissance || '#', ex: exclure || 0 }) || null;
}
function creerPatient(db, u, d) {
  const provisoire = !!d.provisoire;
  const idt = lireIdentite(d, provisoire), cov = lireCouverture(db, d);
  if (!d.forcer && !provisoire) {
    const dup = chercherDoublon(db, null, idt);
    if (dup) throw err(409, 'Doublon probable : vérifiez avant de créer un nouveau dossier.', { doublon: enrichirPatient(db, dup) });
  }
  return db.transaction(() => {
    const ipp = 'P-' + pad(suivant(db, 'ipp'), 6);
    const r = db.prepare(`INSERT INTO patients (ipp, nom, prenoms, recherche, sexe, naissance, telephone, tel_chiffres, commune, contact, assureur_id, num_assure, taux, validite, provisoire, cree_le, cree_par)
      VALUES (@ipp,@nom,@prenoms,@recherche,@sexe,@naissance,@telephone,@tel,@commune,@contact,@assureur_id,@num_assure,@taux,@validite,@provisoire,@cree_le,@cree_par)`)
      .run({ ipp, ...idt, ...cov, recherche: cleRecherche(idt.nom, idt.prenoms), tel: chiffres(idt.telephone), provisoire: provisoire ? 1 : 0, cree_le: maintenant(), cree_par: u.id });
    journal(db, u, 'Accueil', 'Création de dossier', `${ipp} ${idt.nom} ${idt.prenoms}${d.forcer ? ', malgré un doublon probable signalé' : ''}${provisoire ? ', identité provisoire (urgence)' : ''}`, { niveau: d.forcer || provisoire ? 'alerte' : null });
    return { id: r.lastInsertRowid, ipp };
  })();
}
function modifierPatient(db, u, id, d) {
  const avant = patient(db, id);
  if (!avant || avant.fusionne_dans) throw err(404, 'Patient introuvable.');
  const provisoire = d.provisoire === undefined ? !!avant.provisoire : !!d.provisoire;
  const idt = lireIdentite(d, provisoire), cov = lireCouverture(db, d);
  db.transaction(() => {
    db.prepare(`UPDATE patients SET nom=@nom, prenoms=@prenoms, recherche=@recherche, sexe=@sexe, naissance=@naissance, telephone=@telephone, tel_chiffres=@tel, commune=@commune, contact=@contact,
      assureur_id=@assureur_id, num_assure=@num_assure, taux=@taux, validite=@validite, provisoire=@provisoire WHERE id=@id`)
      .run({ id, ...idt, ...cov, recherche: cleRecherche(idt.nom, idt.prenoms), tel: chiffres(idt.telephone), provisoire: provisoire ? 1 : 0 });
    const apres = patient(db, id);
    const diff = Object.keys(apres).filter(k => String(apres[k]) !== String(avant[k]));
    journal(db, u, 'Accueil', 'Modification de dossier', `${avant.ipp} ${nomPatient(apres)} : ${diff.join(', ') || 'aucun changement'}`,
      { avant: Object.fromEntries(diff.map(k => [k, avant[k]])), apres: Object.fromEntries(diff.map(k => [k, apres[k]])) });
  })();
}
/* RG-ACC-1 : fusion réservée à la direction, tracée ; le doublon n'est jamais supprimé. */
function fusionnerPatients(db, u, id, versId) {
  const a = patient(db, id), b = patient(db, versId);
  if (!a || !b || a.id === b.id) throw err(400, 'Choisissez deux dossiers différents.');
  if (a.fusionne_dans || b.fusionne_dans) throw err(409, 'Un des dossiers est déjà fusionné.');
  db.transaction(() => {
    const n = db.prepare('UPDATE passages SET patient_id = ? WHERE patient_id = ?').run(b.id, a.id).changes;
    db.prepare('UPDATE bons SET patient_id = ? WHERE patient_id = ?').run(b.id, a.id);
    db.prepare('UPDATE ordonnances SET patient_id = ? WHERE patient_id = ?').run(b.id, a.id);
    for (const t of ['consultations', 'documents', 'rdv', 'pieces', 'avances', 'factures', 'resultats']) db.prepare(`UPDATE ${t} SET patient_id = ? WHERE patient_id = ?`).run(b.id, a.id);
    db.prepare('UPDATE patients SET fusionne_dans = ? WHERE id = ?').run(b.id, a.id);
    journal(db, u, 'Direction', 'Fusion de doublons', `${a.ipp} ${nomPatient(a)} fusionné dans ${b.ipp} ${nomPatient(b)} (${n} passage(s) rattaché(s))`, { niveau: 'alerte' });
  })();
}

/* Tarifs : le prix vient toujours du référentiel, selon la catégorie du patient (RG-CAI-2, RG-PHA-2). */
const prixNiveau = (ref, niveau) => ref['prix_' + niveau];
function creerBon(db, u, v, item, quantite, origine) {
  if (item.ref.a_valider && !params(db).formation) {
    throw err(409, `Tarif non validé : « ${item.ref.libelle || item.ref.nom} ». La direction doit le vérifier dans Paramétrage avant toute facturation.`);
  }
  const cov = couvertureEffective(db, v), niveau = cov ? cov.niveau : 'non';
  const prix = item.gratuit ? 0 : prixNiveau(item.ref, niveau);
  return db.prepare(`INSERT INTO bons (passage_id, patient_id, nature, code, libelle, quantite, prix, taux, assureur_id, urgent, gratuit, paye, origine, acte_id, produit_id, specialite, ordonnance_id, cree_le, cree_par)
    VALUES (@passage_id,@patient_id,@nature,@code,@libelle,@quantite,@prix,@taux,@assureur_id,@urgent,@gratuit,@paye,@origine,@acte_id,@produit_id,@specialite,@ordonnance_id,@cree_le,@cree_par)`).run({
    passage_id: v.id, patient_id: v.patient_id || null, nature: item.nature, code: item.ref.code, libelle: item.libelle || item.ref.libelle || item.ref.nom,
    quantite, prix, taux: cov && prix > 0 ? cov.taux : 0, assureur_id: cov && prix > 0 ? cov.assureur_id : null, urgent: v.urgent ? 1 : 0,
    gratuit: item.gratuit ? 1 : 0, paye: item.gratuit ? 1 : 0, origine, acte_id: item.nature === 'acte' ? item.ref.id : null,
    produit_id: item.nature === 'produit' ? item.ref.id : null, specialite: item.nature === 'acte' ? item.ref.specialite || null : null,
    ordonnance_id: item.ordonnance_id || null, cree_le: maintenant(), cree_par: u.id
  }).lastInsertRowid;
}
function recalculerPassage(db, v) {
  const cov = couvertureEffective(db, v), niveau = cov ? cov.niveau : 'non';
  const maj = db.prepare('UPDATE bons SET prix = ?, taux = ?, assureur_id = ? WHERE id = ?');
  for (const b of db.prepare("SELECT * FROM bons WHERE passage_id = ? AND paye = 0 AND annule = 0 AND demande_id IS NULL AND gratuit = 0 AND nature <> 'reprise'").all(v.id)) {
    const ref = b.acte_id ? db.prepare('SELECT * FROM actes WHERE id = ?').get(b.acte_id) : b.produit_id ? db.prepare('SELECT * FROM produits WHERE id = ?').get(b.produit_id) : null;
    const prix = ref ? prixNiveau(ref, niveau) : b.prix;
    maj.run(prix, cov && prix > 0 ? cov.taux : 0, cov && prix > 0 ? cov.assureur_id : null, b.id);
  }
}
function derniereConsultationPayee(db, pid, specialite) {
  return db.prepare(`SELECT b.* FROM bons b JOIN actes a ON a.id = b.acte_id WHERE b.patient_id = ? AND a.famille = 'Consultation' AND b.specialite = ?
    AND b.paye = 1 AND b.gratuit = 0 AND b.annule = 0 AND b.prix > 0 ORDER BY b.cree_le DESC LIMIT 1`).get(pid, specialite) || null;
}
function fichePatient(db, id) {
  const p = patient(db, id);
  if (!p) throw err(404, 'Patient introuvable.');
  const vs = db.prepare('SELECT * FROM passages WHERE patient_id = ? ORDER BY cree_le DESC LIMIT 30').all(id);
  const bons = vs.length ? db.prepare(`SELECT * FROM bons WHERE passage_id IN (${vs.map(() => '?').join(',')})`).all(...vs.map(v => v.id)) : [];
  const pm = params(db), controles = {};
  for (const { specialite } of db.prepare("SELECT DISTINCT specialite FROM actes WHERE famille = 'Consultation' AND specialite IS NOT NULL").all()) {
    const last = derniereConsultationPayee(db, id, specialite);
    if (last) { const j = joursEntre(jourDe(last.cree_le), jourLocal()); controles[specialite] = { jours: j, gratuit: j <= pm.delai_controle }; }
  }
  return {
    patient: enrichirPatient(db, p), controles, delai_controle: pm.delai_controle,
    fusionne_dans: p.fusionne_dans ? patient(db, p.fusionne_dans) : null,
    passages: vs.map(v => ({ ...v, bons: bons.filter(b => b.passage_id === v.id).map(b => ({ ...b, ...montants(b) })) }))
  };
}

/* Passages (ACC-06, ACC-07, CAI-12) */
function ouvrirPassage(db, u, d, interne) {
  const type = String(d.type || '');
  /* Le passage « hospitalisation » ne s'ouvre que par l'admission (chambre, référent, infirmiers), jamais directement à l'accueil. */
  if (!['consultation', 'controle', 'urgence', 'soins', 'labo', 'pharma'].includes(type) && !(type === 'hospitalisation' && interne === 'hospitalisation')) throw err(400, 'Type de passage inconnu.');
  const p = patient(db, Number(d.patient_id));
  if (!p || p.fusionne_dans) throw err(404, 'Patient introuvable ou fusionné.');
  const c = couverture(db, p), pm = params(db);
  const accord = texte(d.accord, { label: 'N° d’accord', max: 60 });
  let acte = null;
  if (type === 'consultation' || type === 'controle') {
    acte = db.prepare("SELECT * FROM actes WHERE id = ? AND famille = 'Consultation' AND actif = 1").get(Number(d.acte_id));
    if (!acte) throw err(400, 'Choisissez la consultation (spécialité).');
  }
  if (type === 'urgence') {
    acte = db.prepare('SELECT * FROM actes WHERE code = ? AND actif = 1').get(pm.acte_urgence);
    if (!acte) throw err(400, `Acte d’urgence non paramétré (code ${pm.acte_urgence}).`);
  }
  /* Passage identique déjà ouvert aujourd'hui (double saisie, double clic) : second bon seulement sur confirmation, tracée. */
  let deja = null;
  if (acte) {
    deja = db.prepare(`SELECT v.numero, v.cree_le, b.libelle, b.paye FROM passages v JOIN bons b ON b.passage_id = v.id
      WHERE v.patient_id = ? AND v.type = ? AND b.acte_id = ? AND b.annule = 0 ORDER BY v.id DESC LIMIT 5`).all(p.id, type, acte.id)
      .find(x => jourDe(x.cree_le) === jourLocal()) || null;
    if (deja && !d.forcer) throw err(409, `Le passage ${deja.numero} est déjà ouvert aujourd’hui pour ce patient.`, { deja: { ...deja, paye: !!deja.paye } });
  }
  /* v1.6 : médecin choisi dès l'accueil (facultatif) et motif de consultation, repris par l'infirmerie et par la consultation. */
  const motifPassage = texte(d.motif, { label: 'Motif de consultation', max: 160 }) || null;
  let medecinChoisi = null;
  if (d.medecin_id) {
    const m = db.prepare('SELECT id, roles, specialites, actif FROM utilisateurs WHERE id = ?').get(Number(d.medecin_id));
    if (!m || !m.actif || !String(m.roles).split(',').includes('medecin')) throw err(400, 'Médecin introuvable.');
    const spm = String(m.specialites || '').split(',').map(x => x.trim()).filter(Boolean), spa = acte && acte.specialite;
    if (type !== 'urgence' && spa && spm.length && !spm.includes(spa)) throw err(400, `Ce médecin ne consulte pas en ${spa.toLowerCase()}.`);
    medecinChoisi = m.id;
  }
  return db.transaction(() => {
    const now = new Date(), avecAccord = c.etat === 'valide' && accord;
    const numero = 'V-' + aammjj(now) + '-' + pad(suivant(db, 'passage:' + aammjj(now)), 3);
    const id = db.prepare('INSERT INTO passages(numero, patient_id, type, specialite, accord, accord_le, urgent, cree_le, cree_par, medecin_id, motif) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .run(numero, p.id, type, acte && acte.famille === 'Consultation' ? acte.specialite : null, avecAccord ? accord : null, avecAccord ? maintenant() : null, type === 'urgence' ? 1 : 0, maintenant(), u.id, medecinChoisi, motifPassage).lastInsertRowid;
    const v = passage(db, id);
    let gratuit = false;
    if (acte) {
      let libelle = acte.libelle;
      if (type === 'controle') {
        const last = derniereConsultationPayee(db, p.id, acte.specialite);
        gratuit = !!last && joursEntre(jourDe(last.cree_le), jourLocal()) <= pm.delai_controle;
        libelle = 'Contrôle ' + String(acte.specialite).toLowerCase() + (gratuit ? ', gratuit' : ', hors délai');
      }
      creerBon(db, u, v, { nature: 'acte', ref: acte, libelle, gratuit }, 1, 'accueil');
    }
    journal(db, u, 'Accueil', 'Ouverture de passage', `${numero} ${nomPatient(p)}${deja ? ` (malgré ${deja.numero} déjà ouvert)` : ''} : ${TYPES_PASSAGE[type].toLowerCase()}${v.specialite ? ', ' + v.specialite.toLowerCase() : ''}${v.accord ? ', accord ' + v.accord : ''}${gratuit ? ', contrôle gratuit' : ''}`,
      { niveau: type === 'urgence' || deja ? 'alerte' : null });
    return { id, numero, gratuit, sans_accord: c.etat === 'valide' && !avecAccord, non_couvert: ['expiree', 'inactive'].includes(c.etat) ? c.etat : null };
  })();
}
/* Annulation d'un passage ouvert par erreur (doublon, mauvais acte, patient reparti sans être vu) :
   ses bons sont annulés, jamais supprimés ; refusée dès qu'un acte est payé, délivré ou commencé. Tracée, signalée à la direction. */
function annulerPassage(db, u, passageId, motifSaisi, poste, direction) {
  const v = passage(db, passageId);
  if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
  if (v.type === 'reprise') throw err(409, 'Un solde repris de l’ancien logiciel ne s’annule pas ici : voyez la direction.');
  const motif = texte(motifSaisi, { label: 'Motif de l’annulation', max: 200, requis: true });
  if (!direction && jourDe(v.cree_le) !== jourLocal()) throw err(403, 'Seule la direction peut annuler un passage d’un jour précédent.');
  const actifs = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0').all(v.id);
  if (!actifs.length) throw err(409, 'Ce passage ne comporte aucun bon à annuler.');
  if (actifs.some(b => b.paye)) throw err(409, 'Un acte de ce passage est déjà payé : faites annuler le reçu (avoir validé par la direction).');
  if (actifs.some(b => b.delivre)) throw err(409, 'Un produit ou un acte de ce passage a déjà été délivré : annulation impossible.');
  if (actifs.some(b => b.demande_id)) throw err(409, 'Une demande de remise est en attente pour ce passage : attendez la décision de la direction.');
  if (db.prepare('SELECT 1 FROM consultations WHERE passage_id = ? LIMIT 1').get(v.id)) throw err(409, 'La consultation a commencé : le passage ne peut plus être annulé.');
  if (db.prepare('SELECT 1 FROM resultats WHERE passage_id = ? LIMIT 1').get(v.id)) throw err(409, 'Des résultats de laboratoire sont saisis : le passage ne peut plus être annulé.');
  if (db.prepare('SELECT 1 FROM factures WHERE passage_id = ? LIMIT 1').get(v.id)) throw err(409, 'Une facture a été émise pour ce passage : annulation impossible.');
  return db.transaction(() => {
    const n = db.prepare('UPDATE bons SET annule = 1 WHERE passage_id = ? AND annule = 0 AND paye = 0 AND delivre = 0').run(v.id).changes;
    journal(db, u, poste || 'Accueil', 'Annulation de passage', `${v.numero} ${nomPatient(patient(db, v.patient_id))} : ${n} bon(s) annulé(s). Motif : ${motif}`, { niveau: 'alerte' });
    return { numero: v.numero, bons: n };
  })();
}
function ajouterAccord(db, u, passageId, accordSaisi, poste) {
  const v = passage(db, passageId);
  if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
  const accord = texte(accordSaisi, { label: 'N° d’accord', max: 60, requis: true });
  if (v.accord) throw err(409, 'Un accord est déjà enregistré pour ce passage.');
  const c = couverture(db, patient(db, v.patient_id), jourDe(v.cree_le));
  if (c.etat !== 'valide') throw err(409, 'Droits non valides à la date du passage : l’accord ne peut pas s’appliquer.');
  db.transaction(() => {
    db.prepare('UPDATE passages SET accord = ?, accord_le = ? WHERE id = ?').run(accord, maintenant(), v.id);
    recalculerPassage(db, passage(db, v.id));
    journal(db, u, poste, 'Accord ajouté', `${v.numero} : accord ${accord}, part assureur recalculée`);
  })();
}
/* Un passage reste ouvert le jour de son ouverture, s'il est urgent, ou tant que l'hospitalisation qu'il porte est en cours (v1.7). */
function passageOuvert(db, v) {
  return jourDe(v.cree_le) === jourLocal() || !!v.urgent
    || (v.type === 'hospitalisation' && !!db.prepare("SELECT 1 FROM hospitalisations WHERE passage_id = ? AND statut = 'en_cours'").get(v.id));
}

function ajouterActes(db, u, passageId, items, poste) {
  const v = passage(db, passageId);
  if (!v) throw err(404, 'Passage introuvable.');
  if (!passageOuvert(db, v)) throw err(409, 'Passage clos : ouvrez un nouveau passage à l’accueil.');
  if (!Array.isArray(items) || !items.length || items.length > 30) throw err(400, 'Choisissez au moins un acte.');
  return db.transaction(() => {
    let n = 0;
    for (const it of items) {
      const acte = db.prepare('SELECT * FROM actes WHERE id = ? AND actif = 1').get(Number(it.acte_id));
      if (!acte) throw err(400, 'Acte inconnu ou désactivé.');
      const q = entier(it.quantite, { label: 'Quantité', min: 1, max: 50 });
      creerBon(db, u, v, { nature: 'acte', ref: acte }, q, poste === 'Caisse' ? 'caisse' : 'accueil');
      n += q;
    }
    journal(db, u, poste, 'Actes ajoutés', `${n} acte(s) ajouté(s) au passage ${v.numero} depuis une prescription papier`);
    return n;
  })();
}

module.exports = {
  formaterTelephone, passageOuvert,
  AVANCE, soldeAvance, MODES, COUPURES, TYPES_PASSAGE, CATEGORIES_DEPENSES, PARAMS_DEFAUT, NUMERIQUES, COLS_PATIENT,
  params, ecrireParam, vacation, suivant, journal, verifierJournal,
  patient, nomPatient, passage, couverture, couvertureEffective, montants, impaye, enrichirPatient, rechercherPatients,
  creerPatient, modifierPatient, fusionnerPatients, fichePatient, prixNiveau, creerBon, recalculerPassage,
  ouvrirPassage, annulerPassage, ajouterAccord, ajouterActes, derniereConsultationPayee
};
