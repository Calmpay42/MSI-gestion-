'use strict';
/* Données de départ. En production, les tarifs d'actes sont marqués « à valider » :
   aucune facturation n'est possible sur un tarif tant que la direction ne l'a pas vérifié. */
const crypto = require('crypto');
const R = require('./regles');
const A = require('./auth');
const { maintenant, jourLocal, ajouterJours, pad, norm, chiffres } = require('./outils');

const ASSUREURS = [
  ['ASCOMA', 'ASCOMA', 'maj'], ['MCI', 'MCI', 'maj'], ['WTW', 'WTW', 'maj'], ['ANKARA', 'ANKARA', 'maj'], ['MADGI', 'MADGI', 'aut']
];
const ACTES = [
  ['HOSP-STD', 'Journée d’hospitalisation, chambre standard', 'Hospitalisation', null, 15000],
  ['HOSP-VIP', 'Journée d’hospitalisation, chambre VIP', 'Hospitalisation', null, 35000],
  ['CS-MG', 'Consultation de médecine générale', 'Consultation', 'Médecine générale', 10000],
  ['CS-CAR', 'Consultation de cardiologie', 'Consultation', 'Cardiologie', 25000],
  ['CS-RHU', 'Consultation de rhumatologie', 'Consultation', 'Rhumatologie', 25000],
  ['CS-OPH', 'Consultation d’ophtalmologie', 'Consultation', 'Ophtalmologie', 20000],
  ['CS-PSY', 'Consultation de psychiatrie', 'Consultation', 'Psychiatrie', 25000],
  ['CS-PSO', 'Consultation de psychologie', 'Consultation', 'Psychologie', 15000],
  ['CS-URG', 'Consultation d’urgence', 'Urgence', null, 15000],
  ['B-NFS', 'NFS (hémogramme)', 'Laboratoire', null, 6000], ['B-GE', 'Goutte épaisse', 'Laboratoire', null, 3000],
  ['B-GLY', 'Glycémie', 'Laboratoire', null, 2000], ['B-CREA', 'Créatininémie', 'Laboratoire', null, 4000],
  ['B-CRP', 'CRP', 'Laboratoire', null, 5000], ['B-TRA', 'Transaminases (ASAT, ALAT)', 'Laboratoire', null, 6000],
  ['B-ECBU', 'ECBU', 'Laboratoire', null, 8000],
  ['S-TDR', 'TDR paludisme', 'Soins', null, 2500], ['S-INJ', 'Injection', 'Soins', null, 2000], ['S-PERF', 'Pose de perfusion', 'Soins', null, 5000],
  ['S-PANS', 'Pansement simple', 'Soins', null, 3000], ['S-NEB', 'Nébulisation', 'Soins', null, 4000],
  ['T-ECG', 'Électrocardiogramme (ECG)', 'Acte technique', 'Cardiologie', 15000], ['T-ECHO', 'Échographie', 'Acte technique', null, 35000],
  /* Spécialités de l'en-tête MSI : tarifs provisoires, à valider par la direction */
  ['CS-NEP', 'Consultation de néphrologie', 'Consultation', 'Néphrologie', 20000], ['CS-DER', 'Consultation de dermatologie', 'Consultation', 'Dermatologie', 20000],
  ['CS-DIA', 'Consultation de diabétologie', 'Consultation', 'Diabétologie', 20000], ['CS-INF', 'Consultation d’infectiologie', 'Consultation', 'Infectiologie', 20000],
  ['CS-PED', 'Consultation de pédiatrie', 'Consultation', 'Pédiatrie médicale', 20000], ['CS-CPE', 'Consultation de chirurgie pédiatrique', 'Consultation', 'Chirurgie pédiatrique', 20000],
  ['CS-GYN', 'Consultation de gynécologie-obstétrique', 'Consultation', 'Gynécologie-obstétrique', 20000],
  /* Examens d'ophtalmologie aux tarifs d'OphtaSuite */
  ...require('../public/js/specialites').SPECIALITES.Ophtalmologie.examens.filter(e => e.code).map(e => [e.code, e.l, 'Exploration ophtalmologique', 'Ophtalmologie', e.prix])
];

function referentiels(db, { formation }) {
  db.transaction(() => {
    for (const [k, v] of Object.entries(R.PARAMS_DEFAUT)) db.prepare('INSERT OR IGNORE INTO parametres(cle, valeur) VALUES (?, ?)').run(k, v);
    R.ecrireParam(db, 'formation', formation ? 1 : 0);
    R.ecrireParam(db, 'secret_recus', crypto.randomBytes(32).toString('hex'));
    for (const [code, nom, niveau] of ASSUREURS) db.prepare('INSERT OR IGNORE INTO assureurs(code, nom, niveau) VALUES (?,?,?)').run(code, nom, niveau);
    for (const [code, libelle, famille, specialite, prix] of ACTES) {
      db.prepare('INSERT OR IGNORE INTO actes(code, libelle, famille, specialite, prix_non, prix_maj, prix_aut, a_valider) VALUES (?,?,?,?,?,?,?,?)')
        .run(code, libelle, famille, specialite, prix, prix, prix, formation ? 0 : 1);
    }
    R.journal(db, null, 'Système', 'Initialisation de la base', formation ? 'Base de formation' : 'Base de production : tarifs à valider par la direction', { niveau: 'alerte' });
  })();
}

function creerCompte(db, login, nom, roles, changer, specialites) {
  const mdp = A.mdpProvisoire();
  db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,?,?,?)').run(login, nom, roles, A.hacher(mdp), changer ? 1 : 0, maintenant(), specialites || null);
  return { login, nom, roles, mdp };
}
/* v1.8 : personnel de démonstration relié aux comptes de formation, avec le planning de la semaine en cours. */
function personnelFormation(db) {
  const compte = l => (db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(l) || {}).id || null;
  const j = jourLocal(), t = maintenant(), auteur = compte('admin') || 1;
  const d = new Date(j + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7);
  const lundi = d.toISOString().slice(0, 10), jour = n => ajouterJours(lundi, n);
  const P = [
    ['medecin2', 'KONÉ', 'Ibrahim', 'M', 'Médecin', 'Médecine générale', 'CDI', 650000, 25000, 0, null],
    ['medecin1', 'N’GUESSAN', 'Aya', 'F', 'Médecin', 'Ophtalmologie', 'Vacataire', 0, 0, 30000, null],
    ['infirmier1', 'YAO', 'Serge', 'M', 'Infirmier', 'Soins', 'CDI', 220000, 12000, 0, null],
    ['accueil1', 'KOUAMÉ', 'Mireille', 'F', 'Agent d’accueil', 'Accueil', 'CDI', 130000, 0, 0, null],
    ['caisse1', 'BAMBA', 'Fatou', 'F', 'Caissier', 'Caisse', 'CDI', 150000, 0, 0, null],
    ['pharma1', 'TOURÉ', 'Moussa', 'M', 'Pharmacien', 'Pharmacie', 'CDI', 180000, 0, 0, null],
    ['labo1', 'DIALLO', 'Awa', 'F', 'Laborantin', 'Laboratoire', 'CDI', 190000, 0, 0, null],
    ['facturiste1', 'COULIBALY', 'Drissa', 'M', 'Comptable', 'Facturation', 'CDD', 160000, 0, 0, 20]
  ];
  const ids = {};
  for (const [login, nom, prenoms, sexe, fonction, service, contrat, base, garde, vacation, fin] of P) {
    ids[login] = db.prepare(`INSERT INTO employes(matricule, nom, prenoms, sexe, fonction, service, contrat, embauche_le, fin_contrat, salaire_base, taux_garde, taux_vacation, mode_paiement, utilisateur_id, cree_le)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(`EMP-${pad(R.suivant(db, 'employe'), 4)}`, nom, prenoms, sexe, fonction, service, contrat, ajouterJours(j, -400), fin ? ajouterJours(j, fin) : null,
      base, garde, vacation, 'Virement', compte(login), t).lastInsertRowid;
  }
  /* Semaine en cours et semaine suivante : « Mon planning » montre des créneaux à venir quel que soit le jour de la formation. */
  const cr = (login, n, type, debut, fin) => { for (const s of [0, 7]) db.prepare('INSERT INTO planning(employe_id, jour, type, debut, fin, cree_par, cree_le) VALUES (?,?,?,?,?,?,?)').run(ids[login], jour(n + s), type, debut, fin, auteur, t); };
  cr('medecin2', 0, 'permanence', '08:00', '18:00'); cr('medecin2', 1, 'garde', '18:00', '08:00'); cr('medecin2', 3, 'permanence', '08:00', '18:00'); cr('medecin2', 4, 'garde', '18:00', '08:00');
  cr('infirmier1', 0, 'permanence', '08:00', '18:00'); cr('infirmier1', 2, 'garde', '18:00', '08:00'); cr('infirmier1', 5, 'garde', '08:00', '08:00');
  cr('medecin1', 1, 'consultation', '08:00', '13:00'); cr('medecin1', 3, 'consultation', '08:00', '13:00');
}
function comptes(db, { formation }) {
  if (!formation) return [creerCompte(db, 'admin', 'Administrateur MSI', 'admin,direction', true)];
  const liste = [
    creerCompte(db, 'accueil1', 'Agent d’accueil (formation)', 'accueil', false),
    creerCompte(db, 'caisse1', 'Agent de facturation (formation)', 'caisse', false),
    creerCompte(db, 'pharma1', 'Pharmacien (formation)', 'pharmacie', false),
    creerCompte(db, 'gerant1', 'Gérant de la pharmacie (formation)', 'pharmacien', false),
    creerCompte(db, 'infirmier1', 'Infirmier (formation)', 'infirmier', false),
    creerCompte(db, 'facturiste1', 'Facturiste (formation)', 'facturiste', false),
    creerCompte(db, 'comptable1', 'Comptable (formation)', 'comptable', false),
    creerCompte(db, 'medecin1', 'Dr Ophtalmologue (formation)', 'medecin', false, 'Ophtalmologie'),
    creerCompte(db, 'medecin2', 'Dr Généraliste (formation)', 'medecin', false, 'Médecine générale,Cardiologie'),
    creerCompte(db, 'labo1', 'Technicien de laboratoire (formation)', 'laboratoire', false),
    creerCompte(db, 'raf1', 'Responsable administratif et financier (formation)', 'raf', false),
    creerCompte(db, 'direction1', 'Direction (formation)', 'direction', false),
    creerCompte(db, 'admin', 'Administrateur (formation)', 'admin', false),
    creerCompte(db, 'rh1', 'Ressources humaines (formation)', 'rh', false)
  ];
  personnelFormation(db);
  return liste;
}

/* Jeu fictif identique à la maquette, pour former le personnel sans toucher aux vraies données. */
const CHAMBRES_FORMATION = [['101', 'Chambre 101', 'standard', 2], ['102', 'Chambre 102', 'standard', 2], ['103', 'Chambre 103', 'standard', 1], ['104', 'Chambre 104', 'standard', 1], ['201', 'Suite 201', 'vip', 1], ['202', 'Suite 202', 'vip', 1]];
function donneesFormation(db) {
  for (const [code, nom, categorie, lits] of CHAMBRES_FORMATION) db.prepare('INSERT OR IGNORE INTO chambres(code, nom, categorie, lits) VALUES (?,?,?,?)').run(code, nom, categorie, lits);
  const t = maintenant(), j = jourLocal();
  const ass = code => db.prepare('SELECT id FROM assureurs WHERE code = ?').get(code).id;
  const patients = [
    ['KOUASSI', 'Aya Marie-Josée', 'F', '1991-04-12', '07 08 12 34 56', 'Bingerville', ass('ASCOMA'), 'ASC-448120', 80, ajouterJours(j, 240)],
    ['KONAN', 'Yao Serge', 'M', '1985-01-03', '05 04 77 88 12', 'Cocody', null, null, null, null],
    ['TRAORÉ', 'Awa', 'F', '1996-10-21', '01 02 33 44 55', 'Bingerville', ass('MADGI'), 'MDG-20931', 70, ajouterJours(j, -12)],
    ['DIABATÉ', 'Mariam', 'F', '1978-06-08', '07 77 65 43 21', 'Anyama', null, null, null, null],
    ['N’GUESSAN', 'Koffi Alain', 'M', '1968-12-30', '05 55 10 20 30', 'Bingerville', ass('MCI'), 'MCI-771045', 80, ajouterJours(j, 120)]
  ];
  const ids = patients.map((p, i) => db.prepare(`INSERT INTO patients(ipp, nom, prenoms, recherche, sexe, naissance, telephone, tel_chiffres, commune, assureur_id, num_assure, taux, validite, cree_le)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run('P-' + pad(R.suivant(db, 'ipp'), 6), p[0], p[1], norm(p[0] + ' ' + p[1]) + ' | ' + norm(p[1] + ' ' + p[0]),
    p[2], p[3], p[4], chiffres(p[4]), p[5], p[6], p[7], p[8], p[9], t).lastInsertRowid);
  const passe = n => { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString(); };
  const mg = db.prepare("SELECT * FROM actes WHERE code = 'CS-MG'").get();
  const v1 = db.prepare("INSERT INTO passages(numero, patient_id, type, cree_le) VALUES ('V-REPRISE-001', ?, 'reprise', ?)").run(ids[1], passe(20)).lastInsertRowid;
  db.prepare("INSERT INTO bons(passage_id, patient_id, nature, code, libelle, quantite, prix, origine, cree_le) VALUES (?, ?, 'reprise', 'REPRISE', 'Solde impayé antérieur (reprise)', 1, 5000, 'reprise', ?)").run(v1, ids[1], passe(20));
  const v2 = db.prepare("INSERT INTO passages(numero, patient_id, type, specialite, cree_le) VALUES ('V-REPRISE-002', ?, 'consultation', 'Médecine générale', ?)").run(ids[3], passe(6)).lastInsertRowid;
  db.prepare("INSERT INTO bons(passage_id, patient_id, nature, code, libelle, quantite, prix, paye, origine, acte_id, specialite, cree_le) VALUES (?, ?, 'acte', 'CS-MG', ?, 1, ?, 1, 'reprise', ?, 'Médecine générale', ?)")
    .run(v2, ids[3], mg.libelle, mg.prix_non, mg.id, passe(6));
  const produits = [
    ['PARA500', 'Paracétamol 500 mg', 'Paracétamol', 'Comprimé', 'Antalgique', 1500, 1300, 1000, 30, 0, [['PAR-2604', 90, 20], ['PAR-2511', 380, 100]]],
    ['AMOX500', 'Amoxicilline 500 mg', 'Amoxicilline', 'Gélule', 'Antibiotique', 3500, 3000, 2500, 20, 0, [['AMX-2501', -5, 12], ['AMX-2602', 25, 18], ['AMX-2610', 240, 40]]],
    ['ARTLUM', 'Artéméther-luméfantrine 80/480', 'Artéméther-luméfantrine', 'Comprimé', 'Antipaludique', 4500, 4000, 3500, 15, 0, [['ART-2605', 200, 60]]],
    ['METF850', 'Metformine 850 mg', 'Metformine', 'Comprimé', 'Antidiabétique', 3000, 2700, 2200, 10, 0, [['MET-2609', 330, 8]]],
    ['AMLO5', 'Amlodipine 5 mg', 'Amlodipine', 'Comprimé', 'Antihypertenseur', 3500, 3000, 2600, 10, 0, [['AML-2612', 400, 45]]],
    ['IBU400', 'Ibuprofène 400 mg', 'Ibuprofène', 'Comprimé', 'Anti-inflammatoire', 2000, 1800, 1500, 20, 0, []],
    ['CEFT1G', 'Ceftriaxone 1 g injectable', 'Ceftriaxone', 'Poudre injectable', 'Antibiotique', 4000, 3500, 3000, 10, 0, [['CEF-2607', 280, 25]]],
    ['SRO', 'SRO (réhydratation orale)', 'Sels de réhydratation', 'Sachet', 'Réhydratation', 600, 500, 400, 30, 0, [['SRO-2608', 300, 80]]],
    ['OMEP20', 'Oméprazole 20 mg', 'Oméprazole', 'Gélule', 'Antiulcéreux', 2500, 2200, 1800, 10, 0, [['OME-2609', 60, 5]]],
    ['DICLO75', 'Diclofénac 75 mg injectable', 'Diclofénac', 'Ampoule', 'Anti-inflammatoire', 1000, 900, 700, 20, 0, [['DIC-2603', 50, 30]]],
    ['DIAZ5', 'Diazépam 5 mg', 'Diazépam', 'Comprimé', 'Anxiolytique', 2500, 2200, 1800, 5, 1, [['DZP-2611', 300, 20]]],
    ['SAL100', 'Salbutamol spray 100 µg', 'Salbutamol', 'Aérosol', 'Bronchodilatateur', 4500, 4000, 3500, 5, 0, [['SAL-2702', 520, 12]]]
  ];
  for (const [code, nom, dci, forme, famille, pmaj, paut, pnon, seuil, psy, lots] of produits) {
    const pid = db.prepare('INSERT INTO produits(code, nom, dci, forme, famille, seuil, prix_maj, prix_aut, prix_non, psychotrope) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(code, nom, dci, forme, famille, seuil, pmaj, paut, pnon, psy).lastInsertRowid;
    for (const [numero, jours, q] of lots) {
      const lid = db.prepare('INSERT INTO lots(produit_id, numero, peremption, quantite, prix_achat, fournisseur, cree_le) VALUES (?,?,?,?,?,?,?)')
        .run(pid, numero, ajouterJours(j, jours), q, Math.round(pnon * 0.6), 'Stock initial', t).lastInsertRowid;
      db.prepare('INSERT INTO mouvements(lot_id, produit_id, type, quantite, motif, cree_le) VALUES (?,?,?,?,?,?)').run(lid, pid, 'reception', q, 'Stock initial (formation)', t);
    }
  }
}

/* Mise à jour d'une base existante : ajoute les actes nouveaux du catalogue, sans toucher aux tarifs déjà saisis. */
function completerReferentiels(db) {
  const formation = !!R.params(db).formation;
  let n = 0;
  for (const [code, libelle, famille, specialite, prix] of ACTES) {
    n += db.prepare('INSERT OR IGNORE INTO actes(code, libelle, famille, specialite, prix_non, prix_maj, prix_aut, a_valider) VALUES (?,?,?,?,?,?,?,?)')
      .run(code, libelle, famille, specialite, prix, prix, prix, formation ? 0 : 1).changes;
  }
  if (n) R.journal(db, null, 'Système', 'Catalogue complété', `${n} acte(s) ajouté(s) par la mise à jour${formation ? '' : ', tarifs à valider'}`, { niveau: 'alerte' });
  return n;
}

module.exports = { referentiels, comptes, donneesFormation, completerReferentiels, ACTES, ASSUREURS };
