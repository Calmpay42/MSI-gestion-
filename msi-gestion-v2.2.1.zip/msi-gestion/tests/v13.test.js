'use strict';
/* Recette de la version 1.3 : avances et factures récapitulatives, laboratoire, bordereaux assureurs. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, labo, dir1, raf, medecin;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null);
const pid = nom => db.prepare('SELECT id FROM patients WHERE nom = ?').get(nom).id;
const acte = code => db.prepare('SELECT id FROM actes WHERE code = ?').get(code).id;
const theorique = async () => (await caisse.get('/api/etat')).data.ma_session.especes.theorique;
const payer = (bonIds, paiements) => caisse.post('/api/caisse/encaissement', { bon_ids: bonIds, paiements });
const bon = passageId => db.prepare('SELECT * FROM bons WHERE passage_id = ? ORDER BY id').all(passageId);

let adm;
test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v13-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('labo', 'laboratoire'); compte('dir1', 'direction'); compte('raf', 'raf'); compte('medecin', 'medecin', 'Médecine générale');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, labo, dir1, raf, medecin] = await Promise.all(['accueil', 'caisse', 'labo', 'dir1', 'raf', 'medecin'].map(l => client().login(l)));
  compte('adm', 'admin'); adm = await client().login('adm');
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Avances : dépôt, paiement plafonné au solde, remboursement validé puis versé, restitution sur avoir', async () => {
  const t0 = await theorique();
  const d = await caisse.post('/api/avances', { patient_id: pid('KONAN'), montant: 50000, mode: 'Espèces', motif: 'Avance sur intervention' });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.match(d.data.numero, /^DEP-\d{4}-00001$/); assert.equal(d.data.solde, 50000);
  assert.equal(await theorique(), t0 + 50000, 'dépôt en espèces compté dans la caisse');
  const v = await accueil.post('/api/passages', { patient_id: pid('KONAN'), type: 'consultation', acte_id: acte('CS-MG') });
  const cs = bon(v.data.id)[0];
  assert.equal((await payer([cs.id], [{ mode: 'Avance du patient', montant: 60000 }])).status, 400, 'somme différente du net');
  const p = await payer([cs.id], [{ mode: 'Avance du patient', montant: cs.prix }]);
  assert.equal(p.status, 200, JSON.stringify(p.data));
  assert.equal((await caisse.get('/api/avances?patient_id=' + pid('KONAN'))).data.solde, 40000);
  const v2 = await accueil.post('/api/passages', { patient_id: pid('KONAN'), type: 'soins' });
  await caisse.post(`/api/passages/${v2.data.id}/actes`, { actes: [{ acte_id: acte('T-ECHO'), quantite: 2 }] });
  assert.equal((await payer([bon(v2.data.id)[0].id], [{ mode: 'Avance du patient', montant: 70000 }])).status, 409, 'avance insuffisante');
  assert.equal((await caisse.post('/api/avances/remboursement', { patient_id: pid('KONAN'), montant: 30000, motif: 'Intervention reportée' })).status, 200);
  const dem = db.prepare("SELECT id FROM demandes WHERE type = 'remboursement_avance'").get().id;
  assert.equal((await dir1.post(`/api/demandes/${dem}/decision`, { accepte: true })).status, 200);
  assert.equal((await caisse.get('/api/avances?patient_id=' + pid('KONAN'))).data.solde, 10000);
  const aVerser = (await caisse.get('/api/etat')).data.avances_a_verser;
  assert.equal(aVerser.length, 1);
  const t1 = await theorique();
  assert.equal((await caisse.post(`/api/avances/${aVerser[0].id}/versement`)).status, 200);
  assert.equal(await theorique(), t1 - 30000, 'remboursement sorti de la caisse');
  assert.equal((await caisse.post(`/api/recus/${p.data.id}/annulation`, { motif: 'Erreur de passage' })).status, 200);
  const an = db.prepare("SELECT id FROM demandes WHERE type = 'annulation' AND statut = 'en_attente'").get().id;
  assert.equal((await adm.post(`/api/demandes/${an}/decision`, { accepte: true })).status, 200);
  assert.equal((await caisse.get('/api/avances?patient_id=' + pid('KONAN'))).data.solde, 10000 + cs.prix, 'avance restituée sur avoir');
  assert.throws(() => db.prepare('DELETE FROM avances').run(), /interdite/);
});

test('Facture récapitulative : numérotée, figée, répartition exacte', async () => {
  const v = await accueil.post('/api/passages', { patient_id: pid('KOUASSI'), type: 'consultation', acte_id: acte('CS-CAR'), accord: 'ASC-9' });
  await caisse.post(`/api/passages/${v.data.id}/actes`, { actes: [{ acte_id: acte('T-ECG'), quantite: 1 }] });
  const [c1] = bon(v.data.id);
  await payer([c1.id], [{ mode: 'Espèces', montant: c1.prix * (100 - c1.taux) / 100 }]);
  assert.equal((await accueil.post('/api/factures', { passage_id: v.data.id })).status, 403);
  const f = await caisse.post('/api/factures', { passage_id: v.data.id, destinataire: 'Société Ivoire Services' });
  assert.equal(f.status, 200, JSON.stringify(f.data)); assert.match(f.data.numero, /^FAC-\d{4}-00001$/);
  const x = (await raf.get('/api/factures/' + f.data.id)).data;
  const t = x.donnees.totaux;
  assert.equal(t.total, 25000 + 15000); assert.equal(t.part_assureur, 20000 + 12000); assert.equal(t.regle, 5000); assert.equal(t.reste, 3000);
  assert.throws(() => db.prepare("UPDATE factures SET total = 0").run(), /non modifiable/);
});

test('Laboratoire : examen bloqué avant paiement, valeurs anormales signalées, résultat figé et rectifiable, visible du médecin', async () => {
  const v = await accueil.post('/api/passages', { patient_id: pid('DIABATÉ'), type: 'labo' });
  await caisse.post(`/api/passages/${v.data.id}/actes`, { actes: [{ acte_id: acte('B-NFS'), quantite: 1 }, { acte_id: acte('B-GLY'), quantite: 1 }] });
  const [nfs, gly] = bon(v.data.id);
  assert.equal((await caisse.get('/api/laboratoire/file')).status, 403);
  const f0 = (await labo.get('/api/laboratoire/file')).data;
  assert.equal(f0.find(x => x.bon_id === nfs.id).statut, 'a_payer');
  assert.equal((await labo.post('/api/laboratoire/examens/' + nfs.id, { lignes: [{ p: 'Hémoglobine', valeur: '9' }] })).status, 409);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Examen bloqué'").get());
  await payer([nfs.id], [{ mode: 'Espèces', montant: nfs.prix }]);
  const ex = (await labo.get('/api/laboratoire/examens/' + nfs.id)).data;
  assert.equal(ex.statut, 'a_realiser'); assert.equal(ex.modele.length, 6);
  const lignes = ex.modele.map(l => ({ ...l, valeur: l.p === 'Hémoglobine' ? '9,2' : l.p === 'Plaquettes' ? '250' : '' }));
  const s = await labo.post('/api/laboratoire/examens/' + nfs.id, { lignes, conclusion: 'Anémie modérée' });
  assert.equal(s.status, 200); assert.equal(s.data.anormaux, 1);
  assert.equal((await labo.post(`/api/laboratoire/resultats/${s.data.id}/validation`)).status, 200);
  assert.equal((await labo.post('/api/laboratoire/examens/' + nfs.id, { lignes })).status, 409, 'résultat validé figé');
  assert.throws(() => db.prepare("UPDATE resultats SET conclusion = 'x' WHERE id = ?").run(s.data.id), /non modifiable/);
  const r2 = await labo.post(`/api/laboratoire/resultats/${s.data.id}/rectification`, { motif: 'Erreur de saisie de l’hématocrite' });
  assert.equal(r2.status, 200);
  await labo.post('/api/laboratoire/examens/' + nfs.id, { lignes: lignes.map(l => (l.p === 'Hématocrite' ? { ...l, valeur: '28' } : l)), conclusion: 'Anémie modérée' });
  assert.equal((await labo.post(`/api/laboratoire/resultats/${r2.data.id}/validation`)).status, 200);
  const d = (await medecin.get('/api/dossiers/' + pid('DIABATÉ'))).data;
  const nfsRes = d.resultats.find(x => x.code === 'B-NFS');
  assert.equal(nfsRes.donnees.find(l => l.p === 'Hémoglobine').drapeau, 'B');
  assert.equal(d.resultats.filter(x => x.code === 'B-NFS').length, 1, 'seule la version rectifiée est présentée');
  assert.equal((await labo.get('/api/dossiers/' + pid('DIABATÉ'))).status, 403, 'le laboratoire ne lit pas le dossier médical');
  assert.equal((await labo.get('/api/laboratoire/file')).data.find(x => x.bon_id === gly.id).statut, 'a_payer');
});

test('Bordereaux : un acte jamais facturé deux fois, règlements plafonnés, rejets, annulation par la direction, balance âgée', async () => {
  assert.equal((await caisse.get('/api/bordereaux')).status, 403);
  const af = (await raf.get('/api/tiers-payant/a-facturer')).data;
  const asc = af.find(x => x.assureur === 'ASCOMA');
  assert.equal(asc.montant, 20000 + 0, 'seule la consultation payée est facturable, l’ECG n’est pas réglé');
  const j = new Date().toISOString().slice(0, 10), idAsc = asc.assureur_id;
  const b = await raf.post('/api/bordereaux', { assureur_id: idAsc, du: j, au: j });
  assert.equal(b.status, 200, JSON.stringify(b.data)); assert.match(b.data.numero, /^BRD-\d{4}-0001$/); assert.equal(b.data.total, 20000);
  assert.equal((await raf.post('/api/bordereaux', { assureur_id: idAsc, du: j, au: j })).status, 409, 'rien à facturer deux fois');
  const csv = (await raf.get(`/api/bordereaux/${b.data.id}/csv`)).data;
  assert.ok(csv.includes('KOUASSI') && csv.includes('ASC-9'));
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/reglements`, { date: j, mode: 'Virement', reference: 'VIR-001', montant: 15000 })).status, 200);
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/reglements`, { date: j, mode: 'Virement', reference: 'vir-001', montant: 1000 })).status, 409, 'référence déjà enregistrée');
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/reglements`, { date: j, mode: 'Chèque', reference: 'CHQ-9', montant: 6000 })).status, 409, 'au-delà du reste dû');
  const ligne = (await raf.get('/api/bordereaux/' + b.data.id)).data.lignes[0];
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/rejets`, { lignes: [{ id: ligne.id, motif: 'Accord expiré' }] })).status, 409, 'rejet supérieur au reste dû');
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/annulation`, { motif: 'x' })).status, 403, 'annulation réservée à l’administrateur');
  assert.equal((await dir1.post(`/api/bordereaux/${b.data.id}/annulation`, { motif: 'x' })).status, 403);
  assert.equal((await adm.post(`/api/bordereaux/${b.data.id}/annulation`, { motif: 'Erreur' })).status, 409, 'déjà réglé en partie');
  const ba = (await raf.get('/api/tiers-payant/balance-agee')).data.find(x => x.assureur === 'ASCOMA');
  assert.equal(ba.j30, 5000);
  const vn = await accueil.post('/api/passages', { patient_id: pid('N’GUESSAN'), type: 'consultation', acte_id: acte('CS-MG'), accord: 'MCI-7' });
  const bn = bon(vn.data.id)[0];
  await payer([bn.id], [{ mode: 'Espèces', montant: bn.prix * (100 - bn.taux) / 100 }]);
  const idMci = db.prepare("SELECT id FROM assureurs WHERE code = 'MCI'").get().id;
  const m1 = await raf.post('/api/bordereaux', { assureur_id: idMci, du: j, au: j });
  assert.equal((await adm.post(`/api/bordereaux/${m1.data.id}/annulation`, { motif: 'Période erronée' })).status, 200);
  const m2 = await raf.post('/api/bordereaux', { assureur_id: idMci, du: j, au: j });
  assert.equal(m2.status, 200, 'les actes d’un bordereau annulé redeviennent facturables');
  const l2 = (await raf.get('/api/bordereaux/' + m2.data.id)).data.lignes[0];
  assert.equal((await raf.post(`/api/bordereaux/${m2.data.id}/rejets`, { lignes: [{ id: l2.id, motif: 'Acte non couvert' }] })).status, 200);
  assert.equal((await raf.get('/api/bordereaux')).data.find(x => x.id === m2.data.id).statut, 'solde');
  assert.throws(() => db.prepare('DELETE FROM bordereaux').run(), /interdite/);
  assert.throws(() => db.prepare('UPDATE bordereaux SET total = 0').run(), /non modifiable/);
});
