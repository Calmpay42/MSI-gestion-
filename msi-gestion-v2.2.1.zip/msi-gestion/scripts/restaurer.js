'use strict';
/* Restauration : arrêtez le serveur, puis  npm run restaurer -- chemin/vers/msi-AAAAMMJJ-HHMMSS.msibak
   Option : --vers autre.db pour restaurer ailleurs (contrôle d'une sauvegarde sans toucher à la production). */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { lireConfig } = require('../serveur/config');
const { cle, dechiffrer, horodatage } = require('../serveur/sauvegarde');

const args = process.argv.slice(2).filter(a => a !== '--formation');
const source = args.find(a => !a.startsWith('--') && args[args.indexOf(a) - 1] !== '--vers');
const iVers = args.indexOf('--vers');
if (!source || !fs.existsSync(source)) {
  console.error('Usage : npm run restaurer -- <fichier.msibak> [--vers <base.db>]');
  process.exit(1);
}
const conf = lireConfig();
const cible = iVers >= 0 ? path.resolve(args[iVers + 1]) : conf.fichier;
const brut = dechiffrer(fs.readFileSync(source), cle(conf.dossier_donnees));
if (fs.existsSync(cible)) {
  const archive = cible.replace(/\.db$/, '') + `.avant-restauration-${horodatage()}.db`;
  fs.renameSync(cible, archive);
  for (const ext of ['-wal', '-shm']) if (fs.existsSync(cible + ext)) fs.renameSync(cible + ext, archive + ext);
  console.log(`Base actuelle conservée sous : ${archive}`);
}
fs.writeFileSync(cible, brut);
const db = new Database(cible);
const integrite = db.pragma('integrity_check', { simple: true });
const n = t => db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n;
console.log(`Restauration effectuée : ${cible}`);
console.log(`Contrôle d’intégrité : ${integrite}`);
console.log(`Patients ${n('patients')}, passages ${n('passages')}, reçus ${n('recus')}, lignes d’audit ${n('audit')}`);
db.close();
if (integrite !== 'ok') process.exit(2);
