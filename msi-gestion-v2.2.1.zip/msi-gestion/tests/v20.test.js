'use strict';
/* Recette de la version 2.0 : mode en ligne (relais HTTPS reconnu, connexions non chiffrées refusées, HTTPS imposé,
   limitation des tentatives par adresse, adresse de santé) ; le mode local reste inchangé. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, dir, srvLigne, srvLocal, ligne, local;
const HTTPS = { 'X-Forwarded-Proto': 'https' };
const appel = (base, url, { methode = 'GET', corps, entetes = {} } = {}) =>
  fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...entetes }, body: corps ? JSON.stringify(corps) : undefined });
const connexion = (base, entetes, login = 'directeur', mdp = MDP) => appel(base, '/api/connexion', { methode: 'POST', corps: { login, mdp }, entetes });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v20-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le) VALUES (?,?,?,?,0,?)').run('directeur', 'DIRECTEUR', 'direction', A.hacher(MDP), new Date().toISOString());
  const ecoute = app => new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  srvLigne = await ecoute(creerApp(db, { enLigne: true }));
  srvLocal = await ecoute(creerApp(db, {}));
  ligne = `http://127.0.0.1:${srvLigne.address().port}`;
  local = `http://127.0.0.1:${srvLocal.address().port}`;
});
test.after(() => { srvLigne.close(); srvLocal.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Adresse de santé : publique, sans aucune donnée, version du logiciel', async () => {
  const r = await appel(ligne, '/api/sante');
  assert.equal(r.status, 200);
  const d = await r.json();
  assert.deepEqual(Object.keys(d).sort(), ['base', 'logiciel', 'ok']);
  assert.equal(d.ok, true);
  assert.equal(d.logiciel, require('../package.json').version);
});

test('Mode en ligne : connexion non chiffrée refusée, HTTPS imposé au navigateur, cookie de session sécurisé', async () => {
  assert.equal((await appel(ligne, '/')).status, 403, 'page refusée hors HTTPS');
  assert.equal((await connexion(ligne, {})).status, 403, 'aucun mot de passe accepté en clair');
  const page = await appel(ligne, '/', { entetes: HTTPS });
  assert.equal(page.status, 200);
  assert.match(page.headers.get('strict-transport-security') || '', /max-age=31536000/);
  const c = await connexion(ligne, HTTPS);
  assert.equal(c.status, 200);
  const cookie = c.headers.get('set-cookie');
  assert.match(cookie, /; Secure/);
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
});

test('Limitation par adresse : 30 échecs suspendent cette adresse, pas les autres', async () => {
  const ip = { ...HTTPS, 'X-Forwarded-For': '203.0.113.7' }, autre = { ...HTTPS, 'X-Forwarded-For': '203.0.113.8' };
  for (let i = 0; i < 30; i++) assert.equal((await connexion(ligne, ip, 'inconnu' + i, 'faux')).status, 401);
  const bloque = await connexion(ligne, ip);
  assert.equal(bloque.status, 429, 'même le bon mot de passe attend la fin de la suspension');
  assert.match((await bloque.json()).erreur, /Trop de tentatives/);
  assert.equal((await connexion(ligne, autre)).status, 200, 'une autre adresse n’est pas concernée');
});

test('Mode local inchangé : HTTP accepté, aucun en-tête HTTPS imposé', async () => {
  const r = await appel(local, '/');
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('strict-transport-security'), null);
  const c = await connexion(local, {});
  assert.equal(c.status, 200);
  assert.doesNotMatch(c.headers.get('set-cookie'), /; Secure/);
});
