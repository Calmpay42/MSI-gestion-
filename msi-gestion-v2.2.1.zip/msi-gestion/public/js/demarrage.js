'use strict';
/* Démarrage : événements, synchronisation entre postes toutes les 5 secondes, typographie française. */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const a = el.dataset.action, fn = ACTIONS[a];
  if (!fn) return;
  if (a !== 'backdrop') e.preventDefault();
  if (el.disabled) return;
  fn(el, e);
});
document.addEventListener('input', e => { const el = e.target.closest('[data-input]'); if (el && INPUTS[el.dataset.input]) INPUTS[el.dataset.input](el, e); });
document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el && CHANGES[el.dataset.change]) CHANGES[el.dataset.change](el, e); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && modalOuverte()) { closeModal(); return; }
  const cible = e.target;
  if (e.key === 'Enter' && cible && cible.dataset && cible.dataset.enter && ACTIONS[cible.dataset.enter]) { e.preventDefault(); ACTIONS[cible.dataset.enter](cible, e); }
});

/* Synchronisation : un poste voit les bons, paiements et décisions des autres postes sans recharger la page.
   Pas de rafraîchissement pendant une saisie ou une fenêtre ouverte, pour ne jamais effacer ce que l'agent tape. */
setInterval(async () => {
  if (!MOI || !E || MOI.changer_mdp || OCCUPE || document.hidden) return;
  try {
    const { v } = await api('GET', '/api/version', undefined, true);
    if (v === VERSION) return;
    const actif = document.activeElement;
    const saisie = actif && /^(INPUT|TEXTAREA|SELECT)$/.test(actif.tagName) && $('#app').contains(actif);
    if (modalOuverte() || saisie) return;
    const y = window.scrollY;
    await charger(true);
    render();
    window.scrollTo(0, y);
  } catch (e) { /* réseau momentanément indisponible : nouvel essai dans 5 secondes */ }
}, 5000);

/* Typographie française : espace insécable avant « : ; ! ? % » et à l'intérieur des guillemets. */
const TYPO_TEST = / [:;!?\u00bb%]|\u00ab /;
const typo = v => v.replace(/ ([:;!?\u00bb%])/g, '\u00a0$1').replace(/\u00ab /g, '\u00ab\u00a0');
function corrigerTexte(n) {
  if (n.nodeType === 3) { if (TYPO_TEST.test(n.nodeValue)) n.nodeValue = typo(n.nodeValue); return; }
  if (n.nodeType !== 1 || n.tagName === 'TEXTAREA') return;
  const tw = document.createTreeWalker(n, 4);
  let t;
  while ((t = tw.nextNode())) { if (t.parentNode && t.parentNode.tagName === 'TEXTAREA') continue; if (TYPO_TEST.test(t.nodeValue)) t.nodeValue = typo(t.nodeValue); }
}
if (typeof MutationObserver === 'function') {
  const mo = new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(corrigerTexte)));
  ['#app', '#modal-root', '#toast-root', '#print-root'].forEach(sel => { const el = $(sel); if (el) mo.observe(el, { childList: true, subtree: true }); });
}

demarrerSession();
