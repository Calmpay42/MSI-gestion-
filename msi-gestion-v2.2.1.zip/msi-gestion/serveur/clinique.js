'use strict';
/* Module clinique (phase 2) : consultations par spécialité, documents médicaux, rendez-vous.
   Secret médical : seul le profil médecin lit le contenu clinique. La caisse ne voit que les bons,
   la pharmacie que les médicaments prescrits, l'accueil que les rendez-vous. */
const S = require('../public/js/specialites');
const { pad, jourLocal, maintenant, jourDe, bornesJour, ajouterJours, err, texte, entier, date } = require('./outils');
const R = require('./regles');

const TYPES_DOC = {
  ordonnance: ['ORM', 'Ordonnance médicale'], examens: ['EXA', 'Demande d’examens'], lunettes: ['LUN', 'Ordonnance de lunettes'],
  certificat: ['CER', 'Certificat'], compte_rendu: ['CR', 'Compte rendu'], orientation: ['ORI', 'Lettre d’orientation'], note: ['NOT', 'Note complémentaire'],
  conseils: ['CON', 'Fiches conseils']
};
const STATUTS_RDV = ['prevu', 'honore', 'absent', 'annule'];
const specialitesDe = u => String(u.specialites || '').split(',').map(s => s.trim()).filter(Boolean);
function habilite(u, specialite) {
  const mes = specialitesDe(u);
  if (mes.length && !mes.includes(specialite)) throw err(403, `Votre compte n’est pas habilité en ${specialite.toLowerCase()}.`);
}

/* Le bon de consultation (ou d'urgence) du passage conditionne l'ouverture de la consultation. */
const bonsConsultation = (db, passageId) => db.prepare(`SELECT b.* FROM bons b JOIN actes a ON a.id = b.acte_id
  WHERE b.passage_id = ? AND b.annule = 0 AND a.famille IN ('Consultation', 'Urgence')`).all(passageId);
const reglement = bons => (!bons.length ? 'sans_bon' : bons.every(b => b.paye || b.gratuit || b.urgent) ? 'regle' : 'a_payer');

function fileMedecin(db, u) {
  const [debut] = bornesJour(jourLocal()), [veille] = bornesJour(ajouterJours(jourLocal(), -1));
  const mes = specialitesDe(u);
  return db.prepare(`SELECT * FROM passages WHERE type IN ('consultation', 'controle', 'urgence') AND (cree_le >= ? OR (urgent = 1 AND cree_le >= ?)) ORDER BY cree_le`).all(debut, veille)
    .filter(v => v.urgent || !mes.length || mes.includes(v.specialite))
    .map(v => {
      const p = R.patient(db, v.patient_id), paiement = reglement(bonsConsultation(db, v.id));
      const c = db.prepare('SELECT id, specialite, medecin_id, valide_le FROM consultations WHERE passage_id = ? ORDER BY id DESC LIMIT 1').get(v.id) || null;
      const cst = db.prepare('SELECT c.medecin_id, c.maj_le, c.prioritaire, c.alertes, u.nom AS par FROM constantes c LEFT JOIN utilisateurs u ON u.id = c.saisi_par WHERE c.passage_id = ?').get(v.id) || null;
      return {
        passage_id: v.id, numero: v.numero, cree_le: v.cree_le, type: v.type, specialite: v.specialite, urgent: !!v.urgent, paiement, consultation: c, orientation: cst ? { medecin_id: cst.medecin_id, par: cst.par, le: cst.maj_le } : v.medecin_id ? { medecin_id: v.medecin_id, par: 'l’accueil', le: v.cree_le } : null,
        prioritaire: !!(cst && cst.prioritaire), alertes: cst && cst.alertes ? JSON.parse(cst.alertes) : [], motif: v.motif || null,
        patient: p && { id: p.id, ipp: p.ipp, nom: p.nom, prenoms: p.prenoms, sexe: p.sexe, naissance: p.naissance },
        statut: c ? (c.valide_le ? 'terminee' : 'en_cours') : paiement === 'regle' ? 'prete' : 'a_payer'
      };
    })
    /* Passage annulé (plus aucun bon) : retiré. Patient orienté par l'infirmerie vers un autre médecin : retiré de cette file. */
    .filter(x => x.paiement !== 'sans_bon' && (!x.orientation || x.orientation.medecin_id === u.id || (x.consultation && x.consultation.medecin_id === u.id)))
    /* Patients prioritaires (constantes anormales) en tête de file tant qu'ils ne sont pas reçus. */
    .sort((a, b) => ((b.prioritaire && !b.consultation) - (a.prioritaire && !a.consultation)) || a.cree_le.localeCompare(b.cree_le));
}

/* Infirmerie (v1.5) : passages du jour à prendre en charge (constantes puis orientation vers un médecin). */
function fileInfirmerie(db) {
  const [debut] = bornesJour(jourLocal()), [veille] = bornesJour(ajouterJours(jourLocal(), -1));
  return db.prepare(`SELECT * FROM passages WHERE type IN ('consultation', 'controle', 'urgence') AND (cree_le >= ? OR (urgent = 1 AND cree_le >= ?)) ORDER BY cree_le`).all(debut, veille)
    .map(v => {
      const p = R.patient(db, v.patient_id), paiement = reglement(bonsConsultation(db, v.id));
      const cst = db.prepare('SELECT c.*, u.nom AS par, m.nom AS medecin FROM constantes c LEFT JOIN utilisateurs u ON u.id = c.saisi_par LEFT JOIN utilisateurs m ON m.id = c.medecin_id WHERE c.passage_id = ?').get(v.id);
      const consultation = db.prepare('SELECT id, medecin_id, valide_le FROM consultations WHERE passage_id = ? ORDER BY id DESC LIMIT 1').get(v.id) || null;
      return {
        passage_id: v.id, numero: v.numero, cree_le: v.cree_le, type: v.type, specialite: v.specialite, urgent: !!v.urgent, paiement,
        patient: p && { id: p.id, ipp: p.ipp, nom: p.nom, prenoms: p.prenoms, sexe: p.sexe, naissance: p.naissance },
        constantes: cst ? { valeurs: JSON.parse(cst.valeurs), observation: cst.observation, medecin_id: cst.medecin_id, medecin: cst.medecin, par: cst.par, le: cst.maj_le, prioritaire: !!cst.prioritaire, alertes: cst.alertes ? JSON.parse(cst.alertes) : [] } : null,
        medecin_id: v.medecin_id || null, motif: v.motif || null,
        consultation,
        statut: consultation ? (consultation.valide_le ? 'terminee' : 'en_consultation') : cst ? 'orientee' : (paiement === 'regle' || v.urgent) ? 'a_prendre' : 'a_payer'
      };
    })
    .filter(x => x.paiement !== 'sans_bon');
}

function listerMedecins(db) {
  return db.prepare('SELECT id, nom, roles, specialites, telephone FROM utilisateurs WHERE actif = 1 ORDER BY nom').all()
    .filter(x => String(x.roles).split(',').includes('medecin'))
    .map(x => ({ id: x.id, nom: x.nom, specialites: specialitesDe(x), telephone: x.telephone || '' }));
}

/* L'infirmier prend les constantes, puis oriente le patient vers un médecin, qui les retrouve dans sa consultation.
   Même condition que la consultation : bon réglé (ou urgence), passage du jour, consultation pas encore commencée. */
function enregistrerConstantes(db, u, d) {
  const v = R.passage(db, Number(d.passage_id));
  if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
  if (!['consultation', 'controle', 'urgence'].includes(v.type)) throw err(409, 'Ce passage n’est pas une consultation.');
  if (jourDe(v.cree_le) !== jourLocal() && !v.urgent) throw err(409, 'Passage d’un autre jour : faites ouvrir un nouveau passage à l’accueil.');
  const paiement = reglement(bonsConsultation(db, v.id));
  if (paiement === 'sans_bon') throw err(409, 'Ce passage est annulé.');
  if (!v.urgent && paiement !== 'regle') throw err(409, 'Bon de consultation non réglé : envoyez d’abord le patient à la caisse.');
  if (db.prepare('SELECT 1 FROM consultations WHERE passage_id = ? LIMIT 1').get(v.id)) throw err(409, 'Le médecin a commencé la consultation : transmettez-lui directement les nouvelles mesures.');
  const valeurs = {};
  for (const [k, brut] of Object.entries(d.valeurs || {})) {
    if (!S.CONSTANTES[k] || k === 'imc') continue;
    const t = String(brut == null ? '' : brut).trim().slice(0, 20);
    if (!t) continue;
    if (k === 'ta') {
      if (!/^\d{2,3}\s*\/\s*\d{2,3}$/.test(t)) throw err(400, 'Tension artérielle : écrivez par exemple 120/80.');
      valeurs.ta = t.replace(/\s+/g, '');
      continue;
    }
    const n = Number(t.replace(',', '.'));
    if (!isFinite(n) || n < 0) throw err(400, `${S.CONSTANTES[k].l} : valeur numérique attendue.`);
    valeurs[k] = t;
  }
  if (valeurs.poids && valeurs.taille) {
    const kg = Number(String(valeurs.poids).replace(',', '.')), m = Number(String(valeurs.taille).replace(',', '.')) / 100;
    if (kg > 0 && m > 0.3) valeurs.imc = String(Math.round(kg / (m * m) * 10) / 10).replace('.', ',');
  }
  if (!Object.keys(valeurs).length) throw err(400, 'Saisissez au moins une constante.');
  const medecin = db.prepare('SELECT id, nom, roles, specialites, actif FROM utilisateurs WHERE id = ?').get(Number(d.medecin_id));
  if (!medecin || !medecin.actif || !String(medecin.roles).split(',').includes('medecin')) throw err(400, 'Choisissez le médecin que le patient doit voir.');
  const sp = specialitesDe(medecin);
  if (v.specialite && sp.length && !sp.includes(v.specialite) && !v.urgent) throw err(400, `Ce médecin ne consulte pas en ${v.specialite.toLowerCase()}.`);
  const observation = texte(d.observation, { label: 'Observation', max: 300 }) || null;
  const p = R.patient(db, v.patient_id);
  /* v1.6 : toute constante anormale rend le patient prioritaire et suggère un spécialiste. */
  const naissance = p && p.naissance ? new Date(p.naissance) : null;
  const ageP = naissance && !isNaN(naissance) ? Math.floor((Date.now() - naissance.getTime()) / (365.25 * 864e5)) : null;
  const alertes = Object.entries(valeurs).map(([k, x]) => { const a = S.alerte(k, x, { age: ageP, sexe: p && p.sexe }); return a ? { k, valeur: x, niveau: a.niveau, texte: a.texte } : null; }).filter(Boolean);
  const prioritaire = alertes.length > 0, suggestion = S.specialiteSuggeree(alertes, ageP);
  return db.transaction(() => {
    const avant = db.prepare('SELECT id FROM constantes WHERE passage_id = ?').get(v.id);
    if (avant) db.prepare('UPDATE constantes SET valeurs = ?, observation = ?, medecin_id = ?, saisi_par = ?, maj_le = ?, alertes = ?, prioritaire = ? WHERE id = ?').run(JSON.stringify(valeurs), observation, medecin.id, u.id, maintenant(), JSON.stringify(alertes), prioritaire ? 1 : 0, avant.id);
    else db.prepare('INSERT INTO constantes(passage_id, patient_id, valeurs, observation, medecin_id, saisi_par, saisi_le, maj_le, alertes, prioritaire) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(v.id, v.patient_id, JSON.stringify(valeurs), observation, medecin.id, u.id, maintenant(), maintenant(), JSON.stringify(alertes), prioritaire ? 1 : 0);
    R.journal(db, u, 'Infirmerie', avant ? 'Constantes corrigées' : 'Constantes prises',
      `${v.numero} ${R.nomPatient(p)} : ${Object.entries(valeurs).map(([k, x]) => `${S.CONSTANTES[k].l.toLowerCase()} ${x}`).join(', ')} ; orienté vers ${medecin.nom}${prioritaire ? ', prioritaire : ' + alertes.map(a => a.texte.toLowerCase()).join(', ') : ''}`);
    return { medecin: medecin.nom, valeurs, alertes, prioritaire, suggestion };
  })();
}

function ouvrirConsultation(db, u, d) {
  const v = R.passage(db, Number(d.passage_id));
  if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
  if (!['consultation', 'controle', 'urgence'].includes(v.type)) throw err(409, 'Ce passage n’est pas une consultation.');
  if (jourDe(v.cree_le) !== jourLocal() && !v.urgent) throw err(409, 'Passage d’un autre jour : faites ouvrir un nouveau passage à l’accueil.');
  const specialite = v.specialite || String(d.specialite || '');
  if (!S.SPECIALITES[specialite]) throw err(400, 'Choisissez la spécialité de la consultation.');
  habilite(u, specialite);
  const existante = db.prepare('SELECT id FROM consultations WHERE passage_id = ? AND specialite = ?').get(v.id, specialite);
  if (existante) return { id: existante.id, existante: true };
  if (reglement(bonsConsultation(db, v.id)) !== 'regle') {
    R.journal(db, u, 'Consultation', 'Consultation bloquée', `${v.numero} : bon de consultation non réglé`, { niveau: 'blocage' });
    throw err(409, 'Consultation bloquée : le bon de consultation n’est pas réglé. Envoyez le patient à la caisse.', { bloque: true });
  }
  /* Constantes prises à l'infirmerie : reprises dans la consultation, le médecin n'a pas à les ressaisir. */
  const cst = db.prepare('SELECT c.valeurs, c.observation, c.maj_le, u.nom AS par FROM constantes c LEFT JOIN utilisateurs u ON u.id = c.saisi_par WHERE c.passage_id = ?').get(v.id);
  const donnees = cst ? { ...JSON.parse(cst.valeurs), _constantes: { par: cst.par, le: cst.maj_le, observation: cst.observation || null } } : {};
  if (v.motif && !donnees.motif) donnees.motif = v.motif;
  return db.transaction(() => {
    const id = db.prepare('INSERT INTO consultations(passage_id, patient_id, specialite, medecin_id, cree_le, maj_le, donnees) VALUES (?,?,?,?,?,?,?)')
      .run(v.id, v.patient_id, specialite, u.id, maintenant(), maintenant(), JSON.stringify(donnees)).lastInsertRowid;
    R.journal(db, u, 'Consultation', 'Consultation ouverte', `${v.numero} ${R.nomPatient(R.patient(db, v.patient_id))} : ${specialite}`);
    return { id };
  })();
}

function lireConsultation(db, id) {
  const c = db.prepare('SELECT * FROM consultations WHERE id = ?').get(id);
  if (!c) throw err(404, 'Consultation introuvable.');
  return c;
}
function donneesValides(d, max) {
  const o = d && typeof d === 'object' && !Array.isArray(d) ? d : {};
  const s = JSON.stringify(o);
  if (s.length > max) throw err(413, 'Contenu trop volumineux.');
  return { o, s };
}
function enregistrerConsultation(db, u, id, donnees) {
  const c = lireConsultation(db, id);
  if (c.valide_le) throw err(409, 'Consultation validée : ajoutez une note complémentaire.');
  if (c.medecin_id !== u.id) throw err(403, 'Seul le médecin qui a ouvert la consultation peut la modifier.');
  const { o } = donneesValides(donnees, 200000);
  /* Les constantes prises à l'infirmerie restent celles de l'infirmier : le formulaire ne peut pas les remplacer. */
  const avant = typeof c.donnees === 'string' ? JSON.parse(c.donnees || '{}') : (c.donnees || {});
  if (avant._constantes) { for (const k of Object.keys(S.CONSTANTES)) { if (avant[k] != null && avant[k] !== '') o[k] = avant[k]; } o._constantes = avant._constantes; }
  db.prepare('UPDATE consultations SET donnees = ?, diagnostic = ?, maj_le = ? WHERE id = ?').run(JSON.stringify(o), String(o.diagnostic || '').trim().slice(0, 300) || null, maintenant(), id);
  return o;
}
/* v2.2 : le médecin auteur peut modifier sa consultation après validation. Chaque modification est motivée,
   la version précédente est conservée (historique inaltérable) ; les documents déjà émis ne changent pas. */
function modifierConsultation(db, u, id, donnees, motifSaisi) {
  const c = lireConsultation(db, id);
  if (!c.valide_le) throw err(409, 'Consultation non validée : enregistrez simplement le brouillon.');
  if (c.medecin_id !== u.id) throw err(403, 'Seul le médecin qui a réalisé la consultation peut la modifier.');
  const motif = texte(motifSaisi, { label: 'Motif de la modification', max: 300 }) || '';
  if (motif.length < 5) throw err(400, 'Indiquez le motif de la modification.');
  const { o } = donneesValides(donnees, 200000);
  const avant = typeof c.donnees === 'string' ? JSON.parse(c.donnees || '{}') : (c.donnees || {});
  if (avant._constantes) { for (const k of Object.keys(S.CONSTANTES)) { if (avant[k] != null && avant[k] !== '') o[k] = avant[k]; } o._constantes = avant._constantes; }
  if (!String(o.motif || '').trim() || !String(o.diagnostic || '').trim()) throw err(400, 'Le motif de consultation et le diagnostic restent obligatoires.');
  return db.transaction(() => {
    /* Même instant pour la version conservée et la mise à jour : c'est ce que le verrou de la base exige. */
    const t = maintenant();
    db.prepare('INSERT INTO consultation_versions(consultation_id, donnees, diagnostic, motif, modifie_par, modifie_le) VALUES (?,?,?,?,?,?)')
      .run(c.id, JSON.stringify(avant), c.diagnostic || null, motif, u.id, t);
    db.prepare('UPDATE consultations SET donnees = ?, diagnostic = ?, maj_le = ? WHERE id = ?').run(JSON.stringify(o), String(o.diagnostic || '').trim().slice(0, 300) || null, t, c.id);
    const v = R.passage(db, c.passage_id);
    R.journal(db, u, 'Consultation', 'Consultation modifiée après validation', `${v.numero} ${R.nomPatient(R.patient(db, c.patient_id))} : ${motif}`);
    return { versions: versionsConsultation(db, c.id).length };
  })();
}
function versionsConsultation(db, id) {
  return db.prepare('SELECT v.id, v.motif, v.modifie_le, v.diagnostic, u.nom AS par FROM consultation_versions v LEFT JOIN utilisateurs u ON u.id = v.modifie_par WHERE v.consultation_id = ? ORDER BY v.id DESC').all(id);
}
function validerConsultation(db, u, id, donnees) {
  return db.transaction(() => {
    const o = enregistrerConsultation(db, u, id, donnees);
    if (!String(o.motif || '').trim() || !String(o.diagnostic || '').trim()) throw err(400, 'Renseignez le motif et le diagnostic avant de valider.');
    db.prepare('UPDATE consultations SET valide_le = ? WHERE id = ?').run(maintenant(), id);
    const c = lireConsultation(db, id), v = R.passage(db, c.passage_id);
    R.journal(db, u, 'Consultation', 'Consultation validée', `${v.numero} ${R.nomPatient(R.patient(db, c.patient_id))} : ${c.specialite}`);
  })();
}

function dossierMedical(db, u, patientId) {
  const p = R.patient(db, patientId);
  if (!p) throw err(404, 'Patient introuvable.');
  const json = x => ({ ...x, donnees: JSON.parse(x.donnees) });
  const r = {
    patient: R.enrichirPatient(db, p),
    consultations: db.prepare('SELECT c.*, u.nom AS medecin FROM consultations c LEFT JOIN utilisateurs u ON u.id = c.medecin_id WHERE c.patient_id = ? ORDER BY c.cree_le DESC LIMIT 100').all(patientId).map(json),
    documents: db.prepare('SELECT d.*, u.nom AS medecin FROM documents d LEFT JOIN utilisateurs u ON u.id = d.medecin_id WHERE d.patient_id = ? ORDER BY d.id DESC LIMIT 200').all(patientId).map(json),
    rdv: db.prepare('SELECT r.*, u.nom AS medecin FROM rdv r LEFT JOIN utilisateurs u ON u.id = r.medecin_id WHERE r.patient_id = ? ORDER BY r.date DESC LIMIT 50').all(patientId),
    resultats: db.prepare("SELECT id, code, libelle, donnees, conclusion, valide_le FROM resultats WHERE patient_id = ? AND statut = 'valide' ORDER BY valide_le DESC LIMIT 100").all(patientId).map(json),
    pieces: db.prepare('SELECT x.id, x.consultation_id, x.specialite, x.nom, x.mime, x.taille, x.legende, x.cree_le, u.nom AS medecin FROM pieces x LEFT JOIN utilisateurs u ON u.id = x.medecin_id WHERE x.patient_id = ? ORDER BY x.id DESC LIMIT 200').all(patientId)
  };
  R.journal(db, u, 'Consultation', 'Dossier médical consulté', `${p.ipp} ${R.nomPatient(p)}`);
  return r;
}

/* Documents médicaux : jamais modifiés ni supprimés ; une correction se fait par un nouveau document. */
const t = (v, label, max, requis) => texte(v, { label, max, requis });
function validerDocument(type, sp, x) {
  switch (type) {
    case 'ordonnance': {
      const lignes = Array.isArray(x.lignes) ? x.lignes.filter(l => l && String(l.medicament || '').trim()) : [];
      if (!lignes.length || lignes.length > 30) throw err(400, 'Ajoutez au moins un médicament.');
      /* Ordonnance complète exigée : posologie et durée pour chaque médicament (sécurité du patient, délivrance juste). */
      const faites = lignes.map(l => { const m = t(l.medicament, 'Médicament', 160, true); return { medicament: m, posologie: t(l.posologie, `Posologie (${m})`, 300, true), duree: t(l.duree, `Durée (${m})`, 80, true) }; });
      /* Un médicament ne figure qu'une fois : deux lignes pour le même produit exposent à une double prise. */
      const cle = v => String(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(), vus = new Set();
      for (const l of faites) { if (vus.has(cle(l.medicament))) throw err(400, `« ${l.medicament} » figure deux fois : regroupez la posologie sur une seule ligne.`); vus.add(cle(l.medicament)); }
      return { lignes: faites, conseils: t(x.conseils, 'Conseils', 2000) };
    }
    case 'examens': {
      const demandes = Array.isArray(x.items) ? x.items.map(i => String((i && i.l) || i || '').trim()).filter(Boolean) : [];
      const autres = t(x.autres, 'Autres examens', 1000);
      if (!demandes.length && !autres) throw err(400, 'Choisissez au moins un examen.');
      /* Le code tarifaire vient du référentiel, jamais de l'écran : impossible de facturer un examen pour un autre. */
      const labo = sp.bilan ? Object.fromEntries(S.BILAN.flatMap(gr => gr.items).map(l => [l, S.LABO[l] || null])) : {};
      const items = [...new Set(demandes)].slice(0, 80).map(l => {
        const e = sp.examens.find(z => z.l === l);
        if (e) return { l, code: e.code || null };
        if (l in labo) return { l, code: labo[l], bilan: true };
        throw err(400, `Examen inconnu pour cette spécialité : ${l}.`);
      });
      return { items, autres, renseignement: t(x.renseignement, 'Renseignement clinique', 2000), urgent: !!x.urgent };
    }
    case 'lunettes': {
      const oeil = o => Object.fromEntries(['sphere', 'cylindre', 'axe', 'addition'].map(k => [k, t((o || {})[k], 'Réfraction', 12)]));
      return { od: oeil(x.od), og: oeil(x.og), ecart: t(x.ecart, 'Écart pupillaire', 12), vision: t(x.vision, 'Vision', 40), verres: t(x.verres, 'Type de verres', 60),
        options: (Array.isArray(x.options) ? x.options : []).map(o => t(o, 'Option', 60)).slice(0, 10), remarques: t(x.remarques, 'Remarques', 500) };
    }
    case 'certificat': {
      if (x.sous_type === 'arret') {
        const jours = entier(x.jours, { label: 'Nombre de jours d’arrêt', min: 1, max: 365 }), debut = date(x.debut, { label: 'Début de l’arrêt' });
        return { sous_type: 'arret', jours, debut, reprise: ajouterJours(debut, jours), motif_interne: t(x.motif_interne, 'Motif', 300) };
      }
      return { sous_type: 'medical', objet: t(x.objet, 'Objet du certificat', 120, true), constat: t(x.constat, 'Constatations', 3000, true), conclusion: t(x.conclusion, 'Conclusion', 3000, true) };
    }
    case 'compte_rendu': {
      const modele = sp.comptes_rendus.find(c => c.cle === x.cle);
      if (!modele) throw err(400, 'Type de compte rendu inconnu pour cette spécialité.');
      const champs = Object.fromEntries(modele.champs.map(c => [c.k, t((x.champs || {})[c.k], c.l, 5000)]));
      if (!Object.values(champs).some(Boolean)) throw err(400, 'Le compte rendu est vide.');
      return { cle: modele.cle, titre: modele.l, champs };
    }
    case 'orientation':
      return { destinataire: t(x.destinataire, 'Destinataire', 160, true), motif: t(x.motif, 'Motif et renseignements', 3000, true), urgent: !!x.urgent };
    case 'note':
      return { texte: t(x.texte, 'Note', 5000, true) };
    case 'conseils': {
      /* Le texte des fiches est figé dans le document : ce qui a été remis au patient reste traçable. */
      const codes = Array.isArray(x.codes) ? [...new Set(x.codes.map(String))] : [];
      const fiches = sp.conseils.filter(f => codes.includes(f.code));
      if (!fiches.length || fiches.length !== codes.length) throw err(400, 'Choisissez une ou plusieurs fiches conseils de la spécialité.');
      return { fiches };
    }
    default: throw err(400, 'Type de document inconnu.');
  }
}
function creerDocument(db, u, d) {
  const type = String(d.type || '');
  if (!TYPES_DOC[type]) throw err(400, 'Type de document inconnu.');
  const c = d.consultation_id ? lireConsultation(db, Number(d.consultation_id)) : null;
  if (!c) throw err(400, 'Un document médical se rattache à une consultation.');
  const sp = S.SPECIALITES[c.specialite];
  habilite(u, c.specialite);
  if (type === 'note' ? !c.valide_le : !sp.documents.includes(type)) throw err(400, type === 'note' ? 'La note complémentaire s’ajoute à une consultation validée.' : 'Document non prévu pour cette spécialité.');
  const donnees = validerDocument(type, sp, donneesValides(d.donnees, 100000).o);
  const v = R.passage(db, c.passage_id);
  return db.transaction(() => {
    const [prefixe] = TYPES_DOC[type], annee = new Date().getFullYear();
    const numero = `${prefixe}-${annee}-${pad(R.suivant(db, `document:${prefixe}:${annee}`), 5)}`;
    let facturables = [];
    if (type === 'examens') {
      facturables = donnees.items.filter(i => i.code).map(i => ({ i, acte: db.prepare('SELECT * FROM actes WHERE code = ? AND actif = 1').get(i.code) })).filter(x => x.acte);
      if (facturables.length && jourDe(v.cree_le) !== jourLocal() && !v.urgent) throw err(409, 'Passage clos : faites ouvrir un passage à l’accueil pour facturer ces examens.');
      for (const x of facturables) { x.i.facture = true; R.creerBon(db, u, v, { nature: 'acte', ref: x.acte }, 1, 'medecin'); }
    }
    const id = db.prepare('INSERT INTO documents(numero, type, patient_id, passage_id, consultation_id, specialite, medecin_id, cree_le, donnees) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(numero, type, c.patient_id, c.passage_id, c.id, c.specialite, u.id, maintenant(), JSON.stringify(donnees)).lastInsertRowid;
    R.journal(db, u, 'Consultation', 'Document émis', `${numero} (${TYPES_DOC[type][1].toLowerCase()}) pour ${R.nomPatient(R.patient(db, c.patient_id))}${facturables.length ? `, ${facturables.length} examen(s) envoyé(s) à la caisse` : ''}`);
    return { id, numero, factures: facturables.length };
  })();
}
/* Poids et taille du patient le jour du document (constantes de la consultation), utiles sur les ordonnances. */
function mesuresDocument(db, d) {
  const c = d.consultation_id ? db.prepare('SELECT donnees FROM consultations WHERE id = ?').get(d.consultation_id) : null;
  const o = c ? JSON.parse(c.donnees || '{}') : {};
  return { poids: o.poids || null, taille: o.taille || null };
}
function lireDocument(db, id) {
  const d = db.prepare('SELECT d.*, u.nom AS medecin, u.specialites AS medecin_specialites, u.ordre AS medecin_ordre FROM documents d LEFT JOIN utilisateurs u ON u.id = d.medecin_id WHERE d.id = ?').get(id);
  if (!d) throw err(404, 'Document introuvable.');
  const p = R.params(db);
  return { ...d, donnees: JSON.parse(d.donnees), libelle: TYPES_DOC[d.type][1], patient: R.patient(db, d.patient_id), passage: (R.passage(db, d.passage_id) || {}).numero, mesures: mesuresDocument(db, d),
    etablissement: { raison: p.raison, forme: p.forme, adresse: p.adresse, rccm: p.rccm, ncc: p.ncc, telephone: p.telephone, slogan: p.slogan }, formation: !!p.formation };
}

/* Rendez-vous : posés par le médecin ou l'accueil, suivis par l'accueil. */
function creerRdv(db, u, d) {
  const p = R.patient(db, Number(d.patient_id));
  if (!p || p.fusionne_dans) throw err(404, 'Patient introuvable.');
  const jour = date(d.date, { label: 'Date du rendez-vous' });
  if (jour < jourLocal()) throw err(400, 'La date du rendez-vous est passée.');
  const heure = texte(d.heure, { label: 'Heure', max: 5 });
  if (heure && !/^([01]\d|2[0-3]):[0-5]\d$/.test(heure)) throw err(400, 'Heure invalide (HH:MM).');
  const specialite = texte(d.specialite, { label: 'Spécialité', max: 60 });
  if (specialite && !S.SPECIALITES[specialite]) throw err(400, 'Spécialité inconnue.');
  const medecin = u.roles.includes('medecin') ? u.id : (d.medecin_id ? Number(d.medecin_id) : null);
  const motif = texte(d.motif, { label: 'Motif', max: 160 });
  return db.transaction(() => {
    const id = db.prepare('INSERT INTO rdv(patient_id, specialite, medecin_id, date, heure, motif, cree_par, cree_le) VALUES (?,?,?,?,?,?,?,?)')
      .run(p.id, specialite || null, medecin, jour, heure || null, motif || null, u.id, maintenant()).lastInsertRowid;
    R.journal(db, u, u.roles.includes('medecin') ? 'Consultation' : 'Accueil', 'Rendez-vous', `${R.nomPatient(p)} le ${jour}${heure ? ' à ' + heure : ''}${specialite ? ', ' + specialite.toLowerCase() : ''}`);
    return { id };
  })();
}
function listerRdv(db, du, au) {
  return db.prepare(`SELECT r.*, p.nom, p.prenoms, p.ipp, p.telephone, u.nom AS medecin FROM rdv r JOIN patients p ON p.id = r.patient_id
    LEFT JOIN utilisateurs u ON u.id = r.medecin_id WHERE r.date >= ? AND r.date <= ? ORDER BY r.date, r.heure`).all(du, au);
}
function statutRdv(db, u, id, statut) {
  if (!STATUTS_RDV.includes(statut)) throw err(400, 'Statut inconnu.');
  const r = db.prepare('SELECT * FROM rdv WHERE id = ?').get(id);
  if (!r) throw err(404, 'Rendez-vous introuvable.');
  db.transaction(() => {
    db.prepare('UPDATE rdv SET statut = ? WHERE id = ?').run(statut, id);
    R.journal(db, u, 'Accueil', 'Rendez-vous mis à jour', `${R.nomPatient(R.patient(db, r.patient_id))} le ${r.date} : ${statut}`);
  })();
}

/* Photos et documents scannés du dossier : format vérifié sur le contenu réel, jamais modifiés ni supprimés. */
const SIGNATURES = {
  'image/jpeg': b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/png': b => b.subarray(0, 4).toString('hex') === '89504e47',
  'image/webp': b => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP',
  'application/pdf': b => b.subarray(0, 4).toString() === '%PDF'
};
const TAILLE_MAX_PIECE = 3 * 1024 * 1024;
function controlerPiece(mime, contenu) {
  if (!SIGNATURES[mime]) throw err(400, 'Format accepté : photo (JPEG, PNG, WebP) ou PDF.');
  const buf = Buffer.isBuffer(contenu) ? contenu : Buffer.from(String(contenu || ''), 'base64');
  if (!buf.length) throw err(400, 'Fichier vide.');
  if (buf.length > TAILLE_MAX_PIECE) throw err(413, 'Fichier trop lourd : 3 Mo au maximum.');
  if (!SIGNATURES[mime](buf)) throw err(400, 'Le contenu du fichier ne correspond pas à son format.');
  return buf;
}
function inserePiece(db, { patient_id, consultation_id, specialite, nom, mime, buf, legende, medecin_id, cree_le }) {
  return db.prepare('INSERT INTO pieces(patient_id, consultation_id, specialite, nom, mime, taille, contenu, legende, medecin_id, cree_le) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .run(patient_id, consultation_id || null, specialite || null, nom, mime, buf.length, buf, legende || null, medecin_id, cree_le || maintenant()).lastInsertRowid;
}
function ajouterPiece(db, u, d) {
  const c = lireConsultation(db, Number(d.consultation_id));
  habilite(u, c.specialite);
  const mime = String(d.mime || ''), buf = controlerPiece(mime, d.contenu);
  const nom = texte(d.nom, { label: 'Nom du fichier', max: 120 }) || 'piece', legende = texte(d.legende, { label: 'Légende', max: 300 });
  return db.transaction(() => {
    const id = inserePiece(db, { patient_id: c.patient_id, consultation_id: c.id, specialite: c.specialite, nom, mime, buf, legende, medecin_id: u.id });
    R.journal(db, u, 'Consultation', 'Pièce ajoutée au dossier', `${nom} (${Math.round(buf.length / 1024)} Ko) pour ${R.nomPatient(R.patient(db, c.patient_id))}`);
    return { id };
  })();
}
function lirePiece(db, id) {
  const p = db.prepare('SELECT * FROM pieces WHERE id = ?').get(id);
  if (!p) throw err(404, 'Pièce introuvable.');
  return p;
}

/* La pharmacie ne reçoit que les lignes de médicaments, sans diagnostic. */
function prescriptionsPassage(db, passageId) {
  return db.prepare("SELECT d.numero, d.donnees, d.cree_le, u.nom AS medecin FROM documents d LEFT JOIN utilisateurs u ON u.id = d.medecin_id WHERE d.passage_id = ? AND d.type = 'ordonnance' ORDER BY d.id")
    .all(passageId).map(d => ({ numero: d.numero, medecin: d.medecin, cree_le: d.cree_le, lignes: JSON.parse(d.donnees).lignes }));
}

module.exports = { modifierConsultation, versionsConsultation, fileInfirmerie, listerMedecins, enregistrerConstantes, controlerPiece, inserePiece, ajouterPiece, lirePiece, TYPES_DOC, fileMedecin, ouvrirConsultation, lireConsultation, enregistrerConsultation, validerConsultation, dossierMedical, creerDocument, lireDocument, creerRdv, listerRdv, statutRdv, prescriptionsPassage, specialitesDe };
