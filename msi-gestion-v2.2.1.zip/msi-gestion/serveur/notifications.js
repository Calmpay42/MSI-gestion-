'use strict';
/* Notifications en temps réel (v1.6). Chaque notification est calculée quand le poste de son destinataire se synchronise
   (toutes les quelques secondes) et porte une clé unique par événement : jamais de doublon, rien de perdu pendant une absence.
   Les écrans la signalent par un message, un son et, si l'utilisateur l'autorise, une notification du navigateur. */
const R = require('./regles');
const CL = require('./clinique');
const { maintenant, jourLocal, bornesJour, ajouterJours } = require('./outils');
const { peut } = require('./auth');
const TP = require('./tiers-payant');

const TITRES_DEMANDE = { remise: 'Remise à valider', annulation: 'Annulation de reçu à valider', remboursement: 'Remboursement à valider' };
const chambreDe = (db, hid) => (db.prepare('SELECT c.code FROM hospitalisation_chambres hc JOIN chambres c ON c.id = hc.chambre_id WHERE hc.hospitalisation_id = ? ORDER BY hc.id DESC LIMIT 1').get(hid) || {}).code || '?';
const fr = iso => String(iso || '').slice(0, 10).split('-').reverse().join('/');
const TYPES_PL = { garde: 'Garde', consultation: 'Consultation', permanence: 'Permanence', astreinte: 'Astreinte', conge: 'Congé', absence: 'Absence' };
const MOIS_FR = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
const moisFr = p => `${MOIS_FR[Number(p.slice(5, 7)) - 1]} ${p.slice(0, 4)}`;
const fcfaN = n => `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} FCFA`;

function ajouter(db, u, cle, n) {
  db.prepare('INSERT OR IGNORE INTO notifications(utilisateur_id, type, titre, message, onglet, prioritaire, cle, cree_le) VALUES (?,?,?,?,?,?,?,?)')
    .run(u.id, n.type, n.titre, n.message || null, n.onglet || null, n.prioritaire ? 1 : 0, cle, maintenant());
}

function generer(db, u, produits) {
  const jour = jourLocal(), [debut] = bornesJour(jour);
  db.prepare('DELETE FROM notifications WHERE utilisateur_id = ? AND cree_le < ? AND (lu_le IS NOT NULL OR cree_le < ?)')
    .run(u.id, bornesJour(ajouterJours(jour, -30))[0], bornesJour(ajouterJours(jour, -60))[0]);
  if (peut(u, 'consulter')) {
    /* Patients orientés vers ce médecin (par l'infirmerie, ou dès l'accueil), pas encore reçus. */
    const vs = db.prepare(`SELECT v.id, v.patient_id, v.motif, c.prioritaire, c.alertes, c.maj_le FROM passages v LEFT JOIN constantes c ON c.passage_id = v.id
      WHERE v.cree_le >= ? AND (c.medecin_id = ? OR (c.id IS NULL AND v.medecin_id = ?)) AND NOT EXISTS (SELECT 1 FROM consultations k WHERE k.passage_id = v.id)`).all(debut, u.id, u.id);
    for (const v of vs) {
      const alertes = v.alertes ? JSON.parse(v.alertes) : [];
      ajouter(db, u, `orientation:${v.id}:${v.maj_le || 'accueil'}`, {
        type: 'patient', titre: v.prioritaire ? 'Patient prioritaire' : 'Nouveau patient en salle d’attente', onglet: 'consultations', prioritaire: !!v.prioritaire,
        message: `${R.nomPatient(R.patient(db, v.patient_id))}${v.motif ? ', ' + v.motif : ''}${alertes.length ? ' : ' + alertes.map(a => `${a.texte} (${a.valeur})`).join(', ') : ''}`
      });
    }
    /* Résultats validés pour les patients de ce médecin. */
    const rs = db.prepare(`SELECT r.id, r.libelle, r.donnees, r.patient_id FROM resultats r WHERE r.statut = 'valide' AND r.valide_le >= ?
      AND EXISTS (SELECT 1 FROM consultations k WHERE k.passage_id = r.passage_id AND k.medecin_id = ?)`).all(debut, u.id);
    for (const r of rs) {
      const anormal = JSON.parse(r.donnees || '[]').some(l => l.drapeau);
      ajouter(db, u, `resultat:${r.id}`, { type: 'resultat', titre: anormal ? 'Résultats anormaux' : 'Résultats prêts', onglet: 'consultations', prioritaire: anormal,
        message: `${R.nomPatient(R.patient(db, r.patient_id))} : ${r.libelle}${anormal ? ', valeurs hors normes' : ''}` });
    }
  }
  if (peut(u, 'consulter')) {
    for (const h of db.prepare("SELECT id, patient_id, motif FROM hospitalisations WHERE medecin_id = ? AND statut = 'en_cours'").all(u.id)) {
      ajouter(db, u, `hosp-admission:${h.id}`, { type: 'hospitalisation', titre: 'Patient hospitalisé', onglet: 'hospitalisation',
        message: `${R.nomPatient(R.patient(db, h.patient_id))}, chambre ${chambreDe(db, h.id)} : ${h.motif}` });
    }
    for (const s of db.prepare(`SELECT s.id, s.alertes, h.id AS hid, h.patient_id FROM soins_hospitalisation s JOIN hospitalisations h ON h.id = s.hospitalisation_id
      WHERE h.medecin_id = ? AND h.statut = 'en_cours' AND s.type = 'constantes' AND s.alertes IS NOT NULL AND s.alertes != '[]' AND s.realise_le >= ?`).all(u.id, debut)) {
      ajouter(db, u, `hosp-alerte:${s.id}`, { type: 'hospitalisation', titre: 'Alerte en hospitalisation', onglet: 'hospitalisation', prioritaire: true,
        message: `${R.nomPatient(R.patient(db, s.patient_id))}, chambre ${chambreDe(db, s.hid)} : ${JSON.parse(s.alertes).map(a => `${a.texte} (${a.valeur})`).join(', ')}` });
    }
  }
  if (peut(u, 'constantes')) {
    for (const a of db.prepare(`SELECT hi.id, h.id AS hid, h.patient_id, h.motif FROM hospitalisation_infirmiers hi JOIN hospitalisations h ON h.id = hi.hospitalisation_id
      WHERE hi.infirmier_id = ? AND hi.retire_le IS NULL AND h.statut = 'en_cours'`).all(u.id)) {
      ajouter(db, u, `hosp-assigne:${a.id}`, { type: 'hospitalisation', titre: 'Patient hospitalisé à votre charge', onglet: 'hospitalisation',
        message: `${R.nomPatient(R.patient(db, a.patient_id))}, chambre ${chambreDe(db, a.hid)} : ${a.motif}` });
    }
  }
  if (peut(u, 'constantes')) {
    for (const x of CL.fileInfirmerie(db).filter(y => y.statut === 'a_prendre')) {
      ajouter(db, u, `infirmerie:${x.passage_id}`, { type: 'patient', titre: x.urgent ? 'Urgence à prendre en charge' : 'Patient à prendre en charge', onglet: 'infirmerie', prioritaire: x.urgent,
        message: `${R.nomPatient(x.patient)}${x.specialite ? ', ' + x.specialite.toLowerCase() : ''}${x.motif ? ', ' + x.motif : ''}` });
    }
  }
  if (peut(u, 'laboratoire')) {
    const bs = db.prepare(`SELECT b.id, b.libelle, v.patient_id FROM bons b JOIN actes a ON a.id = b.acte_id JOIN passages v ON v.id = b.passage_id
      WHERE a.famille = 'Laboratoire' AND b.annule = 0 AND (b.paye = 1 OR b.gratuit = 1 OR b.urgent = 1) AND v.cree_le >= ? AND NOT EXISTS (SELECT 1 FROM resultats r WHERE r.bon_id = b.id)`).all(debut);
    for (const b of bs) ajouter(db, u, `labo:${b.id}`, { type: 'examen', titre: 'Examen à réaliser', onglet: 'laboratoire', message: `${R.nomPatient(R.patient(db, b.patient_id))} : ${b.libelle}` });
  }
  if (peut(u, 'pharmacie')) {
    for (const p of produits || []) {
      if (p.actif && (p.stock.rupture || p.stock.sous_seuil)) ajouter(db, u, `stock:${p.id}:${jour}`, { type: 'stock', titre: p.stock.rupture ? 'Rupture de stock' : 'Stock bas', onglet: 'pharmacie',
        prioritaire: !!p.stock.rupture, message: `${p.nom} : ${p.stock.libre} disponible${p.stock.libre > 1 ? 's' : ''}, seuil ${p.seuil}` });
    }
    const lots = db.prepare(`SELECT l.id, l.numero, l.peremption, l.quantite, p.nom FROM lots l JOIN produits p ON p.id = l.produit_id
      WHERE l.quantite > 0 AND p.actif = 1 AND l.peremption <= ?`).all(ajouterJours(jour, 90));
    for (const l of lots) {
      const perime = l.peremption < jour;
      ajouter(db, u, `${perime ? 'perime' : 'peremption'}:${l.id}`, { type: 'peremption', titre: perime ? 'Lot périmé à retirer' : 'Péremption dans moins de 3 mois', onglet: 'pharmacie', prioritaire: perime,
        message: `${l.nom}, lot ${l.numero} (${l.quantite} unité${l.quantite > 1 ? 's' : ''}) : ${perime ? 'périmé depuis le' : 'périme le'} ${fr(l.peremption)}` });
    }
  }
  if (peut(u, 'caisse')) {
    /* v1.7 : la caisse est prévenue des admissions (caution) et des sorties à régler (quitus). */
    for (const h of db.prepare("SELECT id, numero, patient_id FROM hospitalisations WHERE statut = 'en_cours' AND admis_le >= ?").all(bornesJour(ajouterJours(jour, -2))[0]))
      ajouter(db, u, `hosp-caution:${h.id}`, { type: 'hospitalisation', titre: 'Admission : caution à encaisser', onglet: 'caisse', message: `${R.nomPatient(R.patient(db, h.patient_id))}, séjour ${h.numero}` });
    for (const h of db.prepare("SELECT id, numero, patient_id FROM hospitalisations WHERE statut = 'sortie' AND quitus_le IS NULL").all())
      ajouter(db, u, `hosp-sortie:${h.id}`, { type: 'hospitalisation', titre: 'Sortie à régler', onglet: 'hospitalisation', prioritaire: true,
        message: `${R.nomPatient(R.patient(db, h.patient_id))}, séjour ${h.numero} : encaisser le solde puis délivrer le quitus` });
  }
  /* v1.8 : créneaux à venir de l'employé lié au compte, paie à valider, fins de CDD. */
  const emp = db.prepare('SELECT id FROM employes WHERE utilisateur_id = ? AND actif = 1').get(u.id);
  if (emp) for (const c of db.prepare('SELECT id, jour, type, debut, fin FROM planning WHERE employe_id = ? AND annule_le IS NULL AND jour BETWEEN ? AND ?').all(emp.id, jour, ajouterJours(jour, 14)))
    ajouter(db, u, `planning:${c.id}`, { type: 'planning', titre: `Planning : ${(TYPES_PL[c.type] || c.type).toLowerCase()} le ${fr(c.jour)}`, message: `De ${c.debut} à ${c.fin}` });
  if (peut(u, 'paie_valider')) for (const p of db.prepare("SELECT periode, COUNT(*) n, SUM(net) net FROM paies WHERE statut = 'prepare' GROUP BY periode").all())
    ajouter(db, u, `paies:${p.periode}:${p.n}`, { type: 'paie', titre: 'Paie à valider', onglet: 'rh', message: `${p.n} bulletin${p.n > 1 ? 's' : ''} de ${moisFr(p.periode)}, net total ${fcfaN(p.net)}` });
  if (peut(u, 'rh_gerer')) for (const e of db.prepare("SELECT id, nom, prenoms, fin_contrat FROM employes WHERE actif = 1 AND contrat = 'CDD' AND fin_contrat BETWEEN ? AND ?").all(jour, ajouterJours(jour, 30)))
    ajouter(db, u, `cdd:${e.id}:${e.fin_contrat}`, { type: 'rh', titre: 'Fin de CDD dans moins de 30 jours', onglet: 'rh', message: `${e.nom}${e.prenoms ? ' ' + e.prenoms : ''} : fin le ${fr(e.fin_contrat)}` });
  if (peut(u, 'tiers_payant') && Number(jour.slice(8, 10)) <= 10) {
    /* v1.9 : rappel de clôture du mois précédent pendant les 10 premiers jours du mois, tant qu'il reste des prises en charge à facturer. */
    const [ya, ma] = jour.slice(0, 7).split('-').map(Number), prec = ma === 1 ? `${ya - 1}-12` : `${ya}-${String(ma - 1).padStart(2, '0')}`, reste = TP.apercuMois(db, prec);
    if (reste.length) ajouter(db, u, `cloture:${prec}`, { type: 'facturation', titre: 'Clôture mensuelle à faire', onglet: 'tiers',
      message: `${TP.moisFr(prec)} : ${reste.length} assureur${reste.length > 1 ? 's' : ''} à facturer, ${String(reste.reduce((s, x) => s + x.montant, 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} FCFA` });
  }
  if (peut(u, 'supprimer')) {
    /* v2.2 : l'administrateur reçoit les demandes de suppression et d'annulation de reçus. */
    for (const d of db.prepare("SELECT d.id, d.type, d.donnees, d.motif, u.nom AS demandeur FROM demandes d LEFT JOIN utilisateurs u ON u.id = d.demandeur_id WHERE d.statut = 'en_attente' AND d.type IN ('suppression', 'annulation')").all()) {
      const x = JSON.parse(d.donnees);
      ajouter(db, u, `suppression:${d.id}`, { type: 'demande', titre: d.type === 'annulation' ? 'Annulation de reçu à décider' : 'Demande de suppression', onglet: 'suppressions',
        message: `${d.demandeur || 'Agent'}${x.description ? ' : ' + x.description : ''}${d.motif ? '. Motif : ' + d.motif : ''}` });
    }
  }
  /* v2.2 : chacun est prévenu de la décision prise sur ses demandes. */
  for (const d of db.prepare("SELECT d.id, d.type, d.statut, d.donnees, d.reponse FROM demandes d WHERE d.demandeur_id = ? AND d.statut IN ('validee', 'refusee') AND d.decide_le >= ?").all(u.id, bornesJour(ajouterJours(jour, -7))[0])) {
    const x = JSON.parse(d.donnees), quoi = x.description || (d.type === 'annulation' ? 'annulation de reçu' : d.type);
    ajouter(db, u, `decision:${d.id}`, { type: 'demande', titre: d.statut === 'validee' ? 'Demande acceptée' : 'Demande refusée', prioritaire: d.statut === 'refusee',
      message: `${quoi}${d.reponse ? '. Réponse : ' + d.reponse : ''}` });
  }
  if (peut(u, 'valider')) {
    const ds = db.prepare("SELECT d.id, d.type, d.motif, u.nom AS demandeur FROM demandes d LEFT JOIN utilisateurs u ON u.id = d.demandeur_id WHERE d.statut = 'en_attente' AND d.type NOT IN ('suppression', 'annulation')").all();
    for (const d of ds) ajouter(db, u, `demande:${d.id}`, { type: 'demande', titre: TITRES_DEMANDE[d.type] || 'Demande à valider', onglet: 'direction', message: `${d.demandeur || 'Agent'}${d.motif ? ' : ' + d.motif : ''}` });
  }
}

function lister(db, u) {
  return db.prepare('SELECT id, type, titre, message, onglet, prioritaire, cree_le, lu_le FROM notifications WHERE utilisateur_id = ? ORDER BY id DESC LIMIT 40').all(u.id);
}
function marquerLues(db, u, ids) {
  if (ids === 'tout') db.prepare('UPDATE notifications SET lu_le = ? WHERE utilisateur_id = ? AND lu_le IS NULL').run(maintenant(), u.id);
  else for (const id of [].concat(ids || [])) db.prepare('UPDATE notifications SET lu_le = ? WHERE id = ? AND utilisateur_id = ? AND lu_le IS NULL').run(maintenant(), Number(id), u.id);
  return { non_lues: db.prepare('SELECT COUNT(*) n FROM notifications WHERE utilisateur_id = ? AND lu_le IS NULL').get(u.id).n };
}
module.exports = { generer, lister, marquerLues };
