'use strict';
/* Poste Accueil : identification du patient, droits, ouverture du passage (ACC-01 à ACC-10). */
function covBadge(p) {
  const c = p.couverture || { etat: 'aucune' };
  if (c.etat === 'aucune') return '<span class="badge b-muted">Non assuré</span>';
  if (c.etat === 'expiree') return `<span class="badge b-bad">${esc(c.assureur)}, droits expirés</span>`;
  if (c.etat === 'inactive') return `<span class="badge b-bad">${esc(c.assureur)}, convention inactive</span>`;
  return `<span class="badge">${esc(c.assureur)} ${p.taux}&nbsp;%</span>`;
}
const actesConsultation = () => E.actes.filter(a => a.famille === 'Consultation' && a.actif);
const TYPES_OUVRABLES = ['consultation', 'controle', 'urgence', 'soins', 'labo', 'pharma'];

function vAccueil() {
  if (UI.acc.res === null) { UI.acc.res = []; rechercher(''); }
  return `<div class="view-head"><div><h1>Accueil</h1><p class="lead">Retrouver le patient, vérifier ses droits, ouvrir le passage.</p></div>
    ${peut('patient_ecrire') ? `<div class="head-actions"><button class="btn" data-action="nouveauPatient">${icon('plus', 18)}Nouveau patient</button></div>` : ''}</div>
    <div class="grid-2"><section><div class="panel">
      ${champ('Rechercher un patient', `<input id="acc-q" type="search" value="${esc(UI.acc.q)}" placeholder="Nom, téléphone, IPP ou naissance" autocomplete="off" data-input="accRecherche">`, 'Date de naissance au format jj/mm/aaaa.')}
      <div id="acc-res">${accResultats()}</div></div>${rdvAccueil()}</section>
    <section id="acc-detail">${UI.acc.fiche ? accFiche() : vide('Aucun patient sélectionné', 'Recherchez le patient, ou créez son dossier s’il vient pour la première fois.')}</section></div>`;
}
function rdvAccueil() {
  const l = (E.rdv || []).filter(r => r.statut === 'prevu');
  if (!peut('rdv_lire') || !l.length) return '';
  return `<div class="panel"><h2>Rendez-vous à venir</h2><ul class="plist">${l.slice(0, 20).map(r => `<li><div><strong>${esc(r.nom + ' ' + r.prenoms)}</strong>
    <div class="muted">${r.date === todayISO() ? 'Aujourd’hui' : fmtDate(r.date)}${r.heure ? ' à ' + esc(r.heure) : ''}${r.specialite ? ', ' + esc(lcFirst(r.specialite)) : ''}${r.medecin ? ', ' + esc(r.medecin) : ''}${r.telephone ? ', ' + esc(r.telephone) : ''}</div></div>
    <div class="pl-side">${peut('rdv_ecrire') ? `<button class="btn btn-sm btn-ghost" data-action="rdvMessage" data-id="${r.id}">Prévenir</button>` : ''}${peut('rdv_ecrire') && r.date === todayISO() ? `<button class="btn btn-sm btn-ghost" data-action="rdvStatut" data-id="${r.id}" data-s="honore">Arrivé</button><button class="btn btn-sm btn-ghost" data-action="rdvStatut" data-id="${r.id}" data-s="absent">Absent</button>` : ''}</div></li>`).join('')}</ul></div>`;
}
function accResultats() {
  const res = UI.acc.res || [];
  if (!res.length) return `<p class="muted">${UI.acc.q ? 'Aucun patient trouvé. Vérifiez l’orthographe ou cherchez par téléphone.' : 'Aucun dossier pour l’instant.'}</p>`;
  const sel = UI.acc.fiche && UI.acc.fiche.patient.id;
  return `<ul class="list">${res.map(p => `<li><button class="row-btn" data-action="accChoisir" data-id="${p.id}"${sel === p.id ? ' aria-current="true"' : ''}>
    <span class="rb-main"><strong>${esc(nomPatient(p))}</strong><span class="muted">${esc(p.ipp)}${p.naissance ? ', ' + age(p.naissance) + ' ans' : ''}${p.telephone ? ', ' + esc(p.telephone) : ''}</span></span>
    <span class="rb-side">${covBadge(p)}${p.impaye ? `<span class="badge b-bad">Impayé ${money(p.impaye)}</span>` : ''}${p.provisoire ? '<span class="badge b-warn">Identité provisoire</span>' : ''}</span></button></li>`).join('')}</ul>`;
}
let minuterieRecherche = null;
function rechercher(q) {
  clearTimeout(minuterieRecherche);
  minuterieRecherche = setTimeout(async () => {
    try {
      UI.acc.res = await api('GET', '/api/patients?q=' + encodeURIComponent(q));
      const el = $('#acc-res');
      if (el) el.innerHTML = accResultats();
    } catch (e) { if (e.status !== 401) toast(e.message, 'bad'); }
  }, 220);
}
async function chargerFiche(id) {
  const avant = UI.acc.fiche && UI.acc.fiche.patient ? UI.acc.fiche.patient.id : null;
  UI.acc.fiche = await api('GET', '/api/patients/' + id);
  /* Aucune consultation n'est choisie d'office : le choix se fait patient par patient. */
  if (avant !== UI.acc.fiche.patient.id || (UI.acc.acteId && !actesConsultation().some(a => String(a.id) === String(UI.acc.acteId)))) UI.acc.acteId = '';
  if (avant !== UI.acc.fiche.patient.id) { UI.acc.medecin = ''; UI.acc.motif = ''; }
}
function accFiche() {
  const f = UI.acc.fiche, p = f.patient, c = p.couverture, t = UI.acc.type;
  const acte = E.actes.find(a => String(a.id) === String(UI.acc.acteId));
  let hint = '';
  if (t === 'controle' && acte) {
    const ct = f.controles[acte.specialite];
    hint = ct && ct.gratuit
      ? `Dernière consultation payée en ${lcFirst(acte.specialite)} il y a ${ct.jours} ${pl(ct.jours, 'jour')} : contrôle gratuit (délai de ${f.delai_controle} jours).`
      : `Aucune consultation payée en ${lcFirst(acte.specialite)} depuis ${f.delai_controle} jours : le contrôle sera facturé au tarif normal.`;
  } else if (t === 'urgence') hint = 'Prise en charge immédiate : le bon passe « à régulariser » et reste suivi par la direction jusqu’au paiement.';
  else if (t === 'soins' || t === 'labo' || t === 'pharma') hint = 'Aucun bon à l’ouverture : la caisse ajoute ensuite les actes prescrits, ou la pharmacie saisit l’ordonnance.';
  const besoinActe = t === 'consultation' || t === 'controle';
  const niveau = c.etat === 'valide' ? c.niveau : 'non';
  return `<div class="panel">
    <div class="pat-head"><div><h2 class="pat-name">${esc(nomPatient(p))}</h2><p class="muted">${esc(p.ipp)}${p.sexe ? ', ' + (p.sexe === 'F' ? 'femme' : 'homme') : ''}${p.naissance ? ', ' + age(p.naissance) + ' ans' : ''}</p></div>${covBadge(p)}</div>
    <dl class="kv"><div><dt>Téléphone</dt><dd>${esc(p.telephone || 'Non renseigné')}</dd></div><div><dt>Commune</dt><dd>${esc(p.commune || 'Non renseignée')}</dd></div>
      <div><dt>Personne à prévenir</dt><dd>${esc(p.contact || 'Non renseignée')}</dd></div>
      <div><dt>Couverture</dt><dd>${c.etat === 'aucune' ? 'Aucune' : `${esc(c.assureur)}, n° ${esc(p.num_assure)}, ${p.taux}&nbsp;%, jusqu’au ${fmtDate(p.validite)}`}</dd></div></dl>
    ${f.fusionne_dans ? `<div class="notice bad">Dossier fusionné dans ${esc(f.fusionne_dans.ipp)} ${esc(nomPatient(f.fusionne_dans))} : utilisez ce dernier.</div>` : ''}
    ${p.provisoire ? '<div class="notice warn">Identité provisoire (urgence) : complétez le dossier avant la sortie du patient.</div>' : ''}
    ${p.impaye ? `<div class="notice bad">Impayé antérieur de ${money(p.impaye)} : il apparaîtra à la caisse avec les bons du jour.</div>` : ''}
    ${c.etat === 'expiree' ? `<div class="notice bad">Droits ${esc(c.assureur)} expirés le ${fmtDate(p.validite)} : les actes seront facturés comme non assuré.</div>` : ''}
    <div class="row-actions">${peut('patient_ecrire') && !f.fusionne_dans ? '<button class="btn btn-ghost btn-sm" data-action="modifierPatient">Modifier le dossier</button>' : ''}${peut('rdv_ecrire') && !f.fusionne_dans ? '<button class="btn btn-ghost btn-sm" data-action="rdvNouveau">Prendre un rendez-vous</button>' : ''}${peut('hosp_admettre') && !f.fusionne_dans ? '<button class="btn btn-ghost btn-sm" data-action="hospDepuisAccueil">Hospitaliser</button>' : ''}
      ${!peut('patient_fusionner') && peut('suppression_demander') && !f.fusionne_dans ? '<button class="btn btn-ghost btn-sm" data-action="doublonSignaler">Signaler un doublon</button>' : ''}${peut('patient_fusionner') && !f.fusionne_dans ? '<button class="btn btn-ghost btn-sm" data-action="fusionPatient">Fusionner ce doublon</button>' : ''}</div>
  </div>
  ${peut('passage_ouvrir') && !f.fusionne_dans ? `<div class="panel">
    <h2>Ouvrir un passage</h2>
    <div class="seg" role="group" aria-label="Type de passage">${TYPES_OUVRABLES.map(x => `<button data-action="accType" data-type="${x}" aria-pressed="${t === x}">${esc(typeLibelle(x))}</button>`).join('')}</div>
    ${besoinActe ? champ('Consultation', `<select id="acc-acte" data-change="accActe"><option value=""${UI.acc.acteId ? '' : ' selected'}>Choisir la consultation</option>${actesConsultation().map(a => `<option value="${a.id}"${String(UI.acc.acteId) === String(a.id) ? ' selected' : ''}>${esc(a.specialite)}, ${money(a['prix_' + niveau])}${a.a_valider && !E.formation ? ' (tarif à valider)' : ''}</option>`).join('')}</select>`) : ''}
    ${c.etat === 'valide' ? champ(`N° d’accord ${esc(c.assureur)}`, `<input id="acc-accord" value="${esc(UI.acc.accord)}" placeholder="N° d’accord ou de bon de prise en charge" autocomplete="off" data-input="accAccord">`, 'Sans n° d’accord, le passage est facturé comme non assuré.') : ''}
    ${hint ? `<p class="hint">${esc(hint)}</p>` : ''}
    ${champsAdmission()}<button class="btn btn-block" data-action="ouvrirPassage">Ouvrir le passage</button>
  </div>` : ''}
  <div class="panel"><h2>Historique des passages</h2>${historique(f.passages)}</div>`;
}
function historique(list) {
  if (!list.length) return '<p class="muted">Aucun passage enregistré.</p>';
  return '<ul class="plist">' + list.map(v => {
    const bs = v.bons.filter(b => !b.annule), du = bs.filter(b => !b.paye).reduce((s, b) => s + b.net, 0);
    const annule = v.bons.length > 0 && !bs.length;
    const annulable = !annule && v.type !== 'reprise' && (peut('passage_annuler') || peut('suppression_demander')) && bs.length > 0 && bs.every(b => !b.paye && !b.delivre)
      && (jourDe(v.cree_le) === todayISO() || peut('valider'));
    const side = annule ? '<span class="badge b-muted">Annulé</span>' : bs.length ? (bs.some(b => !b.paye) ? `<span class="badge ${bs.some(b => b.urgent && !b.paye) ? 'b-bad' : 'b-due'}">${money(du)} à payer</span>` : '<span class="badge b-ok">Réglé</span>') : '<span class="badge b-muted">Sans bon</span>';
    return `<li><div><strong>${esc(v.numero)}</strong> ${esc(typeLibelle(v.type))}${v.specialite ? ', ' + esc(lcFirst(v.specialite)) : ''}
      <div class="muted">${fmtDateTime(v.cree_le)}${v.accord ? ', accord ' + esc(v.accord) : ''}</div></div><div class="pl-side">${side}<div class="muted">${bs.length} ${pl(bs.length, 'bon')}</div>${annulable ? `<button class="btn btn-ghost btn-sm" data-action="passageAnnuler" data-id="${v.id}" data-numero="${esc(v.numero)}">${peut('passage_annuler') ? 'Annuler' : 'Demander l’annulation'}</button>` : ''}</div></li>`;
  }).join('') + '</ul>';
}

/* Dossier patient : création, modification, doublons */
function formPatient(p) {
  const x = p || {}, ass = E.assureurs.filter(a => a.actif || a.id === x.assureur_id);
  return `<div class="form-grid two">
    ${champ('Nom', `<input id="np-nom" value="${esc(x.nom)}" autocomplete="off">`)}
    ${champ('Prénoms', `<input id="np-prenoms" value="${esc(x.prenoms)}" autocomplete="off">`)}
    ${champ('Sexe', `<select id="np-sexe"><option value="">Choisir</option><option value="F"${x.sexe === 'F' ? ' selected' : ''}>Femme</option><option value="M"${x.sexe === 'M' ? ' selected' : ''}>Homme</option></select>`)}
    ${champ('Date de naissance', `<input id="np-naissance" type="date" value="${esc(x.naissance)}" max="${todayISO()}">`)}
    ${champ('Téléphone', `<input id="np-tel" value="${esc(x.telephone)}" inputmode="tel" autocomplete="off">`)}
    ${champ('Commune et quartier', `<input id="np-commune" value="${esc(x.commune)}" autocomplete="off">`)}
    ${champ('Personne à prévenir', `<input id="np-contact" value="${esc(x.contact)}" placeholder="Nom et téléphone" autocomplete="off">`)}
    ${champ('Assureur', `<select id="np-ass" data-change="npAss"><option value="">Non assuré</option>${ass.map(a => `<option value="${a.id}"${x.assureur_id === a.id ? ' selected' : ''}>${esc(a.nom)}</option>`).join('')}</select>`)}
  </div>
  <div id="np-cov" class="form-grid two"${x.assureur_id ? '' : ' hidden'}>
    ${champ('N° d’assuré', `<input id="np-num" value="${esc(x.num_assure)}" autocomplete="off">`)}
    ${champ('Taux de couverture (%)', `<input id="np-taux" type="number" min="0" max="100" value="${x.taux == null ? 80 : x.taux}">`)}
    ${champ('Droits valables jusqu’au', `<input id="np-val" type="date" value="${esc(x.validite)}">`)}
  </div>
  <label class="case"><input type="checkbox" id="np-prov"${x.provisoire ? ' checked' : ''}> Identité provisoire (urgence, patient non identifiable)</label>`;
}
function lireFormPatient() {
  const v = id => ($('#' + id) || {}).value || '';
  return { nom: v('np-nom'), prenoms: v('np-prenoms'), sexe: v('np-sexe'), naissance: v('np-naissance'), telephone: v('np-tel'), commune: v('np-commune'), contact: v('np-contact'),
    assureur_id: v('np-ass') ? Number(v('np-ass')) : null, num_assure: v('np-num'), taux: v('np-taux'), validite: v('np-val'), provisoire: $('#np-prov').checked };
}
const REQUIS_PATIENT = [['np-nom', 'Nom'], ['np-prenoms', 'Prénoms'], ['np-sexe', 'Sexe'], ['np-naissance', 'Date de naissance'], ['np-tel', 'Téléphone']];
function verifierFormPatient(d) {
  document.querySelectorAll('.modal .invalide').forEach(x => { x.classList.remove('invalide'); x.removeAttribute('aria-invalid'); });
  const manquants = d.provisoire ? [] : REQUIS_PATIENT.filter(([id]) => !String(($('#' + id) || {}).value || '').trim());
  if (d.assureur_id && !String(d.num_assure || '').trim()) manquants.push(['np-num', 'N° d’assuré']);
  if (!manquants.length) return true;
  manquants.forEach(([id]) => { const el = $('#' + id); if (el) { el.classList.add('invalide'); el.setAttribute('aria-invalid', 'true'); } });
  toast(`À compléter : ${manquants.map(x => x[1]).join(', ')}.`, 'bad');
  const premier = $('#' + manquants[0][0]); if (premier) premier.focus();
  return false;
}
async function enregistrerPatient(forcer) {
  const d = lireFormPatient(), edition = UI.acc.edition;
  if (!verifierFormPatient(d)) return;
  const r = await agir(() => (edition ? api('PUT', '/api/patients/' + edition, d) : api('POST', '/api/patients', { ...d, forcer })), null, e => {
    if (e.status === 409 && e.data.doublon) { UI.acc.brouillon = d; afficherDoublon(e.data.doublon); return true; }
    return false;
  });
  if (!r) return;
  closeModal();
  const id = edition || r.id;
  UI.acc.edition = null;
  await chargerFiche(id);
  UI.acc.q = ''; rechercher('');
  render();
  toast(edition ? 'Dossier mis à jour.' : `Dossier créé : ${r.ipp}.`);
}
async function ouvrirPassage(forcer) {
  const f = UI.acc.fiche, p = f.patient, a = $('#acc-accord');
  if (a) UI.acc.accord = a.value.trim();
  if ((UI.acc.type === 'consultation' || UI.acc.type === 'controle') && !UI.acc.acteId) {
    toast('Choisissez la consultation (spécialité) avant d’ouvrir le passage.', 'bad');
    const s = $('#acc-acte'); if (s) { s.classList.add('invalide'); s.focus(); }
    return;
  }
  const corps = { patient_id: p.id, type: UI.acc.type, acte_id: Number(UI.acc.acteId) || null, accord: UI.acc.accord, forcer, medecin_id: Number(UI.acc.medecin) || null, motif: UI.acc.motif || '' };
  const r = await agir(() => api('POST', '/api/passages', corps), r => `Passage ${r.numero} ouvert${r.gratuit ? ' : contrôle gratuit, rien à payer'
    : r.non_couvert === 'expiree' ? ' : droits expirés, facturé comme non assuré' : r.non_couvert === 'inactive' ? ' : assureur suspendu, facturé comme non assuré'
    : r.sans_accord ? ' sans accord : facturé comme non assuré' : ''}.`, e => {
    if (e.status === 409 && e.data && e.data.deja) { afficherPassageDeja(e.data.deja); return true; }
    return false;
  });
  if (r) { closeModal(); UI.acc.accord = ''; UI.acc.acteId = ''; UI.acc.medecin = ''; UI.acc.motif = ''; await chargerFiche(p.id); render(); }
}
function afficherPassageDeja(x) {
  openModal(`<div class="modal-head"><h2>Passage déjà ouvert</h2>${closeBtn()}</div>
    <p>Ce patient a déjà un passage identique aujourd’hui :</p>
    <div class="notice warn"><strong>${esc(x.numero)}</strong>, ${esc(x.libelle)}, ouvert ${fmtDateTime(x.cree_le)}, ${x.paye ? 'déjà payé' : 'pas encore payé'}.</div>
    <p class="muted">Un second passage crée un second bon à payer. Ouvrez-le seulement si le patient revient pour une nouvelle prise en charge : l’ouverture est signalée à la direction.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Ne pas ouvrir</button><button class="btn" data-action="ouvrirPassage" data-forcer="1">Ouvrir un second passage</button></div>`, { noFocus: true });
}
function afficherDoublon(p) {
  openModal(`<div class="modal-head"><h2>Doublon probable</h2>${closeBtn()}</div>
    <p>Un dossier existe déjà avec la même identité ou le même téléphone et la même date de naissance :</p>
    <div class="notice warn"><strong>${esc(nomPatient(p))}</strong>, ${esc(p.ipp)}${p.naissance ? ', né(e) le ' + fmtDate(p.naissance) : ''}${p.telephone ? ', ' + esc(p.telephone) : ''}</div>
    <p class="muted">Un patient ne doit avoir qu’un seul dossier. La création d’un second dossier est tracée et signalée à la direction.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="creerMalgreDoublon">Créer quand même</button><button class="btn" data-action="ouvrirDoublon" data-id="${p.id}">Ouvrir ce dossier</button></div>`, { noFocus: true });
}
Object.assign(ACTIONS, {
  accChoisir: async el => { try { await chargerFiche(Number(el.dataset.id)); UI.acc.accord = ''; render(); scrollToId('acc-detail'); } catch (e) { toast(e.message, 'bad'); } },
  accType: el => { const a = $('#acc-accord'); if (a) UI.acc.accord = a.value; UI.acc.type = el.dataset.type; render(); },
  nouveauPatient: () => {
    UI.acc.edition = null;
    openModal(`<div class="modal-head"><h2>Nouveau patient</h2>${closeBtn()}</div>${formPatient(null)}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="enregistrerPatient">Créer le dossier</button></div>`, { large: true });
  },
  modifierPatient: () => {
    const p = UI.acc.fiche.patient;
    UI.acc.edition = p.id;
    openModal(`<div class="modal-head"><h2>Modifier le dossier ${esc(p.ipp)}</h2>${closeBtn()}</div>${formPatient(p)}
      <p class="hint">Chaque modification est journalisée avec l’ancienne et la nouvelle valeur.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="enregistrerPatient">Enregistrer</button></div>`, { large: true });
  },
  enregistrerPatient: () => enregistrerPatient(false),
  creerMalgreDoublon: async () => {
    const d = UI.acc.brouillon;
    const r = await agir(() => api('POST', '/api/patients', { ...d, forcer: true }));
    if (!r) return;
    closeModal(); await chargerFiche(r.id); UI.acc.q = ''; rechercher(''); render();
    toast(`Dossier créé : ${r.ipp}. Création signalée à la direction.`);
  },
  ouvrirDoublon: async el => { closeModal(); await chargerFiche(Number(el.dataset.id)); render(); },
  ouvrirPassage: el => ouvrirPassage(!!(el && el.dataset && el.dataset.forcer === '1')),
  passageAnnuler: el => !peut('passage_annuler') ? demanderSuppression({ objet: 'passage', id: el.dataset.id, titre: `Demander l’annulation du passage ${el.dataset.numero}`,
    description: 'Pour un passage ouvert par erreur : l’administrateur l’annulera, ses bons non payés quitteront la caisse et il ne comptera plus. En attendant, il ne peut pas être encaissé.' }) : openModal(`<div class="modal-head"><h2>Annuler le passage ${esc(el.dataset.numero)}</h2>${closeBtn()}</div>
    <p>Pour un passage ouvert par erreur ou un patient reparti sans être pris en charge : ses bons non payés sont annulés. C’est impossible dès qu’un acte est payé, délivré ou commencé.</p>
    ${champ('Motif de l’annulation', '<textarea id="pa-motif" rows="2" placeholder="Ex. passage ouvert deux fois"></textarea>')}
    <p class="hint">L’annulation est tracée au journal et signalée à la direction.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Garder le passage</button><button class="btn btn-danger" data-action="passageAnnulerOk" data-id="${el.dataset.id}">Annuler le passage</button></div>`),
  passageAnnulerOk: async el => {
    const r = await agir(() => api('POST', `/api/passages/${el.dataset.id}/annulation`, { motif: $('#pa-motif').value }),
      r => `Passage ${r.numero} annulé : ${r.bons} ${pl(r.bons, 'bon')} retiré${r.bons > 1 ? 's' : ''} de la caisse.`);
    if (!r) return;
    closeModal();
    if (UI.acc && UI.acc.fiche && UI.acc.fiche.patient) { await chargerFiche(UI.acc.fiche.patient.id); render(); }
  },
  fusionPatient: () => {
    const p = UI.acc.fiche.patient;
    openModal(`<div class="modal-head"><h2>Fusionner le dossier ${esc(p.ipp)}</h2>${closeBtn()}</div>
      <p>Les passages de <strong>${esc(nomPatient(p))}</strong> seront rattachés au dossier à conserver. Ce dossier restera consultable, marqué « fusionné » ; rien n’est supprimé.</p>
      ${champ('IPP du dossier à conserver', '<input id="fu-ipp" placeholder="P-000123" autocomplete="off" data-enter="fusionChercher">')}
      <div id="fu-cible"></div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="fusionChercher">Vérifier</button></div>`);
  },
  fusionChercher: async () => {
    const ipp = $('#fu-ipp').value.trim().toUpperCase();
    const res = (await api('GET', '/api/patients?q=' + encodeURIComponent(ipp))).filter(x => x.ipp === ipp && x.id !== UI.acc.fiche.patient.id);
    $('#fu-cible').innerHTML = res.length
      ? `<div class="notice">${esc(nomPatient(res[0]))}, ${esc(res[0].ipp)}${res[0].naissance ? ', né(e) le ' + fmtDate(res[0].naissance) : ''}</div><button class="btn btn-danger btn-block" data-action="fusionConfirmer" data-id="${res[0].id}">Confirmer la fusion</button>`
      : '<div class="notice bad">Aucun autre dossier actif avec cet IPP.</div>';
  },
  fusionConfirmer: async el => {
    const source = UI.acc.fiche.patient.id, cible = Number(el.dataset.id);
    const r = await agir(() => api('POST', `/api/patients/${source}/fusion`, { vers_id: cible }), 'Dossiers fusionnés. L’opération est journalisée.');
    if (r) { closeModal(); await chargerFiche(cible); rechercher(UI.acc.q); render(); }
  }
});
ACTIONS.rdvStatut = el => agir(() => api('PUT', `/api/rdv/${el.dataset.id}`, { statut: el.dataset.s }), el.dataset.s === 'honore' ? 'Arrivée du patient notée.' : 'Absence notée.');
Object.assign(INPUTS, {
  accRecherche: el => { UI.acc.q = el.value; rechercher(el.value.trim()); },
  accAccord: el => { UI.acc.accord = el.value; }
});
Object.assign(CHANGES, {
  accActe: el => { const a = $('#acc-accord'); if (a) UI.acc.accord = a.value; UI.acc.acteId = el.value; UI.acc.medecin = ''; render(); },
  npAss: el => { $('#np-cov').hidden = !el.value; }
});
ONGLETS.push({ id: 'accueil', libelle: 'Accueil', icone: 'accueil', visible: () => peut('passage_ouvrir') || peut('patient_ecrire'), vue: vAccueil });

/* Rendez-vous pris à l'accueil (v1.5) ; le médecin ou le patient est prévenu par un message personnalisé (WhatsApp ou SMS). */
const numeroIntl = t => { let d = String(t || '').replace(/\D/g, ''); if (d.startsWith('00')) d = d.slice(2); if (d.length === 10) d = '225' + d; return d; };
function texteRdv(dest, rv, med) {
  const quand = `${rv.date === todayISO() ? 'aujourd’hui' : 'le ' + fmtDate(rv.date)}${rv.heure ? ' à ' + String(rv.heure).replace(':', ' h ') : ''}`;
  const patient = `${rv.nom || ''} ${rv.prenoms || ''}`.trim(), clinique = E.parametres.raison;
  if (dest === 'medecin') return `Bonjour ${med ? med.nom : 'Docteur'}, un rendez-vous est pris pour ${patient} ${quand}${rv.specialite ? ' en ' + lcFirst(rv.specialite) : ''}${rv.motif ? ', motif : ' + rv.motif : ''}. ${clinique}.`;
  return `Bonjour ${patient}, votre rendez-vous à la ${clinique} est confirmé ${quand}${med ? ' avec ' + med.nom : ''}. Merci de vous présenter 15 minutes avant. Renseignements : ${E.parametres.telephone}.`;
}
function messageRdv(rv) {
  const med = (E.medecins || []).find(m => m.id === rv.medecin_id) || null;
  UI.rdvMsg = { rv, med, dest: med ? 'medecin' : 'patient' };
  afficherMessageRdv();
}
function afficherMessageRdv() {
  const m = UI.rdvMsg, tel = m.dest === 'medecin' ? (m.med && m.med.telephone) : m.rv.telephone;
  openModal(`<div class="modal-head"><h2>Prévenir par message</h2>${closeBtn()}</div>
    <div class="seg" role="group" aria-label="Destinataire">${[['medecin', 'Le médecin'], ['patient', 'Le patient']].map(([k, l]) => `<button type="button" data-action="rdvDest" data-dest="${k}" aria-pressed="${m.dest === k}"${k === 'medecin' && !m.med ? ' disabled' : ''}>${l}</button>`).join('')}</div>
    <p class="muted">${tel ? `Numéro : ${esc(tel)}` : m.dest === 'medecin' ? 'Aucun numéro enregistré pour ce médecin : ajoutez-le dans Paramétrage, Utilisateurs.' : 'Aucun numéro enregistré pour ce patient.'}</p>
    ${champ('Message, modifiable avant l’envoi', `<textarea id="rv-msg" rows="5">${esc(texteRdv(m.dest, m.rv, m.med))}</textarea>`)}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="rdvCopier">Copier le message</button><button class="btn btn-ghost" data-action="rdvEnvoyer" data-canal="sms"${tel ? '' : ' disabled'}>Envoyer par SMS</button><button class="btn" data-action="rdvEnvoyer" data-canal="whatsapp"${tel ? '' : ' disabled'}>Envoyer par WhatsApp</button></div>`, { noFocus: true });
}
Object.assign(ACTIONS, {
  rdvNouveau: () => {
    const p = UI.acc.fiche.patient, meds = E.medecins || [];
    openModal(`<div class="modal-head"><h2>Rendez-vous pour ${esc(nomPatient(p))}</h2>${closeBtn()}</div>
      <div class="form-grid">
        ${champ('Date', `<input type="date" id="rv-date" min="${todayISO()}" value="${todayISO()}">`)}
        ${champ('Heure', '<input type="time" id="rv-heure" step="300">')}
        ${champ('Médecin', `<select id="rv-medecin" data-change="rdvAccMedecin"><option value="">Sans médecin désigné</option>${meds.map(m => `<option value="${m.id}">${esc(m.nom)}${m.specialites.length ? ', ' + esc(m.specialites.join(', ').toLowerCase()) : ''}</option>`).join('')}</select>`)}
        ${champ('Spécialité', `<select id="rv-specialite"><option value="">Non précisée</option>${MSI_SPECIALITES.noms().map(n => `<option>${esc(n)}</option>`).join('')}</select>`)}
      </div>
      ${champ('Motif', '<input id="rv-motif" maxlength="160" placeholder="Ex. contrôle de tension">')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rdvEnregistrerAccueil">Enregistrer le rendez-vous</button></div>`);
  },
  rdvEnregistrerAccueil: async () => {
    const p = UI.acc.fiche.patient;
    const corps = { patient_id: p.id, date: $('#rv-date').value, heure: $('#rv-heure').value, medecin_id: Number($('#rv-medecin').value) || null, specialite: $('#rv-specialite').value, motif: $('#rv-motif').value };
    const r = await agir(() => api('POST', '/api/rdv', corps), 'Rendez-vous enregistré.');
    if (!r) return;
    closeModal();
    const id = r && typeof r === 'object' ? r.id : r;
    const rv = (E.rdv || []).find(x => x.id === id) || { ...corps, id, nom: p.nom, prenoms: p.prenoms, telephone: p.telephone };
    messageRdv(rv);
  },
  rdvMessage: el => { const rv = (E.rdv || []).find(x => String(x.id) === el.dataset.id); if (rv) messageRdv(rv); },
  rdvDest: el => { UI.rdvMsg.dest = el.dataset.dest; afficherMessageRdv(); },
  rdvEnvoyer: el => {
    const m = UI.rdvMsg, tel = numeroIntl(m.dest === 'medecin' ? m.med && m.med.telephone : m.rv.telephone), txt = $('#rv-msg').value;
    if (!tel) return;
    window.open(el.dataset.canal === 'whatsapp' ? `https://wa.me/${tel}?text=${encodeURIComponent(txt)}` : `sms:+${tel}?body=${encodeURIComponent(txt)}`, '_blank');
    toast(el.dataset.canal === 'whatsapp' ? 'WhatsApp s’ouvre avec le message prêt : il reste à l’envoyer.' : 'L’application de SMS s’ouvre avec le message prêt : il reste à l’envoyer.');
  },
  rdvCopier: async () => { try { await navigator.clipboard.writeText($('#rv-msg').value); toast('Message copié.'); } catch (e) { $('#rv-msg').select(); toast('Sélectionnez le message puis copiez-le.'); } }
});
Object.assign(CHANGES, { rdvAccMedecin: el => { const m = (E.medecins || []).find(x => String(x.id) === el.value), s = $('#rv-specialite'); if (m && m.specialites.length === 1 && s) s.value = m.specialites[0]; } });

/* Admission (v1.6) : médecin choisi dès l'accueil (facultatif) et motif, repris par l'infirmerie et par la consultation. */
function champsAdmission() {
  const t = UI.acc.type;
  if (!['consultation', 'controle', 'urgence'].includes(t)) return '';
  const a = (E.actes || []).find(x => String(x.id) === String(UI.acc.acteId)), sp = t === 'urgence' ? null : a && a.specialite;
  const meds = (E.medecins || []).filter(m => !sp || !m.specialites.length || m.specialites.includes(sp));
  return `${t !== 'urgence' ? champ('Médecin (facultatif)', `<select id="acc-medecin" data-change="accMedecin"><option value="">Choisi par l’infirmerie</option>${meds.map(m => `<option value="${m.id}"${String(m.id) === String(UI.acc.medecin || '') ? ' selected' : ''}>${esc(m.nom)}</option>`).join('')}</select>`) : ''}
    ${champ('Motif de consultation', `<input id="acc-motif" data-input="accMotif" maxlength="160" value="${esc(UI.acc.motif || '')}" placeholder="Ex. fièvre depuis trois jours" autocomplete="off">`)}`;
}
Object.assign(CHANGES, { accMedecin: el => { UI.acc.medecin = el.value; } });
Object.assign(INPUTS, { accMotif: el => { UI.acc.motif = el.value; } });

/* Doublon de patient (v2.2) : signalé à l'administrateur, qui fusionne après vérification ; motif obligatoire. */
Object.assign(ACTIONS, {
  doublonSignaler: () => {
    const p = UI.acc.fiche.patient;
    UI.acc.doublonCible = null;
    openModal(`<div class="modal-head"><h2>Signaler un doublon : ${esc(p.ipp)}</h2>${closeBtn()}</div>
      <p>Si <strong>${esc(nomPatient(p))}</strong> a été enregistré deux fois, indiquez le dossier à conserver. L’administrateur fusionnera les deux dossiers après vérification ; rien n’est supprimé.</p>
      ${champ('IPP du dossier à conserver', '<input id="db-ipp" placeholder="P-000123" autocomplete="off" data-enter="doublonChercher">')}<div id="db-cible"></div>
      ${champ('Motif de la demande (obligatoire)', '<textarea id="sup-motif" rows="2" maxlength="300" data-input="supMotif" placeholder="Ex. même patiente enregistrée deux fois avec deux orthographes"></textarea>', '<span id="sup-compte">10 caractères au moins.</span>')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn btn-ghost" data-action="doublonChercher">Vérifier l’IPP</button><button class="btn" id="sup-envoyer" data-action="doublonEnvoyer" disabled>Envoyer la demande à l’administrateur</button></div>`);
  },
  doublonChercher: async () => {
    const ipp = $('#db-ipp').value.trim().toUpperCase();
    const res = (await api('GET', '/api/patients?q=' + encodeURIComponent(ipp))).filter(x => x.ipp === ipp && x.id !== UI.acc.fiche.patient.id);
    UI.acc.doublonCible = res.length ? res[0].id : null;
    $('#db-cible').innerHTML = res.length ? `<div class="notice">Dossier à conserver : ${esc(nomPatient(res[0]))}, ${esc(res[0].ipp)}</div>` : '<div class="notice bad">Aucun autre dossier actif avec cet IPP.</div>';
  },
  doublonEnvoyer: async () => {
    if (!UI.acc.doublonCible) { toast('Vérifiez d’abord l’IPP du dossier à conserver.', 'bad'); return; }
    const motif = ($('#sup-motif').value || '').trim();
    if (motif.length < 10) { toast('Indiquez le motif de la demande (10 caractères au moins).', 'bad'); return; }
    const r = await agir(() => api('POST', '/api/suppressions', { objet: 'doublon', id: UI.acc.fiche.patient.id, vers_id: UI.acc.doublonCible, motif }), 'Demande envoyée à l’administrateur.');
    if (r) closeModal();
  }
});
