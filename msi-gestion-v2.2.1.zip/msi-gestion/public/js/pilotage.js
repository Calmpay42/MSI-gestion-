'use strict';
/* Pilotage (direction, RAF) : tableau de bord et statistiques, avec courbes, diagrammes, alertes et rapport imprimable.
   Les chiffres viennent de /api/pilotage, calculés par le serveur avec les règles mêmes de la caisse. */
const etatPil = () => (UI.pil = UI.pil || { vue: 'tableau', periode: '12m', cache: {}, chargement: {}, erreur: null });
const donneesPil = code => { const c = etatPil().cache[code]; return c ? c.d : null; };
const nbrPil = v => (Array.isArray(v) ? v.length : Number(v) || 0);
const accordPil = (n, un, plusieurs) => `${GR.nb(n)} ${n > 1 ? plusieurs : un}`;
const ongletVisible = id => ONGLETS.some(o => o.id === id && o.visible());
const PERIODES_PIL = [['mois', 'Mois en cours'], ['12m', '12 derniers mois'], ['annee', 'Année en cours'], ['anneePrec', 'Année précédente'], ['tout', 'Depuis le début']];
const LIB_MODES = { 'Avance du patient': 'Avance du patient (déjà versée)' };

async function chargerPil(code, force) {
  const s = etatPil(), c = s.cache[code];
  if (s.chargement[code] || (!force && c && Date.now() - c.le < 60000)) return;
  s.chargement[code] = true;
  try { s.cache[code] = { d: await api('GET', '/api/pilotage?periode=' + encodeURIComponent(code)), le: Date.now() }; s.erreur = null; }
  catch (e) { s.erreur = e.message || 'Chargement des indicateurs impossible.'; }
  finally { s.chargement[code] = false; }
  if (UI.tab === 'pilotage' && !modalOuverte()) render();
}
const chargementPil = () => etatPil().erreur
  ? `<div class="panel"><p class="notice bad">${esc(etatPil().erreur)}</p><button class="btn" data-action="pilActualiser">Réessayer</button></div>`
  : '<div class="panel pil-attente" aria-busy="true"><p class="muted">Calcul des indicateurs en cours…</p></div>';

function alertesPil(annee) {
  const k = E.indicateurs || {}, t = [];
  const ajouter = (n, texte, onglet, grave) => { if (n) t.push({ texte, onglet: onglet && ongletVisible(onglet) ? onglet : null, grave }); };
  const attente = (E.demandes || []).filter(d => d.statut === 'en_attente').length;
  ajouter(attente, `${accordPil(attente, 'validation attend', 'validations attendent')} votre décision`, 'direction', true);
  ajouter(nbrPil(k.ruptures), `${accordPil(nbrPil(k.ruptures), 'produit en rupture', 'produits en rupture')} de stock`, 'pharmacie', true);
  ajouter(nbrPil(k.perimes), `${accordPil(nbrPil(k.perimes), 'lot périmé', 'lots périmés')} à retirer du stock`, 'pharmacie', true);
  ajouter(nbrPil(k.sous_seuil), `${accordPil(nbrPil(k.sous_seuil), 'produit sous', 'produits sous')} le seuil de commande`, 'pharmacie', false);
  ajouter(nbrPil(k.delivrances_sans_paiement), `${accordPil(nbrPil(k.delivrances_sans_paiement), 'délivrance', 'délivrances')} sans paiement aujourd’hui`, 'direction', true);
  ajouter(nbrPil(k.tentatives_bloquees), `${accordPil(nbrPil(k.tentatives_bloquees), 'tentative bloquée', 'tentatives bloquées')} aujourd’hui (contrôles anti-fuite)`, 'direction', false);
  ajouter(Number(k.ecart) ? 1 : 0, `Écart de caisse du jour : ${money(k.ecart)}`, 'direction', true);
  ajouter(nbrPil(k.tarifs_a_valider), `${accordPil(nbrPil(k.tarifs_a_valider), 'tarif', 'tarifs')} à valider avant facturation`, 'parametrage', true);
  ajouter(nbrPil(k.passages_annules), `${accordPil(nbrPil(k.passages_annules), 'passage annulé', 'passages annulés')} aujourd’hui`, 'direction', false);
  const vieilles = annee ? annee.assureurs.creances.reduce((s, c) => s + c.plus90, 0) : 0;
  ajouter(vieilles ? 1 : 0, `Créances des assureurs de plus de 90 jours : ${money(vieilles)}`, 'tiers', true);
  return t;
}

function vPilotage() {
  const s = etatPil();
  const nav = `<div class="pil-nav" role="tablist">${[['tableau', 'Tableau de bord'], ['stats', 'Statistiques']].map(([v, l]) =>
    `<button type="button" role="tab" aria-selected="${s.vue === v}" data-action="pilVue" data-vue="${v}">${l}</button>`).join('')}</div>`;
  return `<div class="pil">${s.vue === 'stats' ? vPilStats(nav) : vPilTableau(nav)}</div>`;
}

function vPilTableau(nav) {
  const heure = new Date().getHours(), aujourdhui = todayISO();
  const entete = `<section class="pil-entete"><div><h1>${heure < 18 ? 'Bonjour' : 'Bonsoir'}, ${esc(MOI.utilisateur.nom)}</h1>
    <p class="muted">${GR.JOURS[(new Date().getDay() + 6) % 7]} ${GR.dateLongue(aujourdhui)}. ${esc(E.parametres.raison)}, pilotage de l’activité.</p></div>${nav}</section>`;
  const m = donneesPil('mois'), a = donneesPil('12m');
  if (!m || !a) return entete + chargementPil();
  const t = m.totaux, p = m.precedent || {}, moisLib = GR.MOIS_L[Number(aujourdhui.slice(5, 7)) - 1];
  const precLib = 'le mois dernier à la même date';
  const creances = a.assureurs.creances.reduce((s, c) => s + c.total, 0), vieilles = a.assureurs.creances.reduce((s, c) => s + c.plus90, 0);
  const alertes = alertesPil(a);
  return `${entete}
  <section class="pil-kpis">
    ${GR.kpi({ lib: 'Recettes du jour', val: GR.montant(m.jour.recettes), sous: `${accordPil(m.jour.passages, 'passage', 'passages')} aujourd’hui`, spark: GR.etincelle(m.recettes_30j) })}
    ${GR.kpi({ lib: `Recettes de ${moisLib}`, val: GR.montant(t.recettes), tend: GR.tendance(t.recettes, p.recettes, precLib), sous: 'encaissées auprès des patients' })}
    ${GR.kpi({ lib: `Chiffre d’affaires de ${moisLib}`, val: GR.montant(t.ca), sous: `dont ${money(t.part_assureurs)} à la charge des assureurs` })}
    ${GR.kpi({ lib: `Passages de ${moisLib}`, val: GR.nb(t.passages), tend: GR.tendance(t.passages, p.passages, precLib) })}
    ${GR.kpi({ lib: 'Nouveaux patients', val: GR.nb(t.nouveaux), tend: GR.tendance(t.nouveaux, p.nouveaux, precLib), sous: `en ${moisLib}` })}
    ${GR.kpi({ lib: 'Créances des assureurs', val: GR.montant(creances), sous: vieilles ? `dont ${money(vieilles)} à plus de 90 jours` : 'aucune de plus de 90 jours', alerte: vieilles > 0, onglet: ongletVisible('tiers') ? 'tiers' : null })}
  </section>
  <section class="pil-grille pil-grille-large">
    <div class="panel"><div class="pil-tete"><h2>Chiffre d’affaires et passages, 12 derniers mois</h2><button class="btn btn-ghost btn-sm" data-action="pilVue" data-vue="stats">Voir les statistiques</button></div>
      ${GR.histogramme({ titre: 'Chiffre d’affaires et passages par mois', libs: a.periode.cases.map(c => GR.libMois(c, false)), titres: a.periode.cases.map(c => GR.libMois(c, true)), enCours: true, enCoursLib: 'Mois en cours',
        barres: { nom: 'FCFA', libelle: 'Chiffre d’affaires (patients et assureurs)', vals: a.series.recettes.map((v, i) => v + a.series.part_assureurs[i]) },
        ligne: { nom: 'passages', libelle: 'Passages', couleur: GR.C.cuivre, vals: a.series.passages }, w: 680,
        vide: 'Le chiffre d’affaires apparaîtra ici dès les premiers encaissements.' })}</div>
    <div class="panel"><h2>Recettes par service</h2><p class="muted pil-note">12 derniers mois, patients et assureurs.</p>
      ${GR.anneau({ titre: 'Recettes par service', parts: a.services.slice(0, 7).map(x => ({ l: x.libelle, v: x.montant })), centre: GR.abrege(a.totaux.ca), centreLib: 'FCFA', fmt: v => money(v), fmtLeg: v => GR.abrege(v) })}</div>
  </section>
  <section class="pil-grille">
    <div class="panel"><div class="pil-tete"><h2>Alertes</h2>${alertes.length ? `<span class="pil-pastille">${alertes.length}</span>` : ''}</div>
      ${alertes.length ? `<ul class="pil-alertes">${alertes.map(x => `<li class="${x.grave ? 'pil-grave' : ''}"${x.onglet ? ` data-action="onglet" data-tab="${x.onglet}" role="button" tabindex="0"` : ''}>${esc(x.texte)}</li>`).join('')}</ul>`
        : GR.vide('Aucune alerte : stock, caisse, validations et créances sont en ordre.')}</div>
    <div class="panel"><h2>Modes de paiement en ${moisLib}</h2>
      ${GR.anneau({ titre: 'Modes de paiement', parts: m.modes.map((x, i) => ({ l: LIB_MODES[x.mode] || x.mode, v: x.montant, c: GR.PALETTE[i % GR.PALETTE.length] })), centre: GR.abrege(t.recettes), centreLib: 'FCFA encaissés', fmt: v => money(v), fmtLeg: v => GR.abrege(v), vide: 'Aucun encaissement ce mois-ci.' })}</div>
  </section>
  <section class="panel"><div class="pil-tete"><h2>Créances des assureurs</h2>${ongletVisible('tiers') ? '<button class="btn btn-ghost btn-sm" data-action="onglet" data-tab="tiers">Ouvrir le tiers payant</button>' : ''}</div>
    ${GR.barresH(a.assureurs.creances.filter(c => c.total > 0).map(c => ({ l: c.assureur, v: c.total, d: c.plus90 ? `dont ${money(c.plus90)} à plus de 90 jours` : '', c: c.plus90 ? GR.C.alerte : GR.C.barre })),
      { fmt: v => money(v), detail: true, videTxt: 'Aucune créance : tout le tiers payant est facturé et réglé.' })}</section>`;
}

function vPilStats(nav) {
  const s = etatPil();
  const actions = `<div class="pil-actions"><div class="pil-periodes" role="group" aria-label="Période">${PERIODES_PIL.map(([c, l]) =>
    `<button type="button" aria-pressed="${s.periode === c}" data-action="pilPeriode" data-periode="${c}">${l}</button>`).join('')}</div>
    <button class="btn btn-ghost btn-sm" data-action="pilImprimer">Imprimer le rapport</button></div>`;
  const d = donneesPil(s.periode);
  const entete = (lib, comp) => `<section class="pil-entete"><div><h1>Statistiques</h1><p class="muted">${lib ? `Période : ${esc(lib)}${comp ? `, comparée ${esc(GR.aLib(comp))}` : ''}.` : 'Choisissez une période.'}</p></div>${nav}</section>${actions}`;
  if (!d) return entete() + chargementPil();
  const t = d.totaux, p = d.precedent, P = d.periode, parJour = P.par_jour;
  const libs = P.cases.map(c => (parJour ? GR.libCase(c) : GR.libMois(c, P.cases.length > 12 || P.code !== '12m')));
  const titres = P.cases.map(c => (parJour ? GR.dateLongue(c) : GR.libMois(c, true)));
  const enCours = P.au === todayISO(), ca = d.series.recettes.map((v, i) => v + d.series.part_assureurs[i]);
  const cumul = []; ca.reduce((acc, v) => { cumul.push(acc + v); return acc + v; }, 0);
  const moyenne = t.passages_factures ? t.panier : 0;
  const heures = d.frequentation.heures.map((v, h) => ({ h, v })).filter(x => x.h >= 6 && x.h <= 21);
  const reglesParAssureur = new Map(d.assureurs.regle.map(r => [r.assureur, r.montant]));
  return `${entete(P.lib, P.prec)}
  <section class="pil-kpis">
    ${GR.kpi({ lib: 'Chiffre d’affaires', val: GR.montant(t.ca), tend: p ? GR.tendance(t.ca, p.ca, P.prec) : '', sous: 'patients et assureurs' })}
    ${GR.kpi({ lib: 'Encaissé auprès des patients', val: GR.montant(t.recettes), tend: p ? GR.tendance(t.recettes, p.recettes, P.prec) : '' })}
    ${GR.kpi({ lib: 'Part des assureurs', val: GR.montant(t.part_assureurs), sous: `${t.ca ? Math.round(t.part_assureurs / t.ca * 100) : 0} % du chiffre d’affaires` })}
    ${GR.kpi({ lib: 'Passages', val: GR.nb(t.passages), tend: p ? GR.tendance(t.passages, p.passages, P.prec) : '' })}
    ${GR.kpi({ lib: 'Nouveaux patients', val: GR.nb(t.nouveaux), tend: p ? GR.tendance(t.nouveaux, p.nouveaux, P.prec) : '' })}
    ${GR.kpi({ lib: 'Recette moyenne par passage', val: GR.montant(moyenne), sous: `${GR.nb(t.passages_factures)} passages facturés` })}
    ${GR.kpi({ lib: 'Remises accordées', val: GR.montant(t.remises), sous: t.ca ? `${(t.remises / (t.ca + t.remises) * 100).toFixed(1).replace('.', ',')} % du montant avant remise` : '' })}
    ${GR.kpi({ lib: 'Valeur du stock', val: GR.montant(t.valeur_stock), sous: 'au prix d’achat, lots non périmés', onglet: ongletVisible('pharmacie') ? 'pharmacie' : null })}
  </section>
  <section class="panel"><h2>Activité</h2>
    ${GR.histogramme({ titre: 'Passages et nouveaux patients', libs, titres, enCours, enCoursLib: parJour ? 'Aujourd’hui' : 'Mois en cours', w: 900,
      barres: { nom: 'passages', libelle: 'Passages', vals: d.series.passages }, ligne: { nom: 'nouveaux patients', libelle: 'Nouveaux patients', couleur: GR.C.cuivre, vals: d.series.nouveaux } })}</section>
  <section class="panel"><div class="pil-tete"><h2>Chiffre d’affaires</h2><span class="muted">Total : ${money(t.ca)}</span></div>
    ${GR.histogramme({ titre: 'Chiffre d’affaires et cumul', libs, titres, enCours, enCoursLib: parJour ? 'Aujourd’hui' : 'Mois en cours', w: 900,
      barres: { nom: 'FCFA', libelle: parJour ? 'Chiffre d’affaires du jour' : 'Chiffre d’affaires du mois', vals: ca }, ligne: { nom: 'FCFA cumulés', libelle: 'Cumul sur la période', couleur: GR.C.cuivre, vals: cumul } })}</section>
  <section class="pil-grille">
    <div class="panel"><h2>Recettes par service</h2>${GR.barresH(d.services.map(x => ({ l: x.libelle, v: x.montant })), { fmt: v => money(v) })}</div>
    <div class="panel"><h2>Modes de paiement</h2>${GR.anneau({ titre: 'Modes de paiement', parts: d.modes.map((x, i) => ({ l: LIB_MODES[x.mode] || x.mode, v: x.montant, c: GR.PALETTE[i % GR.PALETTE.length] })), centre: GR.abrege(t.recettes), centreLib: 'FCFA encaissés', fmt: v => money(v), fmtLeg: v => GR.abrege(v) })}</div>
  </section>
  <section class="pil-grille">
    <div class="panel"><h2>Types de passage</h2>${GR.anneau({ titre: 'Types de passage', parts: d.types.map((x, i) => ({ l: typeLibelle(x.type), v: x.nombre, c: GR.PALETTE[i % GR.PALETTE.length] })), centreLib: 'passages' })}</div>
    <div class="panel"><h2>Consultations par spécialité</h2>${GR.barresH(d.specialites.map(x => ({ l: x.specialite, v: x.nombre })), { videTxt: 'Aucune consultation sur la période.' })}</div>
  </section>
  <section class="pil-grille">
    <div class="panel"><h2>Actes les plus facturés</h2>${GR.barresH(d.actes.map(x => ({ l: x.libelle, v: x.montant, d: accordPil(x.quantite, 'acte', 'actes') })), { fmt: v => money(v), detail: true, videTxt: 'Aucun acte facturé sur la période.' })}</div>
    <div class="panel"><h2>Médicaments les plus délivrés</h2>${GR.barresH(d.produits.map(x => ({ l: x.libelle, v: x.quantite, d: money(x.montant) })), { couleur: GR.C.cuivre, detail: true, videTxt: 'Aucun médicament vendu sur la période.' })}</div>
  </section>
  <section class="pil-grille">
    <div class="panel"><h2>Facturé aux assureurs</h2>${GR.barresH(d.assureurs.facture.map(x => ({ l: x.assureur, v: x.montant, d: reglesParAssureur.has(x.assureur) ? `réglé sur la période : ${money(reglesParAssureur.get(x.assureur))}` : '' })), { fmt: v => money(v), detail: true, videTxt: 'Aucune part assureur sur la période.' })}</div>
    <div class="panel"><h2>Règlements reçus des assureurs</h2>${GR.barresH(d.assureurs.regle.map(x => ({ l: x.assureur, v: x.montant })), { fmt: v => money(v), couleur: GR.C.cuivre, videTxt: 'Aucun règlement reçu sur la période.' })}</div>
  </section>
  <section class="panel"><h2>Créances des assureurs à ce jour</h2>${d.assureurs.creances.length ? `<div class="table-wrap"><table class="pil-table"><thead><tr><th>Assureur</th><th>Non facturé</th><th>0 à 30 jours</th><th>31 à 60 jours</th><th>61 à 90 jours</th><th>Plus de 90 jours</th><th>Total</th></tr></thead><tbody>
    ${d.assureurs.creances.map(c => `<tr><td>${esc(c.assureur)}</td><td>${money(c.non_facture)}</td><td>${money(c.j30)}</td><td>${money(c.j60)}</td><td>${money(c.j90)}</td><td class="${c.plus90 ? 'pil-rouge' : ''}">${money(c.plus90)}</td><td><strong>${money(c.total)}</strong></td></tr>`).join('')}
    </tbody></table></div>` : GR.vide('Aucune créance : tout le tiers payant est facturé et réglé.')}</section>
  <section class="pil-grille">
    <div class="panel"><h2>Fréquentation par jour</h2>${GR.histogramme({ titre: 'Passages par jour de la semaine', libs: GR.JOURS.map(j => j.slice(0, 3) + '.'), titres: GR.JOURS, w: 460, h: 250, barres: { nom: 'passages', libelle: 'Passages', vals: d.frequentation.jours } })}</div>
    <div class="panel"><h2>Fréquentation par heure d’arrivée</h2>${GR.histogramme({ titre: 'Passages par heure', libs: heures.map(x => x.h + ' h'), titres: heures.map(x => `de ${x.h} h à ${x.h + 1} h`), w: 460, h: 250, barres: { nom: 'passages', libelle: 'Passages', vals: heures.map(x => x.v), couleur: GR.C.cuivre } })}</div>
  </section>
  <section class="panel"><div class="pil-tete"><h2>Écarts de caisse</h2><span class="muted">${accordPil(d.caisse.sessions, 'caisse clôturée', 'caisses clôturées')}, dont ${accordPil(d.caisse.avec_ecart, 'avec écart', 'avec écart')} ; total ${money(d.caisse.total_ecart)}</span></div>
    ${GR.histogramme({ titre: 'Écarts de caisse', libs, titres, w: 900, h: 220, barres: { nom: 'FCFA d’écart', libelle: 'Écart cumulé des clôtures', vals: d.series.ecarts, couleur: GR.C.petroleClair }, vide: 'Aucun écart de caisse sur la période.' })}</section>`;
}

Object.assign(ACTIONS, {
  pilVue: el => { etatPil().vue = el.dataset.vue; render(); toTop(); },
  pilPeriode: el => { etatPil().periode = el.dataset.periode; render(); },
  pilActualiser: () => { const s = etatPil(); s.cache = {}; s.erreur = null; render(); },
  pilImprimer: () => {
    const vue = document.querySelector('#main .pil');
    if (!vue) return;
    const copie = vue.cloneNode(true);
    copie.querySelectorAll('.pil-actions, .pil-nav, button').forEach(x => x.remove());
    imprimer(`<div class="pil-rapport"><div class="pil-rapport-tete">${logo(64)}<div><strong>${esc(E.parametres.raison)}</strong><span>MSI Gestion, rapport de pilotage édité le ${fmtDate(new Date().toISOString())}</span></div></div>${copie.innerHTML}</div>`);
  }
});

ONGLETS.unshift({
  id: 'pilotage', libelle: 'Tableau de bord', icone: 'pilotage', visible: () => peut('pilotage'), vue: vPilotage,
  apresRendu: () => { const s = etatPil(); if (s.vue === 'stats') chargerPil(s.periode); else { chargerPil('mois'); chargerPil('12m'); } }
});
