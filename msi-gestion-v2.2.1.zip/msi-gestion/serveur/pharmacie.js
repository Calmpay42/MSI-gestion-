'use strict';
/* Pharmacie : lots et péremptions, prix automatiques, délivrance des seuls bons payés ou accordés. */
const { pad, jourLocal, maintenant, jourDe, joursEntre, fmt, err, texte, entier, date } = require('./outils');
const R = require('./regles');

const TYPES_AJUSTEMENT = {
  inventaire: 'Écart d’inventaire', casse: 'Casse', perime: 'Retrait de périmés', retour_fournisseur: 'Retour fournisseur',
  retour_patient: 'Retour patient', sortie_interne: 'Sortie interne vers un service'
};
const SORTANTS = ['casse', 'perime', 'retour_fournisseur', 'sortie_interne'];

const reserve = (db, pid) => db.prepare("SELECT COALESCE(SUM(quantite),0) q FROM bons WHERE nature = 'produit' AND produit_id = ? AND delivre = 0 AND annule = 0").get(pid).q;

/* PHA-03, PHA-08, RG-PHA-3 : lots triés par péremption ; les lots périmés sont bloqués. */
function stockProduit(db, p, jour = jourLocal()) {
  const lots = db.prepare('SELECT * FROM lots WHERE produit_id = ? AND quantite > 0 ORDER BY peremption, id').all(p.id);
  const utilisables = lots.filter(l => l.peremption >= jour);
  const dispo = utilisables.reduce((s, l) => s + l.quantite, 0), res = reserve(db, p.id);
  const prochain = utilisables[0] || null, jours = prochain ? joursEntre(jour, prochain.peremption) : null;
  return {
    dispo, reserve: res, libre: dispo - res, lots, prochain, jours,
    perimes: lots.filter(l => l.peremption < jour).reduce((s, l) => s + l.quantite, 0),
    rupture: dispo === 0, sous_seuil: dispo > 0 && dispo < p.seuil, p30: jours !== null && jours <= 30, p90: jours !== null && jours > 30 && jours <= 90
  };
}

/* PHA-04, PHA-05 : ordonnance sur un passage du jour, ou vente comptoir ; prix selon la couverture (RG-PHA-2). */
function creerOrdonnance(db, u, d) {
  const lignes = Array.isArray(d.lignes) ? d.lignes : [];
  if (!lignes.length || lignes.length > 40) throw err(400, 'Ajoutez au moins un produit.');
  const fusion = new Map();
  for (const l of lignes) {
    const pid = Number(l.produit_id), q = entier(l.quantite, { label: 'Quantité', min: 1, max: 1000 });
    fusion.set(pid, (fusion.get(pid) || 0) + q);
  }
  const produits = [...fusion].map(([pid, q]) => {
    const p = db.prepare('SELECT * FROM produits WHERE id = ? AND actif = 1').get(pid);
    if (!p) throw err(400, 'Produit inconnu ou désactivé.');
    const st = stockProduit(db, p);
    if (q > st.libre) throw err(409, `Stock insuffisant pour ${p.nom} : ${Math.max(0, st.libre)} disponible(s).`);
    return { p, q };
  });
  const prescripteur = texte(d.prescripteur, { label: 'Prescripteur', max: 120 });
  const referenceExt = texte(d.reference_ext, { label: 'N° d’ordonnance', max: 60 });
  if (produits.some(x => x.p.psychotrope) && (!prescripteur || !referenceExt)) throw err(400, 'Psychotrope : indiquez le prescripteur et le n° d’ordonnance pour le registre (PHA-11).');
  return db.transaction(() => {
    let v;
    if (d.comptoir) {
      const now = new Date(), j = String(now.getFullYear()).slice(2) + pad(now.getMonth() + 1, 2) + pad(now.getDate(), 2);
      const numero = 'V-' + j + '-' + pad(R.suivant(db, 'passage:' + j), 3);
      v = R.passage(db, db.prepare('INSERT INTO passages(numero, patient_id, type, cree_le, cree_par) VALUES (?, NULL, ?, ?, ?)').run(numero, 'comptoir', maintenant(), u.id).lastInsertRowid);
    } else {
      v = R.passage(db, Number(d.passage_id));
      if (!v) throw err(404, 'Passage introuvable.');
      if (!R.passageOuvert(db, v)) throw err(409, 'Passage d’un autre jour : ouvrez un nouveau passage à l’accueil.');
    }
    const annee = new Date().getFullYear();
    const numero = `ORD-${annee}-${pad(R.suivant(db, 'ordonnance:' + annee), 5)}`;
    const oid = db.prepare('INSERT INTO ordonnances(numero, passage_id, patient_id, prescripteur, reference_ext, cree_le, cree_par) VALUES (?,?,?,?,?,?,?)')
      .run(numero, v.id, v.patient_id, prescripteur || null, referenceExt || null, maintenant(), u.id).lastInsertRowid;
    for (const { p, q } of produits) R.creerBon(db, u, v, { nature: 'produit', ref: p, libelle: p.nom, ordonnance_id: oid }, q, 'pharmacie');
    const cov = R.couvertureEffective(db, v);
    const du = db.prepare('SELECT * FROM bons WHERE ordonnance_id = ?').all(oid).reduce((s, b) => s + R.montants(b).net, 0);
    R.journal(db, u, 'Pharmacie', 'Ordonnance saisie', `${numero} pour ${R.nomPatient(R.patient(db, v.patient_id))} : ${produits.length} ligne(s), tarif ${cov ? (cov.niveau === 'maj' ? 'assurances majeures' : 'autres assurances') : 'non assurés'}, ${fmt(du)} à payer`);
    return { id: oid, numero, du, urgent: !!v.urgent };
  })();
}

/* RG-PHA-1 : aucune délivrance sans bon payé ou accordé (sauf urgence), et celui qui encaisse ne délivre pas. */
function delivrer(db, u, id) {
  const o = db.prepare('SELECT * FROM ordonnances WHERE id = ?').get(id);
  if (!o) throw err(404, 'Ordonnance introuvable.');
  const bons = db.prepare('SELECT * FROM bons WHERE ordonnance_id = ? AND annule = 0 AND delivre = 0').all(o.id);
  if (!bons.length) throw err(409, 'Rien à délivrer sur cette ordonnance.');
  const nonPayes = bons.filter(b => !b.paye && !b.urgent);
  if (nonPayes.length) {
    R.journal(db, u, 'Pharmacie', 'Délivrance bloquée', `${o.numero} : ${nonPayes.length} bon(s) non payé(s)`, { niveau: 'blocage' });
    throw err(409, `Délivrance bloquée : ${nonPayes.length} bon(s) non payé(s). Envoyez le patient à la caisse (règle d’or).`, { bloque: true });
  }
  const encaissePar = bons.filter(b => b.recu_id).map(b => db.prepare('SELECT caissier_id FROM recus WHERE id = ?').get(b.recu_id)).filter(Boolean);
  if (encaissePar.some(r => r.caissier_id === u.id)) throw err(403, 'Séparation des fonctions : vous avez encaissé ces bons, un autre agent doit les délivrer.');
  const jour = jourLocal();
  return db.transaction(() => {
    const sorties = [];
    for (const b of bons) {
      let reste = b.quantite;
      for (const lot of db.prepare('SELECT * FROM lots WHERE produit_id = ? AND quantite > 0 AND peremption >= ? ORDER BY peremption, id').all(b.produit_id, jour)) {
        if (reste <= 0) break;
        const q = Math.min(reste, lot.quantite);
        db.prepare('UPDATE lots SET quantite = quantite - ? WHERE id = ?').run(q, lot.id);
        db.prepare('INSERT INTO mouvements(lot_id, produit_id, type, quantite, motif, bon_id, utilisateur_id, cree_le) VALUES (?,?,?,?,?,?,?,?)')
          .run(lot.id, b.produit_id, 'delivrance', -q, o.numero, b.id, u.id, maintenant());
        sorties.push({ produit: b.libelle, lot: lot.numero, peremption: lot.peremption, quantite: q });
        reste -= q;
      }
      if (reste > 0) throw err(409, `Stock insuffisant pour ${b.libelle}.`);
      db.prepare('UPDATE bons SET delivre = 1, delivre_le = ?, delivre_par = ? WHERE id = ?').run(maintenant(), u.id, b.id);
    }
    db.prepare('UPDATE ordonnances SET delivre_le = ?, delivre_par = ?, lots = ? WHERE id = ?').run(maintenant(), u.id, JSON.stringify(sorties), o.id);
    const urgenceNonPayee = bons.some(b => b.urgent && !b.paye);
    R.journal(db, u, 'Pharmacie', 'Délivrance', `${o.numero}${urgenceNonPayee ? ' en urgence avant paiement, à régulariser' : ''} : ${sorties.map(s => `lot ${s.lot} × ${s.quantite}`).join(', ')}`, { niveau: urgenceNonPayee ? 'alerte' : null });
    const psy = bons.filter(b => (db.prepare('SELECT psychotrope FROM produits WHERE id = ?').get(b.produit_id) || {}).psychotrope);
    if (psy.length) R.journal(db, u, 'Pharmacie', 'Registre des psychotropes', `${o.numero} : ${psy.map(b => `${b.libelle} × ${b.quantite}`).join(', ')}, prescripteur ${o.prescripteur}, ordonnance ${o.reference_ext}`);
    return { sorties };
  })();
}

/* PHA-06 : réception contrôlée ; un lot déjà périmé est refusé. */
function receptionner(db, u, d) {
  if (!Number(d.produit_id)) throw err(400, 'Choisissez le produit reçu.');
  const p = db.prepare('SELECT * FROM produits WHERE id = ?').get(Number(d.produit_id));
  if (!p) throw err(400, 'Produit inconnu.');
  const numero = texte(d.numero, { label: 'N° de lot', max: 40, requis: true });
  const peremption = date(d.peremption, { label: 'Date de péremption' });
  const quantite = entier(d.quantite, { label: 'Quantité reçue', min: 1, max: 1000000 });
  const prixAchat = entier(d.prix_achat, { label: 'Prix d’achat unitaire', min: 0, max: 10000000 });
  const fournisseur = texte(d.fournisseur, { label: 'Fournisseur', max: 120, requis: true });
  if (peremption < jourLocal()) {
    R.journal(db, u, 'Pharmacie', 'Réception refusée', `${p.nom}, lot ${numero} déjà périmé (${peremption})`, { niveau: 'alerte' });
    throw err(409, 'Lot déjà périmé : réception refusée.');
  }
  return db.transaction(() => {
    const exist = db.prepare('SELECT * FROM lots WHERE produit_id = ? AND numero = ? AND peremption = ?').get(p.id, numero, peremption);
    const lotId = exist ? exist.id : db.prepare('INSERT INTO lots(produit_id, numero, peremption, quantite, prix_achat, fournisseur, cree_le) VALUES (?,?,?,0,?,?,?)')
      .run(p.id, numero, peremption, prixAchat, fournisseur, maintenant()).lastInsertRowid;
    db.prepare('UPDATE lots SET quantite = quantite + ?, prix_achat = ?, fournisseur = ? WHERE id = ?').run(quantite, prixAchat, fournisseur, lotId);
    db.prepare('INSERT INTO mouvements(lot_id, produit_id, type, quantite, motif, utilisateur_id, cree_le) VALUES (?,?,?,?,?,?,?)')
      .run(lotId, p.id, 'reception', quantite, fournisseur, u.id, maintenant());
    R.journal(db, u, 'Pharmacie', 'Réception', `${p.nom}, lot ${numero}, ${quantite} unité(s), péremption ${peremption}, ${fournisseur}`);
    return { jours: joursEntre(jourLocal(), peremption) };
  })();
}

/* PHA-07, PHA-09, PHA-10, RG-PHA-4 : au-delà du seuil de valeur, l'ajustement attend la direction. */
function ajuster(db, u, d, estDirection) {
  const lot = db.prepare('SELECT * FROM lots WHERE id = ?').get(Number(d.lot_id));
  if (!lot) throw err(404, 'Lot introuvable.');
  const type = String(d.type || '');
  if (!TYPES_AJUSTEMENT[type]) throw err(400, 'Type d’ajustement inconnu.');
  let q = entier(d.quantite, { label: 'Quantité', min: -1000000, max: 1000000 });
  if (!q) throw err(400, 'Quantité non nulle attendue.');
  if (SORTANTS.includes(type)) q = -Math.abs(q);
  if (type === 'retour_patient') q = Math.abs(q);
  const motif = texte(d.motif, { label: 'Motif', max: 300, requis: true });
  const service = type === 'sortie_interne' ? texte(d.service, { label: 'Service destinataire', max: 60, requis: true }) : null;
  if (lot.quantite + q < 0) throw err(409, `Quantité en stock insuffisante sur ce lot (${lot.quantite}).`);
  const p = db.prepare('SELECT * FROM produits WHERE id = ?').get(lot.produit_id);
  const valeur = Math.abs(q) * (lot.prix_achat || p.prix_non);
  const a = { lot_id: lot.id, produit: p.nom, lot: lot.numero, type, quantite: q, motif, service, valeur };
  if (!estDirection && valeur > R.params(db).seuil_ajustement) {
    db.transaction(() => {
      db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)').run('ajustement', JSON.stringify(a), motif, u.id, maintenant());
      R.journal(db, u, 'Pharmacie', 'Demande d’ajustement', `${TYPES_AJUSTEMENT[type]} ${p.nom} lot ${lot.numero} : ${q} (${fmt(valeur)}), motif : ${motif}`, { niveau: 'alerte' });
    })();
    return { en_attente: true };
  }
  db.transaction(() => appliquerAjustement(db, u, a))();
  return { en_attente: false };
}
function appliquerAjustement(db, u, a) {
  const lot = db.prepare('SELECT * FROM lots WHERE id = ?').get(a.lot_id);
  if (!lot || lot.quantite + a.quantite < 0) throw err(409, 'Stock du lot insuffisant pour appliquer l’ajustement.');
  db.prepare('UPDATE lots SET quantite = quantite + ? WHERE id = ?').run(a.quantite, lot.id);
  db.prepare('INSERT INTO mouvements(lot_id, produit_id, type, quantite, motif, service, utilisateur_id, cree_le) VALUES (?,?,?,?,?,?,?,?)')
    .run(lot.id, lot.produit_id, a.type, a.quantite, a.motif, a.service, u.id, maintenant());
  R.journal(db, u, 'Pharmacie', 'Ajustement de stock', `${TYPES_AJUSTEMENT[a.type]} ${a.produit} lot ${a.lot} : ${a.quantite > 0 ? '+' : ''}${a.quantite}${a.service ? ', vers ' + a.service : ''}, motif : ${a.motif}`,
    { niveau: a.valeur > R.params(db).seuil_ajustement ? 'alerte' : null });
}

module.exports = { TYPES_AJUSTEMENT, reserve, stockProduit, creerOrdonnance, delivrer, receptionner, ajuster, appliquerAjustement };
