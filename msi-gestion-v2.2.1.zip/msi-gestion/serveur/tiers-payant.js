'use strict';
/* Tiers payant (ASS-05 à ASS-08) : bordereaux numérotés par assureur, règlements, rejets, balance âgée.
   Un acte ne figure jamais sur deux bordereaux ; un bordereau émis ne change plus (hors rejets et règlements). */
const { pad, jourLocal, maintenant, jourDe, bornesPeriode, joursEntre, fmt, err, texte, entier, date, versCsv } = require('./outils');
const R = require('./regles');

const MODES_REGLEMENT = ['Virement', 'Chèque', 'Mobile money', 'Espèces'];
const CANDIDATS = `SELECT b.*, r.cree_le AS date_recu, r.numero AS recu FROM bons b JOIN recus r ON r.id = b.recu_id
  WHERE b.assureur_id IS NOT NULL AND b.annule = 0 AND b.taux > 0 AND b.paye = 1 AND r.annule = 0
  AND NOT EXISTS (SELECT 1 FROM bordereau_lignes l WHERE l.bon_id = b.id AND l.annule = 0)`;

function aFacturer(db) {
  const par = new Map();
  for (const b of db.prepare(CANDIDATS).all()) {
    const pa = R.montants(b).pa;
    if (!pa) continue;
    const x = par.get(b.assureur_id) || { assureur_id: b.assureur_id, lignes: 0, montant: 0, depuis: b.date_recu };
    x.lignes++; x.montant += pa; if (b.date_recu < x.depuis) x.depuis = b.date_recu;
    par.set(b.assureur_id, x);
  }
  return [...par.values()].map(x => ({ ...x, assureur: db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(x.assureur_id).nom, depuis: jourDe(x.depuis) }))
    .sort((a, b) => b.montant - a.montant);
}
function creerBordereau(db, u, d) {
  const a = db.prepare('SELECT * FROM assureurs WHERE id = ?').get(Number(d.assureur_id));
  if (!a) throw err(404, 'Assureur inconnu.');
  const du = date(d.du, { label: 'Début de période' }), au = date(d.au, { label: 'Fin de période' });
  if (au < du || au > jourLocal()) throw err(400, 'Période invalide.');
  const [debut, fin] = bornesPeriode(du, au);
  const lignes = db.prepare(`${CANDIDATS} AND b.assureur_id = ? AND r.cree_le >= ? AND r.cree_le < ? ORDER BY r.cree_le, b.id`).all(a.id, debut, fin)
    .map(b => ({ b, montant: R.montants(b).pa })).filter(l => l.montant > 0);
  if (!lignes.length) throw err(409, `Rien à facturer à ${a.nom} sur cette période.`);
  const total = lignes.reduce((s, l) => s + l.montant, 0);
  return db.transaction(() => {
    const an = new Date().getFullYear(), numero = `BRD-${an}-${pad(R.suivant(db, 'bordereau:' + an), 4)}`;
    const id = db.prepare('INSERT INTO bordereaux(numero, assureur_id, du, au, total, cree_le, cree_par) VALUES (?,?,?,?,?,?,?)').run(numero, a.id, du, au, total, maintenant(), u.id).lastInsertRowid;
    const ins = db.prepare('INSERT INTO bordereau_lignes(bordereau_id, bon_id, montant) VALUES (?,?,?)');
    for (const l of lignes) ins.run(id, l.b.id, l.montant);
    R.journal(db, u, 'Tiers payant', 'Bordereau émis', `${numero} pour ${a.nom}, du ${du} au ${au} : ${lignes.length} ligne(s), ${fmt(total)}`);
    return { id, numero, lignes: lignes.length, total };
  })();
}
function soldes(db, br) {
  const regle = db.prepare('SELECT COALESCE(SUM(montant),0) m FROM reglements_assureurs WHERE bordereau_id = ?').get(br.id).m;
  const rejete = db.prepare('SELECT COALESCE(SUM(montant),0) m FROM bordereau_lignes WHERE bordereau_id = ? AND rejete = 1 AND annule = 0').get(br.id).m;
  const reste = br.annule ? 0 : br.total - regle - rejete;
  return { regle, rejete, reste, statut: br.annule ? 'annule' : reste <= 0 ? 'solde' : regle || rejete ? 'partiel' : 'emis' };
}
function listeBordereaux(db) {
  return db.prepare('SELECT b.*, a.nom AS assureur FROM bordereaux b JOIN assureurs a ON a.id = b.assureur_id ORDER BY b.id DESC LIMIT 300').all().map(b => ({ ...b, ...soldes(db, b) }));
}
function lireBordereau(db, id) {
  const b = db.prepare('SELECT b.*, a.nom AS assureur, a.code AS code_assureur FROM bordereaux b JOIN assureurs a ON a.id = b.assureur_id WHERE b.id = ?').get(id);
  if (!b) throw err(404, 'Bordereau introuvable.');
  const lignes = db.prepare(`SELECT l.id, l.montant, l.rejete, l.motif_rejet, l.annule, bo.code, bo.libelle, bo.quantite, bo.prix, bo.taux, bo.cree_le, v.numero AS passage, v.accord,
    p.nom, p.prenoms, p.ipp, p.num_assure, r.numero AS recu FROM bordereau_lignes l JOIN bons bo ON bo.id = l.bon_id JOIN passages v ON v.id = bo.passage_id
    LEFT JOIN patients p ON p.id = bo.patient_id LEFT JOIN recus r ON r.id = bo.recu_id WHERE l.bordereau_id = ? ORDER BY bo.cree_le, l.id`).all(id);
  const pm = R.params(db);
  return { ...b, ...soldes(db, b), lignes, reglements: db.prepare('SELECT * FROM reglements_assureurs WHERE bordereau_id = ? ORDER BY id').all(id),
    etablissement: { raison: pm.raison, forme: pm.forme, adresse: pm.adresse, rccm: pm.rccm, ncc: pm.ncc, telephone: pm.telephone }, formation: !!pm.formation };
}
function csvBordereau(db, id) {
  const b = lireBordereau(db, id);
  return { nom: `${b.numero}-${b.code_assureur}.csv`, csv: versCsv([
    { titre: 'Date', v: l => jourDe(l.cree_le) }, { titre: 'Patient', v: l => `${l.nom} ${l.prenoms}` }, { titre: 'IPP', v: 'ipp' }, { titre: 'N° d’assuré', v: 'num_assure' },
    { titre: 'N° d’accord', v: 'accord' }, { titre: 'Passage', v: 'passage' }, { titre: 'Reçu', v: 'recu' }, { titre: 'Code', v: 'code' }, { titre: 'Libellé', v: 'libelle' },
    { titre: 'Quantité', v: 'quantite' }, { titre: 'Prix unitaire', v: 'prix' }, { titre: 'Total', v: l => l.prix * l.quantite }, { titre: 'Taux', v: 'taux' }, { titre: 'Part assureur', v: 'montant' },
    { titre: 'Rejet', v: l => (l.rejete ? l.motif_rejet : '') }], b.lignes.filter(l => !l.annule)) };
}
function actif(db, id) {
  const b = db.prepare('SELECT * FROM bordereaux WHERE id = ?').get(id);
  if (!b) throw err(404, 'Bordereau introuvable.');
  if (b.annule) throw err(409, 'Bordereau annulé.');
  return b;
}
function enregistrerReglement(db, u, id, d) {
  const b = actif(db, id);
  const jour = date(d.date, { label: 'Date du règlement' }), mode = String(d.mode || '');
  if (!MODES_REGLEMENT.includes(mode)) throw err(400, 'Mode de règlement inconnu.');
  const reference = texte(d.reference, { label: 'Référence du règlement', max: 60, requis: true });
  const montant = entier(d.montant, { label: 'Montant', min: 1, max: 1000000000 });
  const { reste } = soldes(db, b);
  if (montant > reste) throw err(409, `Montant supérieur au reste dû (${fmt(reste)}).`);
  const deja = db.prepare('SELECT x.id FROM reglements_assureurs x JOIN bordereaux y ON y.id = x.bordereau_id WHERE y.assureur_id = ? AND x.reference = ? COLLATE NOCASE').get(b.assureur_id, reference);
  if (deja) throw err(409, `Référence ${reference} déjà enregistrée pour cet assureur.`);
  db.transaction(() => {
    db.prepare('INSERT INTO reglements_assureurs(bordereau_id, date, mode, reference, montant, cree_le, cree_par) VALUES (?,?,?,?,?,?,?)').run(b.id, jour, mode, reference, montant, maintenant(), u.id);
    R.journal(db, u, 'Tiers payant', 'Règlement reçu', `${b.numero} : ${fmt(montant)} (${mode}, réf. ${reference})`);
  })();
  return soldes(db, b);
}
function rejeter(db, u, id, d) {
  const b = actif(db, id);
  const lignes = Array.isArray(d.lignes) ? d.lignes : [];
  if (!lignes.length) throw err(400, 'Choisissez les lignes rejetées.');
  const { reste } = soldes(db, b);
  db.transaction(() => {
    let montant = 0;
    for (const l of lignes) {
      const x = db.prepare('SELECT * FROM bordereau_lignes WHERE id = ? AND bordereau_id = ? AND annule = 0').get(Number(l.id), b.id);
      if (!x || x.rejete) throw err(409, 'Ligne introuvable ou déjà rejetée.');
      db.prepare('UPDATE bordereau_lignes SET rejete = 1, motif_rejet = ? WHERE id = ?').run(texte(l.motif, { label: 'Motif du rejet', max: 200, requis: true }), x.id);
      montant += x.montant;
    }
    if (montant > reste) throw err(409, 'Le rejet dépasse le reste dû du bordereau.');
    R.journal(db, u, 'Tiers payant', 'Rejet de l’assureur', `${b.numero} : ${lignes.length} ligne(s), ${fmt(montant)}`, { niveau: 'alerte' });
  })();
  return soldes(db, b);
}
function annulerBordereau(db, u, id, motifSaisi) {
  const b = actif(db, id);
  if (soldes(db, b).regle) throw err(409, 'Bordereau déjà réglé en partie : annulation impossible.');
  const motif = texte(motifSaisi, { label: 'Motif de l’annulation', max: 300, requis: true });
  db.transaction(() => {
    db.prepare('UPDATE bordereaux SET annule = 1, motif_annulation = ? WHERE id = ?').run(motif, b.id);
    db.prepare('UPDATE bordereau_lignes SET annule = 1 WHERE bordereau_id = ?').run(b.id);
    R.journal(db, u, 'Tiers payant', 'Bordereau annulé', `${b.numero} : ${motif}. Les actes redeviennent facturables.`, { niveau: 'alerte' });
  })();
}
/* Balance âgée : non facturé, puis reste dû par ancienneté du bordereau. */
function balanceAgee(db) {
  const par = new Map(), ligne = id => {
    if (!par.has(id)) par.set(id, { assureur: db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(id).nom, non_facture: 0, j30: 0, j60: 0, j90: 0, plus90: 0, total: 0 });
    return par.get(id);
  };
  for (const x of aFacturer(db)) { const l = ligne(x.assureur_id); l.non_facture += x.montant; l.total += x.montant; }
  for (const b of db.prepare('SELECT * FROM bordereaux WHERE annule = 0').all()) {
    const { reste } = soldes(db, b);
    if (reste <= 0) continue;
    const age = joursEntre(jourDe(b.cree_le), jourLocal()), l = ligne(b.assureur_id);
    l[age <= 30 ? 'j30' : age <= 60 ? 'j60' : age <= 90 ? 'j90' : 'plus90'] += reste;
    l.total += reste;
  }
  return [...par.values()].sort((a, b) => b.total - a.total);
}

/* ---------- Clôture mensuelle (v1.9) ----------
   Pour le mois choisi : un bordereau par assureur ayant des prises en charge à facturer, dans une seule transaction.
   Rejouable : seules les prises en charge non encore facturées sont reprises (un acte n'est jamais facturé deux fois). */
const lireMois = v => {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(v || ''))) throw err(400, 'Mois attendu au format AAAA-MM.');
  if (`${v}-01` > jourLocal()) throw err(400, 'Ce mois n’est pas encore commencé.');
  return String(v);
};
function bornesMois(periode) {
  const [y, m] = periode.split('-').map(Number), dernier = `${periode}-${pad(new Date(Date.UTC(y, m, 0)).getUTCDate(), 2)}`;
  return { du: `${periode}-01`, dernier, au: dernier > jourLocal() ? jourLocal() : dernier };
}
const moisFr = p => { const [y, m] = p.split('-').map(Number); return new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' }); };
function apercuMois(db, periode) {
  const { du, au } = bornesMois(periode), [debut, fin] = bornesPeriode(du, au), par = new Map();
  for (const b of db.prepare(`${CANDIDATS} AND r.cree_le >= ? AND r.cree_le < ?`).all(debut, fin)) {
    const pa = R.montants(b).pa;
    if (!pa) continue;
    const x = par.get(b.assureur_id) || { assureur_id: b.assureur_id, lignes: 0, montant: 0 };
    x.lignes++; x.montant += pa; par.set(b.assureur_id, x);
  }
  return [...par.values()].map(x => ({ ...x, assureur: db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(x.assureur_id).nom })).sort((a, b) => b.montant - a.montant);
}
function cloturerMois(db, u, d) {
  const periode = lireMois(d.periode), { du, au } = bornesMois(periode), a = apercuMois(db, periode);
  if (!a.length) throw err(409, `Rien à facturer aux assureurs pour ${moisFr(periode)} : toutes les prises en charge du mois sont déjà sur un bordereau.`);
  return db.transaction(() => {
    const crees = a.map(x => ({ ...creerBordereau(db, u, { assureur_id: x.assureur_id, du, au }), assureur: x.assureur }));
    const total = crees.reduce((s, b) => s + b.total, 0);
    db.prepare('INSERT INTO clotures_mensuelles(periode, du, au, bordereaux, total, cree_par, cree_le) VALUES (?,?,?,?,?,?,?)').run(periode, du, au, JSON.stringify(crees.map(b => b.id)), total, u.id, maintenant());
    R.journal(db, u, 'Tiers payant', 'Clôture mensuelle', `${moisFr(periode)} : ${crees.length} bordereau${crees.length > 1 ? 'x' : ''} (${crees.map(b => `${b.numero} ${b.assureur}`).join(', ')}), ${fmt(total)}`);
    return { periode, mois: moisFr(periode), du, au, bordereaux: crees, total };
  })();
}
function rapportMois(db, periodeDemandee) {
  const periode = periodeDemandee ? lireMois(periodeDemandee) : jourLocal().slice(0, 7), { du, dernier, au } = bornesMois(periode), pm = R.params(db);
  const bordereaux = db.prepare('SELECT b.*, a.nom AS assureur FROM bordereaux b JOIN assureurs a ON a.id = b.assureur_id WHERE b.annule = 0 AND b.du >= ? AND b.au <= ? ORDER BY a.nom, b.id').all(du, dernier)
    .map(b => ({ ...b, ...soldes(db, b), lignes: db.prepare('SELECT COUNT(*) n FROM bordereau_lignes WHERE bordereau_id = ? AND annule = 0').get(b.id).n }));
  const services = db.prepare(`SELECT CASE WHEN bo.nature = 'produit' THEN 'Pharmacie' ELSE COALESCE(a.famille, 'Autres actes') END AS service, COUNT(*) AS lignes, SUM(l.montant) AS montant
    FROM bordereau_lignes l JOIN bordereaux b ON b.id = l.bordereau_id JOIN bons bo ON bo.id = l.bon_id LEFT JOIN actes a ON a.code = bo.code AND bo.nature = 'acte'
    WHERE l.annule = 0 AND b.annule = 0 AND b.du >= ? AND b.au <= ? GROUP BY service ORDER BY montant DESC`).all(du, dernier);
  const somme = k => bordereaux.reduce((s, b) => s + (b[k] || 0), 0);
  return {
    periode, mois: moisFr(periode), du, au, bordereaux, services, a_facturer: apercuMois(db, periode),
    total: somme('total'), regle: somme('regle'), rejete: somme('rejete'), reste: somme('reste'),
    clotures: db.prepare('SELECT c.id, c.du, c.au, c.total, c.cree_le, c.bordereaux, u.nom AS par FROM clotures_mensuelles c LEFT JOIN utilisateurs u ON u.id = c.cree_par WHERE c.periode = ? ORDER BY c.id')
      .all(periode).map(c => ({ ...c, bordereaux: JSON.parse(c.bordereaux).length })),
    etablissement: { raison: pm.raison, forme: pm.forme, adresse: pm.adresse, rccm: pm.rccm, ncc: pm.ncc, telephone: pm.telephone }, formation: !!pm.formation
  };
}

module.exports = { apercuMois, cloturerMois, rapportMois, moisFr, MODES_REGLEMENT, aFacturer, creerBordereau, listeBordereaux, lireBordereau, csvBordereau, enregistrerReglement, rejeter, annulerBordereau, balanceAgee };
