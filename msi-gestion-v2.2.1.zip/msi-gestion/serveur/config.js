'use strict';
/* Configuration : config.json à la racine (facultatif), sinon valeurs par défaut.
   --formation : base de formation séparée, port suivant, sans copie cloud. */
const fs = require('fs');
const path = require('path');

const RACINE = path.join(__dirname, '..');
const DEFAUT = {
  port: 8080,
  hote: '0.0.0.0',
  en_ligne: false,
  base: 'donnees/msi.db',
  fuseau: 'Africa/Abidjan',
  sauvegarde: { dossier: 'donnees/sauvegardes', dossier_cloud: '', intervalle_min: 15 }
};

function lireConfig(formation = process.argv.includes('--formation')) {
  const f = path.join(RACINE, 'config.json');
  const lu = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {};
  const c = { ...DEFAUT, ...lu, sauvegarde: { ...DEFAUT.sauvegarde, ...(lu.sauvegarde || {}) } };
  if (formation) {
    c.base = 'donnees/formation.db';
    c.port = Number(c.port) + 1;
    c.sauvegarde = { dossier: 'donnees/sauvegardes-formation', dossier_cloud: '', intervalle_min: 60 };
  }
  /* v2.0 : hébergement en ligne. Les variables d'environnement priment (serveur cloud, conteneur). */
  const env = process.env;
  if (env.MSI_EN_LIGNE !== undefined) c.en_ligne = /^(1|true|oui)$/i.test(env.MSI_EN_LIGNE);
  if (env.MSI_PORT) c.port = Number(env.MSI_PORT);
  /* v2.2.1 : un hébergeur géré (Render, Railway…) impose son port par la variable PORT : elle prime. */
  if (env.PORT) c.port = Number(env.PORT);
  if (env.MSI_HOTE) c.hote = env.MSI_HOTE;
  if (env.MSI_DOSSIER_CLOUD) c.sauvegarde.dossier_cloud = env.MSI_DOSSIER_CLOUD;
  c.formation = formation;
  c.fichier = path.resolve(RACINE, c.base);
  c.dossier_donnees = path.dirname(c.fichier);
  c.sauvegarde.dossier = path.resolve(RACINE, c.sauvegarde.dossier);
  c.sauvegarde.dossier_cloud = c.sauvegarde.dossier_cloud ? path.resolve(RACINE, c.sauvegarde.dossier_cloud) : '';
  return c;
}

module.exports = { lireConfig, RACINE };
