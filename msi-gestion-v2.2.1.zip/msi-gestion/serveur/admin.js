'use strict';
/* Paramétrage : comptes (ADM-06), référentiels et tarifs (ADM-01, ADM-02, ASS-01, PHA-01, PHA-02), imports CSV. */
const { maintenant, err, texte, entier, lireCsv, norm } = require('./outils');
const R = require('./regles');
const A = require('./auth');

/* Comptes nominatifs ; le mot de passe provisoire n'est affiché qu'une fois. */
function lireRoles(v) {
  const roles = (Array.isArray(v) ? v : String(v || '').split(',')).map(x => String(x).trim()).filter(Boolean);
  if (!roles.length || roles.some(r => !A.ROLES[r])) throw err(400, 'Profil inconnu ou manquant.');
  if (roles.includes('caisse') && roles.includes('pharmacie')) throw err(400, 'Séparation des fonctions : un même compte ne peut pas encaisser et délivrer.');
  if (roles.includes('caisse') && roles.includes('medecin')) throw err(400, 'Séparation des fonctions : celui qui prescrit n’encaisse pas.');
  if (roles.includes('caisse') && roles.includes('laboratoire')) throw err(400, 'Séparation des fonctions : celui qui réalise l’examen n’encaisse pas.');
  return [...new Set(roles)].join(',');
}
const S = require('../public/js/specialites');
function lireSpecialites(v, roles) {
  const l = (Array.isArray(v) ? v : String(v || '').split(',')).map(x => String(x).trim()).filter(Boolean);
  if (l.some(x => !S.SPECIALITES[x])) throw err(400, 'Spécialité inconnue.');
  if (roles.includes('medecin') && !l.length) throw err(400, 'Indiquez au moins une spécialité pour un compte médecin.');
  return roles.includes('medecin') ? [...new Set(l)].join(',') : null;
}
function creerUtilisateur(db, u, d) {
  const login = texte(d.login, { label: 'Identifiant', max: 40, requis: true }).toLowerCase();
  if (!/^[a-z0-9._-]{3,40}$/.test(login)) throw err(400, 'Identifiant : 3 à 40 caractères (lettres, chiffres, point, tiret).');
  if (db.prepare('SELECT 1 FROM utilisateurs WHERE login = ?').get(login)) throw err(409, 'Cet identifiant existe déjà.');
  const nom = texte(d.nom, { label: 'Nom complet', max: 80, requis: true });
  const roles = lireRoles(d.roles), mdp = A.mdpProvisoire();
  const specialites = lireSpecialites(d.specialites, roles), ordre = texte(d.ordre, { label: 'N° d’inscription à l’Ordre', max: 40 }) || null;
  const telephone = R.formaterTelephone(texte(d.telephone, { label: 'Téléphone', max: 30 })) || null;
  db.transaction(() => {
    db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, cree_le, specialites, ordre, telephone) VALUES (?,?,?,?,?,?,?,?)').run(login, nom, roles, A.hacher(mdp), maintenant(), specialites, ordre, telephone);
    R.journal(db, u, 'Administration', 'Création de compte', `${login} (${nom}) : ${roles}`, { apres: { login, nom, roles } });
  })();
  return { login, mdp };
}
function modifierUtilisateur(db, u, id, d) {
  const avant = db.prepare('SELECT id, login, nom, roles, actif, specialites, ordre, telephone FROM utilisateurs WHERE id = ?').get(id);
  if (!avant) throw err(404, 'Compte introuvable.');
  const apres = { nom: texte(d.nom, { label: 'Nom complet', max: 80, requis: true }), roles: lireRoles(d.roles), actif: d.actif ? 1 : 0 };
  apres.specialites = lireSpecialites(d.specialites, apres.roles);
  apres.ordre = texte(d.ordre, { label: 'N° d’inscription à l’Ordre', max: 40 }) || null;
  apres.telephone = R.formaterTelephone(texte(d.telephone, { label: 'Téléphone', max: 30 })) || null;
  if (avant.id === u.id && (!apres.actif || !apres.roles.includes('admin'))) throw err(400, 'Vous ne pouvez pas retirer vos propres droits d’administration.');
  db.transaction(() => {
    db.prepare('UPDATE utilisateurs SET nom = ?, roles = ?, actif = ?, specialites = ?, ordre = ?, telephone = ? WHERE id = ?').run(apres.nom, apres.roles, apres.actif, apres.specialites, apres.ordre, apres.telephone, id);
    if (!apres.actif) db.prepare('DELETE FROM sessions WHERE utilisateur_id = ?').run(id);
    R.journal(db, u, 'Administration', 'Modification de compte', avant.login, { avant: { nom: avant.nom, roles: avant.roles, actif: avant.actif, specialites: avant.specialites, ordre: avant.ordre, telephone: avant.telephone }, apres, niveau: 'alerte' });
  })();
}
function reinitialiserMdp(db, u, id) {
  const c = db.prepare('SELECT login FROM utilisateurs WHERE id = ?').get(id);
  if (!c) throw err(404, 'Compte introuvable.');
  const mdp = A.mdpProvisoire();
  db.transaction(() => {
    db.prepare('UPDATE utilisateurs SET hash = ?, changer_mdp = 1, echecs = 0, bloque_jusqua = NULL WHERE id = ?').run(A.hacher(mdp), id);
    db.prepare('DELETE FROM sessions WHERE utilisateur_id = ?').run(id);
    R.journal(db, u, 'Administration', 'Réinitialisation de mot de passe', c.login, { niveau: 'alerte' });
  })();
  return { login: c.login, mdp };
}

/* Référentiels : toute modification est journalisée avec l'avant et l'après (RG-ADM-3). */
const prix = (v, label) => entier(v, { label, min: 0, max: 50000000 });
function lireActe(d) {
  return {
    code: texte(d.code, { label: 'Code', max: 30, requis: true }).toUpperCase(), libelle: texte(d.libelle, { label: 'Libellé', max: 160, requis: true }),
    famille: texte(d.famille, { label: 'Famille', max: 60, requis: true }), specialite: texte(d.specialite, { label: 'Spécialité', max: 60 }) || null,
    prix_non: prix(d.prix_non, 'Prix non assurés'), prix_maj: prix(d.prix_maj, 'Prix assurances majeures'), prix_aut: prix(d.prix_aut, 'Prix autres assurances'),
    actif: d.actif === undefined ? 1 : (d.actif ? 1 : 0)
  };
}
function lireProduit(d) {
  return {
    code: texte(d.code, { label: 'Code', max: 30, requis: true }).toUpperCase(), nom: texte(d.nom, { label: 'Nom commercial', max: 160, requis: true }),
    dci: texte(d.dci, { label: 'DCI', max: 120 }) || null, forme: texte(d.forme, { label: 'Forme et dosage', max: 80 }) || null, famille: texte(d.famille, { label: 'Famille', max: 60 }) || null,
    seuil: entier(d.seuil || 0, { label: 'Seuil minimal', min: 0, max: 1000000 }),
    prix_non: prix(d.prix_non, 'Prix non assurés'), prix_maj: prix(d.prix_maj, 'Prix assurances majeures'), prix_aut: prix(d.prix_aut, 'Prix autres assurances'),
    psychotrope: d.psychotrope ? 1 : 0, actif: d.actif === undefined ? 1 : (d.actif ? 1 : 0)
  };
}
function lireAssureur(d) {
  const niveau = String(d.niveau || '');
  if (!['maj', 'aut'].includes(niveau)) throw err(400, 'Niveau de prix : assurances majeures ou autres assurances.');
  return { code: texte(d.code, { label: 'Code', max: 30, requis: true }).toUpperCase(), nom: texte(d.nom, { label: 'Nom', max: 120, requis: true }), niveau, actif: d.actif === undefined ? 1 : (d.actif ? 1 : 0) };
}
/* Chambres d'hospitalisation (v1.7) : numéro, libellé, catégorie standard ou VIP, nombre de lits. */
function lireChambre(d) {
  const code = texte(d.code, { label: 'Numéro de chambre', max: 10, requis: true }).toUpperCase();
  if (!['standard', 'vip'].includes(d.categorie)) throw err(400, 'Catégorie : standard ou VIP.');
  return { code, nom: texte(d.nom, { label: 'Libellé', max: 60 }) || `Chambre ${code}`, categorie: d.categorie, lits: entier(d.lits, { label: 'Nombre de lits', min: 1, max: 12 }),
    actif: d.actif === false || d.actif === 0 || d.actif === '0' ? 0 : 1 };
}
const TABLES = {
  actes: { lire: lireActe, cols: ['code', 'libelle', 'famille', 'specialite', 'prix_non', 'prix_maj', 'prix_aut', 'actif'], valider: true, etiquette: 'Acte' },
  produits: { lire: lireProduit, cols: ['code', 'nom', 'dci', 'forme', 'famille', 'seuil', 'prix_non', 'prix_maj', 'prix_aut', 'psychotrope', 'actif'], valider: true, etiquette: 'Produit' },
  assureurs: { lire: lireAssureur, cols: ['code', 'nom', 'niveau', 'actif'], valider: false, etiquette: 'Assureur' },
  chambres: { lire: lireChambre, cols: ['code', 'nom', 'categorie', 'lits', 'actif'], valider: false, etiquette: 'Chambre' }
};
function sauverReferentiel(db, u, table, id, d) {
  const T = TABLES[table];
  if (!T) throw err(404, 'Référentiel inconnu.');
  const v = T.lire(d);
  return db.transaction(() => {
    const doublon = db.prepare(`SELECT id FROM ${table} WHERE code = ?`).get(v.code);
    if (doublon && doublon.id !== id) throw err(409, `Le code ${v.code} existe déjà.`);
    if (id) {
      const avant = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
      if (!avant) throw err(404, `${T.etiquette} introuvable.`);
      db.prepare(`UPDATE ${table} SET ${T.cols.map(c => `${c} = @${c}`).join(', ')}${T.valider ? ', a_valider = 0' : ''} WHERE id = @id`).run({ ...v, id });
      const diff = T.cols.filter(c => String(avant[c]) !== String(v[c]));
      R.journal(db, u, 'Paramétrage', `${T.etiquette} modifié`, `${v.code} ${v.libelle || v.nom}${avant.a_valider ? ', tarif validé' : ''} : ${diff.join(', ') || 'aucun changement'}`,
        { avant: Object.fromEntries(diff.map(c => [c, avant[c]])), apres: Object.fromEntries(diff.map(c => [c, v[c]])), niveau: diff.some(c => c.startsWith('prix')) ? 'alerte' : null });
      return id;
    }
    const nid = db.prepare(`INSERT INTO ${table} (${T.cols.join(', ')}) VALUES (${T.cols.map(c => '@' + c).join(', ')})`).run(v).lastInsertRowid;
    R.journal(db, u, 'Paramétrage', `${T.etiquette} créé`, `${v.code} ${v.libelle || v.nom}`, { apres: v });
    return nid;
  })();
}

/* Paramètres sensibles : direction seulement, avant et après journalisés. */
const PARAMS_EDITABLES = {
  plafond_remise: [0, 100], delai_controle: [0, 90], seuil_ajustement: [0, 10000000], inactivite_min: [5, 240], vacation_debut: [0, 23], vacation_fin: [0, 23],
  acte_urgence: 'texte', raison: 'texte', forme: 'texte', adresse: 'texte', rccm: 'texte', ncc: 'texte', telephone: 'texte', slogan: 'texte'
};
function modifierParametres(db, u, d) {
  const avant = R.params(db), changes = {};
  for (const [k, regle] of Object.entries(PARAMS_EDITABLES)) {
    if (d[k] === undefined) continue;
    const v = regle === 'texte' ? texte(d[k], { label: k, max: 160, requis: true }) : entier(d[k], { label: k, min: regle[0], max: regle[1] });
    if (String(v) !== String(avant[k])) changes[k] = v;
  }
  if (!Object.keys(changes).length) return 0;
  db.transaction(() => {
    for (const [k, v] of Object.entries(changes)) R.ecrireParam(db, k, v);
    R.journal(db, u, 'Direction', 'Paramètres modifiés', Object.keys(changes).join(', '),
      { avant: Object.fromEntries(Object.keys(changes).map(k => [k, avant[k]])), apres: changes, niveau: 'alerte' });
  })();
  return Object.keys(changes).length;
}

/* Imports CSV pour la mise en service (catalogue pharmacie, actes) : mise à jour par code, erreurs ligne par ligne. */
const oui = v => ['1', 'oui', 'o', 'x', 'vrai', 'true', 'yes'].includes(norm(v));
function importer(db, u, type, csv) {
  const lignes = lireCsv(csv);
  if (!lignes.length) throw err(400, 'Fichier vide ou illisible.');
  if (lignes.length > 5000) throw err(400, '5 000 lignes au maximum par import.');
  const res = { crees: 0, modifies: 0, lots: 0, erreurs: [] };
  db.transaction(() => {
    for (const l of lignes) {
      try {
        if (type === 'actes') {
          const v = lireActe(l);
          const ex = db.prepare('SELECT id FROM actes WHERE code = ?').get(v.code);
          if (ex) { db.prepare('UPDATE actes SET libelle=@libelle, famille=@famille, specialite=@specialite, prix_non=@prix_non, prix_maj=@prix_maj, prix_aut=@prix_aut, actif=@actif, a_valider=0 WHERE id=@id').run({ ...v, id: ex.id }); res.modifies++; }
          else { db.prepare('INSERT INTO actes(code, libelle, famille, specialite, prix_non, prix_maj, prix_aut, actif) VALUES (@code,@libelle,@famille,@specialite,@prix_non,@prix_maj,@prix_aut,@actif)').run(v); res.crees++; }
        } else if (type === 'produits') {
          const v = lireProduit({ ...l, psychotrope: oui(l.psychotrope) });
          const ex = db.prepare('SELECT id FROM produits WHERE code = ?').get(v.code);
          let pid;
          if (ex) { db.prepare('UPDATE produits SET nom=@nom, dci=@dci, forme=@forme, famille=@famille, seuil=@seuil, prix_non=@prix_non, prix_maj=@prix_maj, prix_aut=@prix_aut, psychotrope=@psychotrope, actif=@actif, a_valider=0 WHERE id=@id').run({ ...v, id: ex.id }); pid = ex.id; res.modifies++; }
          else { pid = db.prepare('INSERT INTO produits(code, nom, dci, forme, famille, seuil, prix_non, prix_maj, prix_aut, psychotrope, actif) VALUES (@code,@nom,@dci,@forme,@famille,@seuil,@prix_non,@prix_maj,@prix_aut,@psychotrope,@actif)').run(v).lastInsertRowid; res.crees++; }
          if (l.lot) {
            const q = entier(l.quantite, { label: 'Quantité du lot', min: 1, max: 1000000 });
            const per = String(l.peremption || '').trim();
            if (!/^\d{4}-\d{2}-\d{2}$/.test(per)) throw err(400, 'Péremption du lot : AAAA-MM-JJ.');
            const lid = db.prepare('INSERT INTO lots(produit_id, numero, peremption, quantite, prix_achat, fournisseur, cree_le) VALUES (?,?,?,?,?,?,?)')
              .run(pid, l.lot, per, q, l.prix_achat ? entier(l.prix_achat, { label: 'Prix d’achat', min: 0, max: 10000000 }) : null, l.fournisseur || 'Stock initial', maintenant()).lastInsertRowid;
            db.prepare('INSERT INTO mouvements(lot_id, produit_id, type, quantite, motif, utilisateur_id, cree_le) VALUES (?,?,?,?,?,?,?)').run(lid, pid, 'reception', q, 'Stock initial (import)', u.id, maintenant());
            res.lots++;
          }
        } else throw err(404, 'Type d’import inconnu.');
      } catch (e) {
        if (e.status === 404) throw e;
        res.erreurs.push({ ligne: l._ligne, message: e.message });
      }
    }
    if (res.erreurs.length) throw Object.assign(err(400, `Import annulé : ${res.erreurs.length} ligne(s) en erreur. Corrigez le fichier puis recommencez.`), { extra: res });
    R.journal(db, u, 'Paramétrage', `Import ${type}`, `${res.crees} créé(s), ${res.modifies} mis à jour, ${res.lots} lot(s) de stock initial`, { niveau: 'alerte' });
  })();
  return res;
}

/* Catalogue de la pharmacie (v1.5) : le gérant ajoute et modifie les médicaments. Un prix qu'il fixe ou change
   reste « à valider » par la direction avant la première vente (séparation des tâches) ; la direction valide en enregistrant. */
function sauverProduitPharmacie(db, u, id, d) {
  const T = TABLES.produits, v = T.lire(d), direction = u.roles.includes('direction');
  return db.transaction(() => {
    const doublon = db.prepare('SELECT id FROM produits WHERE code = ?').get(v.code);
    if (doublon && doublon.id !== id) throw err(409, `Le code ${v.code} existe déjà.`);
    if (id) {
      const avant = db.prepare('SELECT * FROM produits WHERE id = ?').get(id);
      if (!avant) throw err(404, 'Médicament introuvable.');
      const diff = T.cols.filter(c => String(avant[c]) !== String(v[c])), prixChange = diff.some(c => c.startsWith('prix'));
      const aValider = direction ? 0 : prixChange ? 1 : avant.a_valider;
      db.prepare(`UPDATE produits SET ${T.cols.map(c => `${c} = @${c}`).join(', ')}, a_valider = @aValider WHERE id = @id`).run({ ...v, id, aValider });
      R.journal(db, u, 'Pharmacie', 'Médicament modifié', `${v.code} ${v.nom} : ${diff.join(', ') || 'aucun changement'}${prixChange && aValider ? ', prix à valider par la direction' : ''}`,
        { avant: Object.fromEntries(diff.map(c => [c, avant[c]])), apres: Object.fromEntries(diff.map(c => [c, v[c]])), niveau: prixChange ? 'alerte' : null });
      return { id, a_valider: !!aValider };
    }
    const nid = db.prepare(`INSERT INTO produits (${T.cols.join(', ')}, a_valider) VALUES (${T.cols.map(c => '@' + c).join(', ')}, @aValider)`).run({ ...v, aValider: direction ? 0 : 1 }).lastInsertRowid;
    R.journal(db, u, 'Pharmacie', 'Médicament ajouté', `${v.code} ${v.nom}${direction ? '' : ', prix à valider par la direction'}`, { apres: v });
    return { id: nid, a_valider: !direction };
  })();
}

module.exports = { sauverProduitPharmacie, creerUtilisateur, modifierUtilisateur, reinitialiserMdp, sauverReferentiel, modifierParametres, importer, lireRoles, TABLES };
