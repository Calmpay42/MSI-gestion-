'use strict';
/* Garde-fou (reprise 1.7) : les écrans sont des scripts classiques qui partagent le même espace global.
   Deux déclarations de premier niveau du même nom dans deux écrans se remplacent sans aucun message d'erreur
   (cas réel : « rechargerDossier » de l'hospitalisation masquait celle de la consultation). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

test('Écrans : aucune déclaration de premier niveau en double', () => {
  const dossier = path.join(__dirname, '..', 'public', 'js'), vues = new Map();
  for (const f of fs.readdirSync(dossier).filter(x => x.endsWith('.js')).sort()) {
    fs.readFileSync(path.join(dossier, f), 'utf8').split('\n').forEach((l, i) => {
      const m = l.match(/^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/) || l.match(/^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/);
      if (m) vues.set(m[1], [...(vues.get(m[1]) || []), `${f}:${i + 1}`]);
    });
  }
  const doubles = [...vues].filter(([, v]) => v.length > 1).map(([k, v]) => `${k} (${v.join(', ')})`);
  assert.deepEqual(doubles, [], 'Déclarations en double : ' + doubles.join(' ; '));
});
