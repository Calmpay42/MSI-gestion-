'use strict';
/* Recette de la version 2.2 : modification d'une consultation validée (motif, version conservée) ;
   suppressions réservées à l'administrateur, sur demande motivée, avec décision tracée et notifiée. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');
const R = require('../serveur/regles');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, rh, raf, dir1, adm, meda, medb, fact;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null);
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
const notifs = async qui => (await qui.get('/api/etat')).data.notifications;
const decider = (qui, id, accepte, reponse) => qui.post(`/api/demandes/${id}/decision`, { accepte, reponse });
let n = 0;
async function patient(extra) {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'suppr' + n, prenoms: 'awa', sexe: 'F', naissance: `1980-05-${String(n).padStart(2, '0')}`, telephone: `07 33 00 00 ${String(n).padStart(2, '0')}`, ...extra });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  return p.data.id;
}
async function passagePaye(pid, extra) {
  const v = await accueil.post('/api/passages', { patient_id: pid || await patient(), type: 'consultation', acte_id: consultationMG(), ...extra });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0').all(v.data.id);
  const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode: 'Espèces', montant: bons.reduce((s, b) => s + R.montants(b).net, 0) }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return v.data.id;
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v22-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('rh', 'rh'); compte('raf', 'raf'); compte('dir1', 'direction'); compte('adm', 'admin');
  compte('meda', 'medecin', 'Médecine générale'); compte('medb', 'medecin', 'Médecine générale'); compte('fact', 'facturiste');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, rh, raf, dir1, adm, meda, medb, fact] = await Promise.all(['accueil', 'caisse', 'rh', 'raf', 'dir1', 'adm', 'meda', 'medb', 'fact'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Consultation validée : le médecin auteur la modifie avec un motif, la version précédente est conservée', async () => {
  const c = (await meda.post('/api/consultations', { passage_id: await passagePaye() })).data;
  const modif = (qui, donnees, motif) => qui.post(`/api/consultations/${c.id}/modification`, { donnees, motif });
  const m0 = await modif(meda, { motif: 'Céphalées', diagnostic: 'Migraine' }, 'Correction');
  assert.equal(m0.status, 409, 'avant validation : simple brouillon');
  const val = await meda.post(`/api/consultations/${c.id}/validation`, { donnees: { motif: 'Céphalées', diagnostic: 'Migraine' } });
  assert.equal(val.status, 200, JSON.stringify(val.data));
  assert.equal((await meda.put(`/api/consultations/${c.id}`, { donnees: { motif: 'X', diagnostic: 'Y' } })).status, 409, 'le brouillon ne s’écrit plus après validation');
  assert.equal((await modif(meda, { motif: 'Céphalées', diagnostic: 'Migraine sans aura' }, '')).status, 400, 'motif obligatoire');
  assert.equal((await modif(medb, { motif: 'Céphalées', diagnostic: 'Autre' }, 'Erreur de saisie')).status, 403, 'seul l’auteur modifie');
  const m = await modif(meda, { motif: 'Céphalées', diagnostic: 'Migraine sans aura' }, 'Précision du diagnostic');
  assert.equal(m.status, 200, JSON.stringify(m.data));
  assert.equal(m.data.versions, 1);
  const lu = (await meda.get(`/api/consultations/${c.id}`)).data;
  assert.equal(lu.donnees.diagnostic, 'Migraine sans aura');
  assert.ok(lu.valide_le, 'reste validée');
  assert.deepEqual([lu.versions.length, lu.versions[0].motif, lu.versions[0].diagnostic, lu.versions[0].par], [1, 'Précision du diagnostic', 'Migraine', 'MEDA']);
  assert.equal((await modif(meda, { motif: '', diagnostic: '' }, 'Effacement complet')).status, 400, 'motif de consultation et diagnostic restent obligatoires');
  assert.throws(() => db.prepare("UPDATE consultations SET diagnostic = 'Falsifié', maj_le = '2030-01-01T00:00:00.000Z' WHERE id = ?").run(c.id), /non modifiable/, 'modification sans version : refusée par la base');
  assert.throws(() => db.prepare("UPDATE consultations SET medecin_id = ? WHERE id = ?").run(1, c.id), /non modifiable/, 'médecin figé');
  assert.throws(() => db.prepare('DELETE FROM consultation_versions').run(), /Suppression interdite/);
  assert.throws(() => db.prepare("UPDATE consultation_versions SET motif = 'x'").run(), /non modifiable/);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Consultation modifiée après validation' AND detail LIKE '%Précision du diagnostic%'").get());
});

test('Créneau de planning : demande des RH, notification et décision de l’administrateur, demandeur prévenu', async () => {
  const emp = (await rh.post('/api/rh/employes', { nom: 'SUPPR', prenoms: 'Agent', sexe: 'F', fonction: 'Aide-soignant', contrat: 'CDI', embauche_le: '2025-01-06', salaire_base: 100000 })).data.id;
  const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const cr = await rh.post('/api/rh/planning', { employe_id: emp, jour: demain, type: 'garde', debut: '18:00', fin: '08:00' });
  assert.equal(cr.status, 200, JSON.stringify(cr.data));
  assert.equal((await rh.post(`/api/rh/planning/${cr.data.id}/annulation`)).status, 403, 'les RH ne suppriment plus directement');
  const d = await rh.post('/api/suppressions', { objet: 'creneau', id: cr.data.id, motif: 'Garde saisie sur le mauvais agent' });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.ok((await notifs(adm)).some(x => x.titre === 'Demande de suppression' && /SUPPR/.test(x.message)), 'administrateur prévenu');
  assert.ok((await adm.get('/api/etat')).data.suppressions.some(x => x.id === d.data.id && x.statut === 'en_attente' && /créneau/.test(x.libelle)));
  assert.equal((await decider(dir1, d.data.id, true)).status, 403, 'la direction ne décide pas des suppressions');
  assert.equal((await decider(caisse, d.data.id, true)).status, 403);
  assert.equal((await decider(adm, d.data.id, true)).status, 200);
  assert.ok(db.prepare('SELECT annule_le FROM planning WHERE id = ?').get(cr.data.id).annule_le);
  assert.ok((await notifs(rh)).some(x => x.titre === 'Demande acceptée'), 'demandeur prévenu');
});

test('Bulletin de paie : demande refusée par l’administrateur avec une réponse, bulletin intact', async () => {
  const emp = (await rh.post('/api/rh/employes', { nom: 'REFUS', prenoms: 'Agent', sexe: 'M', fonction: 'Aide-soignant', contrat: 'CDI', embauche_le: '2025-01-06', salaire_base: 120000 })).data.id;
  const bp = (await rh.post('/api/rh/paies/preparation', { periode: new Date().toISOString().slice(0, 7), employe_id: emp })).data.prepares[0];
  const d = await raf.post('/api/suppressions', { objet: 'bulletin', id: bp.id, motif: 'Bulletin préparé en double' });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.equal((await decider(adm, d.data.id, false, 'Le bulletin est correct : vérifiez la période.')).status, 200);
  assert.equal(db.prepare('SELECT statut FROM paies WHERE id = ?').get(bp.id).statut, 'prepare');
  const dm = db.prepare('SELECT statut, reponse FROM demandes WHERE id = ?').get(d.data.id);
  assert.deepEqual([dm.statut, dm.reponse], ['refusee', 'Le bulletin est correct : vérifiez la période.']);
  assert.ok((await notifs(raf)).some(x => x.titre === 'Demande refusée' && /vérifiez la période/.test(x.message)));
});

test('Doublon de patient et bordereau : fusion et annulation exécutées à l’acceptation de l’administrateur', async () => {
  const p1 = await patient(), p2 = await patient();
  const d1 = await accueil.post('/api/suppressions', { objet: 'doublon', id: p1, vers_id: p2, motif: 'Même patiente enregistrée deux fois' });
  assert.equal(d1.status, 200, JSON.stringify(d1.data));
  assert.equal((await decider(adm, d1.data.id, true)).status, 200);
  assert.equal(db.prepare('SELECT fusionne_dans FROM patients WHERE id = ?').get(p1).fusionne_dans, p2);
  const a1 = db.prepare('SELECT id FROM assureurs WHERE actif = 1 ORDER BY id LIMIT 1').get().id, jour = new Date().toISOString().slice(0, 10);
  await passagePaye(await patient({ assureur_id: a1, num_assure: 'SUP-1', taux: 80, validite: '2030-12-31' }), { accord: 'ACC-SUP-1' });
  const b = await raf.post('/api/bordereaux', { assureur_id: a1, du: jour, au: jour });
  assert.equal(b.status, 200, JSON.stringify(b.data));
  const d2 = await fact.post('/api/suppressions', { objet: 'bordereau', id: b.data.id, motif: 'Période saisie par erreur' });
  assert.equal(d2.status, 200, JSON.stringify(d2.data));
  assert.equal((await decider(adm, d2.data.id, true)).status, 200);
  assert.equal(db.prepare('SELECT annule FROM bordereaux WHERE id = ?').get(b.data.id).annule, 1);
});

test('Reçus et remises : l’annulation d’un reçu est décidée par l’administrateur, une remise reste à la direction', async () => {
  const v = await passagePaye();
  const recu = db.prepare('SELECT r.id, r.numero FROM recus r JOIN bons b ON b.recu_id = r.id WHERE b.passage_id = ?').get(v);
  assert.equal((await caisse.post(`/api/recus/${recu.id}/annulation`, { motif: 'Patient reparti sans consulter' })).status, 200);
  const an = db.prepare("SELECT id FROM demandes WHERE type = 'annulation' AND statut = 'en_attente' ORDER BY id DESC").get().id;
  assert.ok((await adm.get('/api/etat')).data.suppressions.some(x => x.id === an && x.description.includes(recu.numero)), 'visible chez l’administrateur');
  assert.ok(!(await dir1.get('/api/etat')).data.demandes.some(x => x.id === an), 'plus chez la direction');
  assert.equal((await decider(dir1, an, true)).status, 403);
  assert.equal((await decider(adm, an, true)).status, 200);
  assert.equal(db.prepare('SELECT annule FROM recus WHERE id = ?').get(recu.id).annule, 1);
  const pid = await patient(), vr = await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: consultationMG() });
  const bons = db.prepare('SELECT id FROM bons WHERE passage_id = ?').all(vr.data.id).map(x => x.id);
  assert.equal((await caisse.post('/api/caisse/remise', { bon_ids: bons, pct: 30, motif: 'Patient indigent' })).status, 200);
  const rem = db.prepare("SELECT id FROM demandes WHERE type = 'remise' AND statut = 'en_attente' ORDER BY id DESC").get().id;
  assert.equal((await decider(adm, rem, true)).status, 403, 'une remise n’est pas une suppression');
  assert.equal((await decider(dir1, rem, true)).status, 200);
});
