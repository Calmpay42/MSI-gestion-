'use strict';
/* Direction : validations (séparation des fonctions), état de travail des postes, indicateurs et exports. */
const { pad, jourLocal, maintenant, bornesJour, bornesPeriode, fmt, err, versCsv } = require('./outils');
const R = require('./regles');
const C = require('./caisse');
const P = require('./pharmacie');
const { peut } = require('./auth');
const CL = require('./clinique');
const F = require('./facturation');

const SUP = require('./suppressions');
function decider(db, u, id, accepte, reponseSaisie) {
  if (!peut(u, 'valider') && !peut(u, 'supprimer')) throw err(403, 'Décision réservée à la direction ou à l’administrateur.');
  return db.transaction(() => {
    const d = db.prepare('SELECT * FROM demandes WHERE id = ?').get(id);
    if (!d || d.statut !== 'en_attente') throw err(409, 'Demande déjà traitée ou introuvable.');
    if (d.demandeur_id === u.id) throw err(403, 'Séparation des fonctions : vous ne pouvez pas valider votre propre demande.');
    /* v2.2 : les suppressions et les annulations de reçus sont décidées par l'administrateur ; le reste par la direction. */
    const suppression = ['suppression', 'annulation'].includes(d.type);
    if (suppression ? !peut(u, 'supprimer') : !peut(u, 'valider')) throw err(403, suppression ? 'Seul l’administrateur décide des suppressions et des annulations.' : 'Décision réservée à la direction.');
    const x = JSON.parse(d.donnees);
    let detail = '';
    if (d.type === 'remise') {
      for (const b of db.prepare('SELECT * FROM bons WHERE demande_id = ?').all(d.id)) {
        db.prepare('UPDATE bons SET demande_id = NULL WHERE id = ?').run(b.id);
        if (accepte && !b.paye && !b.annule) db.prepare('UPDATE bons SET remise_pct = ? WHERE id = ?').run(x.pct, b.id);
      }
      detail = `Remise de ${x.pct} % pour ${x.patient}`;
    } else if (d.type === 'annulation') {
      const r = db.prepare('SELECT * FROM recus WHERE id = ?').get(x.recu_id);
      if (accepte) {
        if (!r || r.annule) throw err(409, 'Reçu déjà annulé.');
        if (db.prepare('SELECT 1 FROM bons WHERE recu_id = ? AND delivre = 1').get(r.id)) throw err(409, 'Produits délivrés entre-temps : annulation impossible sans retour.');
        const annee = new Date().getFullYear();
        const avoir = `AV-${annee}-${pad(R.suivant(db, 'avoir:' + annee), 4)}`;
        const ouverte = db.prepare('SELECT id FROM caisse_sessions WHERE id = ? AND fermee_le IS NULL').get(r.session_id);
        db.prepare('UPDATE recus SET annule = 1, avoir = ?, annule_le = ?, motif_annulation = ?, rembourse_session_id = ?, rembourse_le = ? WHERE id = ?')
          .run(avoir, maintenant(), d.motif, ouverte ? r.session_id : null, ouverte ? maintenant() : null, r.id);
        db.prepare('UPDATE bons SET annule = 1 WHERE recu_id = ?').run(r.id);
        const pav = db.prepare('SELECT montant FROM paiements WHERE recu_id = ? AND mode = ?').get(r.id, R.AVANCE);
        if (pav) F.restituer(db, u, r.patient_id, pav.montant, r.id, `Restitution sur l’avoir ${avoir}`);
        detail = `Annulation du reçu ${r.numero} : avoir ${avoir}${ouverte ? '' : ', remboursement à effectuer en caisse'}`;
      } else detail = `Annulation du reçu ${x.numero}`;
    } else if (d.type === 'suppression') {
      detail = SUP.executer(db, u, d, accepte);
    } else if (d.type === 'ecart') {
      if (accepte) db.prepare('UPDATE caisse_sessions SET ecart_valide_par = ?, ecart_valide_le = ? WHERE id = ?').run(u.id, maintenant(), x.session_id);
      detail = `Écart de caisse de ${fmt(x.ecart)} (${x.caissier})`;
    } else if (d.type === 'remboursement_avance') {
      if (accepte) F.appliquerRemboursement(db, u, d, x);
      detail = `Remboursement d’avance de ${fmt(x.montant)} pour ${x.patient}`;
    } else if (d.type === 'ajustement') {
      if (accepte) P.appliquerAjustement(db, u, x);
      detail = `Ajustement de stock ${x.produit} lot ${x.lot} : ${x.quantite}`;
    } else throw err(400, 'Type de demande inconnu.');
    db.prepare('UPDATE demandes SET statut = ?, decideur_id = ?, decide_le = ?, reponse = ? WHERE id = ?').run(accepte ? 'validee' : 'refusee', u.id, maintenant(), String(reponseSaisie || '').trim().slice(0, 300) || null, d.id);
    R.journal(db, u, 'Direction', accepte ? 'Validation' : 'Refus', detail, { niveau: 'decision' });
  })();
}

/* Indicateurs du jour et contrôles anti-fuite (verrous 3 et 6). */
function indicateurs(db, stock) {
  const [debut] = bornesJour(jourLocal());
  const mois = jourLocal().slice(0, 8) + '01';
  const [debutMois] = bornesJour(mois);
  const bonsJour = db.prepare('SELECT * FROM bons WHERE cree_le >= ? AND annule = 0').all(debut);
  const recus = db.prepare('SELECT * FROM recus WHERE cree_le >= ? AND annule = 0').all(debut);
  const payes = db.prepare('SELECT b.* FROM bons b JOIN recus r ON r.id = b.recu_id WHERE r.cree_le >= ? AND b.annule = 0').all(debut);
  const clotures = db.prepare('SELECT * FROM caisse_sessions WHERE fermee_le >= ?').all(debut);
  const modes = {};
  for (const p of db.prepare('SELECT p.mode, SUM(p.montant) m FROM paiements p JOIN recus r ON r.id = p.recu_id WHERE r.cree_le >= ? AND r.annule = 0 GROUP BY p.mode').all(debut)) modes[p.mode] = p.m;
  const assureurs = {};
  for (const b of db.prepare('SELECT b.*, a.nom AS assureur FROM bons b JOIN recus r ON r.id = b.recu_id JOIN assureurs a ON a.id = b.assureur_id WHERE r.cree_le >= ? AND b.annule = 0').all(debutMois)) {
    const pa = R.montants(b).pa;
    if (!pa) continue;
    assureurs[b.assureur] = assureurs[b.assureur] || { bons: 0, montant: 0 };
    assureurs[b.assureur].bons++; assureurs[b.assureur].montant += pa;
  }
  const nonEnc = bonsJour.filter(b => !b.paye);
  const urg = db.prepare('SELECT * FROM bons WHERE urgent = 1 AND paye = 0 AND annule = 0').all();
  return {
    passages: db.prepare('SELECT COUNT(*) n FROM passages WHERE cree_le >= ?').get(debut).n,
    consultations: db.prepare('SELECT COUNT(*) n FROM consultations WHERE valide_le >= ?').get(debut).n,
    examens_non_realises: require('./laboratoire').nonRealises(db),
    consultations_bloquees: db.prepare("SELECT COUNT(*) n FROM audit WHERE action = 'Consultation bloquée' AND t >= ?").get(debut).n,
    facture: bonsJour.reduce((s, b) => s + R.montants(b).total, 0),
    encaisse: recus.reduce((s, r) => s + r.net, 0),
    part_assureurs: payes.reduce((s, b) => s + R.montants(b).pa, 0),
    remises: recus.reduce((s, r) => s + r.remise, 0),
    clotures: clotures.length,
    ecart: clotures.reduce((s, c) => s + c.ecart, 0),
    delivrances_sans_paiement: db.prepare('SELECT COUNT(*) n FROM bons WHERE delivre = 1 AND paye = 0 AND urgent = 0 AND annule = 0').get().n,
    tentatives_bloquees: db.prepare("SELECT COUNT(*) n FROM audit WHERE niveau = 'blocage' AND t >= ?").get(debut).n,
    non_encaisses: { n: nonEnc.length, montant: nonEnc.reduce((s, b) => s + R.montants(b).net, 0) },
    urgences: { n: urg.length, montant: urg.reduce((s, b) => s + R.montants(b).net, 0) },
    avoirs: db.prepare('SELECT COUNT(*) n FROM recus WHERE annule_le >= ?').get(debut).n,
    provisoires: db.prepare('SELECT COUNT(*) n FROM patients WHERE provisoire = 1 AND fusionne_dans IS NULL').get().n,
    doublons_forces: db.prepare("SELECT COUNT(*) n FROM audit WHERE action = 'Création de dossier' AND niveau = 'alerte' AND detail LIKE '%doublon%' AND t >= ?").get(debut).n,
    passages_annules: db.prepare("SELECT COUNT(*) n FROM audit WHERE action = 'Annulation de passage' AND t >= ?").get(debut).n,
    passages_doubles: db.prepare("SELECT COUNT(*) n FROM audit WHERE action = 'Ouverture de passage' AND niveau = 'alerte' AND detail LIKE '%déjà ouvert%' AND t >= ?").get(debut).n,
    tarifs_a_valider: db.prepare('SELECT (SELECT COUNT(*) FROM actes WHERE a_valider = 1 AND actif = 1) + (SELECT COUNT(*) FROM produits WHERE a_valider = 1 AND actif = 1) n').get().n,
    modes, assureurs_mois: assureurs,
    stock: {
      ruptures: stock.filter(s => s.stock.rupture).map(s => s.nom),
      sous_seuil: stock.filter(s => s.stock.sous_seuil).map(s => s.nom),
      p30: stock.filter(s => s.stock.p30).map(s => s.nom),
      perimes: stock.filter(s => s.stock.perimes > 0).map(s => s.nom)
    }
  };
}

/* État de travail envoyé aux postes : la journée en cours et tout ce qui reste ouvert. */
const N = require('./notifications');
const H = require('./hospitalisation');
function etat(db, u) {
  const [debut] = bornesJour(jourLocal());
  const pids = `SELECT id FROM passages WHERE cree_le >= @debut OR id IN (SELECT passage_id FROM bons WHERE paye = 0 AND annule = 0) OR id IN (SELECT passage_id FROM ordonnances WHERE delivre_le IS NULL) OR id IN (SELECT passage_id FROM hospitalisations WHERE statut = 'en_cours')`;
  const passages = db.prepare(`SELECT * FROM passages WHERE id IN (${pids}) ORDER BY cree_le DESC`).all({ debut });
  /* v2.2 : un passage dont l'annulation est demandée à l'administrateur est signalé aux postes (et ne s'encaisse pas). */
  const supEnAttente = new Set(db.prepare("SELECT donnees FROM demandes WHERE type = 'suppression' AND statut = 'en_attente'").all().map(r => JSON.parse(r.donnees)).filter(x => x.objet === 'passage').map(x => x.id));
  for (const v of passages) v.suppression_demandee = supEnAttente.has(v.id);
  const bons = db.prepare(`SELECT * FROM bons WHERE passage_id IN (${pids}) ORDER BY id`).all({ debut }).map(b => ({ ...b, ...R.montants(b) }));
  const patients = db.prepare(`SELECT ${R.COLS_PATIENT} FROM patients WHERE id IN (SELECT patient_id FROM passages WHERE id IN (${pids}))`).all({ debut }).map(p => R.enrichirPatient(db, p));
  const sessions = db.prepare('SELECT * FROM caisse_sessions WHERE fermee_le IS NULL OR fermee_le >= ? ORDER BY ouverte_le').all(debut)
    .map(s => ({ ...s, especes: s.fermee_le ? null : C.especes(db, s) }));
  const recus = db.prepare(`SELECT * FROM recus WHERE cree_le >= @debut OR session_id IN (SELECT id FROM caisse_sessions WHERE fermee_le IS NULL)
    OR (annule = 1 AND rembourse_session_id IS NULL) OR annule_le >= @debut ORDER BY cree_le DESC`).all({ debut });
  const paiements = recus.length ? db.prepare(`SELECT * FROM paiements WHERE recu_id IN (${recus.map(() => '?').join(',')})`).all(...recus.map(r => r.id)) : [];
  /* Les patients des reçus de la liste sont toujours nommés, même si leur passage n’est pas du jour. */
  for (const pid of new Set(recus.map(r => r.patient_id).filter(Boolean))) {
    if (!patients.some(x => x.id === pid)) { const x = R.patient(db, pid); if (x) patients.push(R.enrichirPatient(db, x)); }
  }
  const produits = db.prepare('SELECT * FROM produits ORDER BY nom').all().map(p => ({ ...p, stock: P.stockProduit(db, p) }));
  const pm = R.params(db);
  const e = {
    jour: jourLocal(), vacation: R.vacation(pm), formation: !!pm.formation,
    parametres: { plafond_remise: pm.plafond_remise, delai_controle: pm.delai_controle, seuil_ajustement: pm.seuil_ajustement, inactivite_min: pm.inactivite_min, acte_urgence: pm.acte_urgence,
      vacation_debut: pm.vacation_debut, vacation_fin: pm.vacation_fin, raison: pm.raison, forme: pm.forme, adresse: pm.adresse, rccm: pm.rccm, ncc: pm.ncc, telephone: pm.telephone, slogan: pm.slogan },
    passages, bons, patients, sessions, recus, paiements,
    ma_session: C.sessionOuverte(db, u.id),
    depenses: sessions.length ? db.prepare(`SELECT * FROM depenses WHERE session_id IN (${sessions.map(() => '?').join(',')})`).all(...sessions.map(s => s.id)) : [],
    demandes: db.prepare("SELECT * FROM demandes WHERE type NOT IN ('suppression', 'annulation') AND (statut = 'en_attente' OR decide_le >= ?) ORDER BY cree_le DESC").all(debut).map(d => ({ ...d, donnees: JSON.parse(d.donnees) })),
    ordonnances: db.prepare('SELECT * FROM ordonnances WHERE cree_le >= ? OR delivre_le IS NULL ORDER BY cree_le DESC').all(debut).map(o => ({ ...o, lots: o.lots ? JSON.parse(o.lots) : [] })),
    produits,
    actes: db.prepare('SELECT * FROM actes ORDER BY famille, specialite, libelle').all(),
    assureurs: db.prepare('SELECT * FROM assureurs ORDER BY nom').all(),
    utilisateurs: Object.fromEntries(db.prepare('SELECT id, nom FROM utilisateurs').all().map(x => [x.id, x.nom])),
    receptions: db.prepare(`SELECT m.*, l.numero AS lot, l.peremption, l.fournisseur, p.nom AS produit FROM mouvements m JOIN lots l ON l.id = m.lot_id JOIN produits p ON p.id = m.produit_id
      WHERE m.type = 'reception' ORDER BY m.id DESC LIMIT 10`).all()
  };
  if (e.ma_session) e.ma_session.especes = C.especes(db, e.ma_session);
  if (peut(u, 'pilotage')) e.indicateurs = indicateurs(db, produits);
  if (peut(u, 'consulter')) e.file_medecin = CL.fileMedecin(db, u);
  if (peut(u, 'constantes')) e.file_infirmerie = CL.fileInfirmerie(db);
  if (peut(u, 'constantes') || peut(u, 'rdv_ecrire') || peut(u, 'consulter')) e.medecins = CL.listerMedecins(db);
  if (peut(u, 'caisse')) e.avances_a_verser = F.aVerser(db);
  if (peut(u, 'rdv_lire')) e.rdv = CL.listerRdv(db, jourLocal(), require('./outils').ajouterJours(jourLocal(), 14));
  if (peut(u, 'audit')) e.audit = db.prepare('SELECT id, t, login, poste, action, detail, niveau FROM audit ORDER BY id DESC LIMIT 40').all();
  if (peut(u, 'hosp_lire')) e.hospitalisation = H.etat(db);
  if (peut(u, 'referentiels')) e.chambres = db.prepare('SELECT * FROM chambres ORDER BY code').all();
  if (peut(u, 'supprimer')) e.suppressions = SUP.lister(db);
  if (peut(u, 'supprimer')) e.suppressions = SUP.lister(db);
  N.generer(db, u, produits);
  e.notifications = N.lister(db, u);
  return e;
}

/* Exports compatibles Excel (ASS-09, CAI-11, PHA-11) */
function exporter(db, type, du, au) {
  const [a, b] = bornesPeriode(du, au);
  const nom = id => (db.prepare('SELECT nom FROM utilisateurs WHERE id = ?').get(id) || {}).nom || '';
  const date = t => new Date(t).toLocaleString('fr-FR');
  const pat = id => R.patient(db, id);
  if (type === 'journal-caisse') {
    const rows = db.prepare('SELECT * FROM recus WHERE cree_le >= ? AND cree_le < ? ORDER BY cree_le').all(a, b);
    return versCsv([
      { titre: 'Date', v: r => date(r.cree_le) }, { titre: 'Reçu', v: 'numero' }, { titre: 'Caissier', v: r => nom(r.caissier_id) },
      { titre: 'Patient', v: r => R.nomPatient(pat(r.patient_id)) }, { titre: 'IPP', v: r => (pat(r.patient_id) || {}).ipp || '' },
      { titre: 'Total actes', v: 'total' }, { titre: 'Part assureur', v: 'part_assureur' }, { titre: 'Remise', v: 'remise' }, { titre: 'Net encaissé', v: 'net' },
      { titre: 'Paiements', v: r => db.prepare('SELECT * FROM paiements WHERE recu_id = ?').all(r.id).map(p => `${p.mode} ${p.montant}${p.reference ? ' réf. ' + p.reference : ''}`).join(' + ') },
      { titre: 'Statut', v: r => (r.annule ? 'Annulé, avoir ' + r.avoir : 'Valide') }, { titre: 'Code de contrôle', v: 'code_controle' }
    ], rows);
  }
  if (type === 'sorties') {
    const rows = db.prepare('SELECT d.*, s.vacation FROM depenses d JOIN caisse_sessions s ON s.id = d.session_id WHERE d.cree_le >= ? AND d.cree_le < ? ORDER BY d.cree_le').all(a, b);
    return versCsv([
      { titre: 'Date', v: r => date(r.cree_le) }, { titre: 'Compte SYSCOHADA', v: 'categorie' }, { titre: 'Libellé', v: 'libelle' }, { titre: 'Montant', v: 'montant' },
      { titre: 'Justificatif', v: 'justificatif' }, { titre: 'Agent', v: r => nom(r.utilisateur_id) }, { titre: 'Vacation', v: 'vacation' }
    ], rows);
  }
  if (type === 'tiers-payants') {
    const rows = db.prepare(`SELECT b.*, r.numero AS recu, r.cree_le AS date_recu, a.nom AS assureur, v.accord, v.numero AS passage FROM bons b JOIN recus r ON r.id = b.recu_id
      JOIN assureurs a ON a.id = b.assureur_id JOIN passages v ON v.id = b.passage_id WHERE r.cree_le >= ? AND r.cree_le < ? AND b.annule = 0 AND b.taux > 0 ORDER BY a.nom, r.cree_le`).all(a, b);
    return versCsv([
      { titre: 'Assureur', v: 'assureur' }, { titre: 'Date', v: r => date(r.date_recu) }, { titre: 'Reçu', v: 'recu' }, { titre: 'Passage', v: 'passage' }, { titre: 'N° d’accord', v: 'accord' },
      { titre: 'Patient', v: r => R.nomPatient(pat(r.patient_id)) }, { titre: 'IPP', v: r => (pat(r.patient_id) || {}).ipp }, { titre: 'N° d’assuré', v: r => (pat(r.patient_id) || {}).num_assure },
      { titre: 'Code', v: 'code' }, { titre: 'Libellé', v: 'libelle' }, { titre: 'Quantité', v: 'quantite' }, { titre: 'Prix unitaire', v: 'prix' },
      { titre: 'Total', v: r => R.montants(r).total }, { titre: 'Taux', v: 'taux' }, { titre: 'Part assureur', v: r => R.montants(r).pa }, { titre: 'Part patient', v: r => R.montants(r).pp }
    ], rows);
  }
  if (type === 'stock') {
    const rows = db.prepare('SELECT l.*, p.code, p.nom, p.famille, p.seuil FROM lots l JOIN produits p ON p.id = l.produit_id WHERE l.quantite > 0 ORDER BY p.nom, l.peremption').all();
    return versCsv([
      { titre: 'Code', v: 'code' }, { titre: 'Produit', v: 'nom' }, { titre: 'Famille', v: 'famille' }, { titre: 'Lot', v: 'numero' }, { titre: 'Péremption', v: 'peremption' },
      { titre: 'Quantité', v: 'quantite' }, { titre: 'Prix d’achat', v: 'prix_achat' }, { titre: 'Valeur', v: r => r.quantite * (r.prix_achat || 0) },
      { titre: 'Statut', v: r => (r.peremption < jourLocal() ? 'Périmé, bloqué' : 'Utilisable') }
    ], rows);
  }
  if (type === 'psychotropes') {
    const rows = db.prepare(`SELECT b.*, o.numero AS ordonnance, o.prescripteur, o.reference_ext FROM bons b JOIN ordonnances o ON o.id = b.ordonnance_id JOIN produits p ON p.id = b.produit_id
      WHERE p.psychotrope = 1 AND b.delivre = 1 AND b.delivre_le >= ? AND b.delivre_le < ? ORDER BY b.delivre_le`).all(a, b);
    return versCsv([
      { titre: 'Date de délivrance', v: r => date(r.delivre_le) }, { titre: 'Ordonnance MSI', v: 'ordonnance' }, { titre: 'N° d’ordonnance', v: 'reference_ext' },
      { titre: 'Prescripteur', v: 'prescripteur' }, { titre: 'Patient', v: r => R.nomPatient(pat(r.patient_id)) }, { titre: 'Produit', v: 'libelle' },
      { titre: 'Quantité', v: 'quantite' }, { titre: 'Délivré par', v: r => nom(r.delivre_par) },
      { titre: 'Lots', v: r => db.prepare('SELECT l.numero, m.quantite FROM mouvements m JOIN lots l ON l.id = m.lot_id WHERE m.bon_id = ?').all(r.id).map(x => `${x.numero} × ${-x.quantite}`).join(', ') }
    ], rows);
  }
  if (type === 'audit') {
    const rows = db.prepare('SELECT * FROM audit WHERE t >= ? AND t < ? ORDER BY id').all(a, b);
    return versCsv([
      { titre: 'N°', v: 'id' }, { titre: 'Date', v: r => date(r.t) }, { titre: 'Utilisateur', v: 'login' }, { titre: 'Poste', v: 'poste' }, { titre: 'Action', v: 'action' },
      { titre: 'Détail', v: 'detail' }, { titre: 'Avant', v: 'avant' }, { titre: 'Après', v: 'apres' }, { titre: 'Niveau', v: 'niveau' }, { titre: 'Empreinte', v: 'hash' }
    ], rows);
  }
  throw err(404, 'Export inconnu.');
}

function verifierRecu(db, numero) {
  const r = db.prepare('SELECT * FROM recus WHERE numero = ?').get(String(numero || '').trim().toUpperCase());
  if (!r) return { trouve: false };
  return { trouve: true, numero: r.numero, net: r.net, cree_le: r.cree_le, code_controle: r.code_controle, annule: !!r.annule, avoir: r.avoir, authentique: C.codeControle(db, r.numero, r.net, r.cree_le) === r.code_controle };
}

module.exports = { decider, indicateurs, etat, exporter, verifierRecu };
