'use strict';
/* Poste Infirmerie (v1.5) : l'infirmier prend les constantes, puis oriente le patient vers le médecin qui le recevra.
   Le médecin retrouve ces constantes dans sa consultation : il n'a pas à les ressaisir. */
const ETATS_INF = {
  a_prendre: ['b-warn', 'À prendre'], orientee: ['b-ok', 'Orienté'], en_consultation: ['b-muted', 'En consultation'],
  terminee: ['b-muted', 'Consultation terminée'], a_payer: ['b-due', 'À régler à la caisse']
};
const ORDRE_CONSTANTES = ['ta', 'pouls', 'temperature', 'spo2', 'fr', 'poids', 'taille', 'imc', 'glycemie', 'pc', 'eva'];
const infUI = () => (UI.inf = UI.inf || { sel: null, pour: null, valeurs: {}, medecin: '', observation: '' });

function medecinsPour(x) {
  const tous = E.medecins || [];
  if (!x || x.urgent || !x.specialite) return tous;
  return tous.filter(m => !m.specialites.length || m.specialites.includes(x.specialite));
}
function constantesPour(x) {
  const sp = x && x.specialite && MSI_SPECIALITES.SPECIALITES[x.specialite];
  const liste = sp && sp.constantes && sp.constantes.length ? sp.constantes : ['ta', 'pouls', 'temperature', 'spo2', 'poids', 'taille', 'imc', 'glycemie'];
  return ORDRE_CONSTANTES.filter(k => liste.includes(k));
}
function infAlerte(k, v, p) {
  if (!v || typeof alerteHTML !== 'function') return '';
  try { return alerteHTML(MSI_SPECIALITES.alerte(k, v, { age: p && p.naissance ? age(p.naissance) : null, sexe: p && p.sexe })); } catch (e) { return ''; }
}

/* v1.6 : constantes anormales signalées en rouge pendant la saisie, avec le spécialiste suggéré ; le patient sera prioritaire. */
function alertesInf(x) {
  const ui = infUI(), S = MSI_SPECIALITES, p = (x && x.patient) || {}, v = { ...ui.valeurs };
  const imc = S.imc(v.taille, v.poids); if (imc) v.imc = String(imc);
  return Object.entries(v).filter(([k, val]) => val && S.CONSTANTES[k]).map(([k, val]) => {
    try { const a = S.alerte(k, val, { age: p.naissance ? age(p.naissance) : null, sexe: p.sexe }); return a ? { k, valeur: val, niveau: a.niveau, texte: a.texte } : null; } catch (e) { return null; }
  }).filter(Boolean);
}
function suggestionInf(x) { const p = (x && x.patient) || {}; return MSI_SPECIALITES.specialiteSuggeree(alertesInf(x), p.naissance ? age(p.naissance) : null); }
function syntheseInf(x) {
  const al = alertesInf(x);
  if (!al.length) return '';
  return `<div class="notice bad"><strong>Constantes anormales :</strong> ${al.map(a => `${esc(a.texte)} (${esc(a.valeur)})`).join(', ')}.
    Le patient sera signalé en priorité au médecin.${suggestionInf(x) ? ` Spécialiste suggéré : <strong>${esc(suggestionInf(x))}</strong>.` : ''}</div>`;
}
function vInfirmerie() {
  const ui = infUI(), file = E.file_infirmerie || [];
  if (ui.sel && !file.some(x => x.passage_id === ui.sel)) ui.sel = null;
  const x = file.find(y => y.passage_id === ui.sel) || null;
  const aPrendre = file.filter(y => y.statut === 'a_prendre').length;
  return `<div class="page-head"><div><h1>Infirmerie</h1><p class="lead">Prendre les constantes, puis orienter le patient vers le médecin qui le recevra.</p></div></div>
  <div class="grid-2 inf-grille">
    <div class="panel"><h2>Patients du jour${aPrendre ? ` <span class="badge b-warn">${aPrendre} à prendre</span>` : ''}</h2>
      ${file.length ? `<ul class="list">${file.map(y => {
        const [cls, txt] = ETATS_INF[y.statut] || ['b-muted', y.statut], p = y.patient || {};
        return `<li><button class="row-btn" data-action="infChoisir" data-id="${y.passage_id}"${ui.sel === y.passage_id ? ' aria-current="true"' : ''}>
          <span><strong>${esc(nomPatient(p))}</strong><small class="muted">${esc(y.numero)}, ${esc(y.specialite || (y.type === 'urgence' ? 'urgence' : 'consultation'))}, arrivé ${fmtDateTime(y.cree_le)}</small>
          ${y.constantes ? `<small class="muted">Orienté vers ${esc(y.constantes.medecin)}</small>` : ''}${y.constantes && y.constantes.prioritaire ? '<small class="alerte-file">Prioritaire</small>' : ''}</span>
          <span class="badge ${cls}">${txt}</span></button></li>`;
      }).join('')}</ul>` : '<p class="muted">Aucun patient en consultation pour le moment. Les passages ouverts à l’accueil apparaissent ici.</p>'}
    </div>
    <div>${x ? ficheInfirmerie(x) : '<div class="panel empty"><h2>Choisissez un patient</h2><p class="muted">Sélectionnez un patient dans la liste pour prendre ses constantes.</p></div>'}</div>
  </div>`;
}

function ficheInfirmerie(x) {
  const ui = infUI(), S = MSI_SPECIALITES, p = x.patient || {}, c = x.constantes;
  if (ui.pour !== x.passage_id) { ui.pour = x.passage_id; ui.valeurs = c ? { ...c.valeurs } : {}; ui.medecin = c ? String(c.medecin_id) : (x.medecin_id ? String(x.medecin_id) : ''); ui.observation = (c && c.observation) || ''; }
  const bloque = x.statut === 'a_payer', fige = x.statut === 'en_consultation' || x.statut === 'terminee', off = bloque || fige ? ' disabled' : '';
  const champs = constantesPour(x).map(k => {
    const d = S.CONSTANTES[k], v = k === 'imc' ? String(S.imc(ui.valeurs.taille, ui.valeurs.poids) || '').replace('.', ',') : (ui.valeurs[k] || '');
    return `<label class="f"><span>${esc(d.l)}${d.unite ? ` (${esc(d.unite)})` : ''}</span><input id="inf-${k}" ${k === 'imc' ? 'readonly tabindex="-1"' : `data-input="infValeur" data-k="${k}"`}
      value="${esc(v)}" inputmode="${k === 'ta' ? 'text' : 'decimal'}" placeholder="${esc(d.exemple || '')}" autocomplete="off"${off}><span class="alerte" id="inf-al-${k}">${infAlerte(k, v, p)}</span></label>`;
  }).join('');
  const sugg = suggestionInf(x), meds = medecinsPour(x).sort((a, b) => (b.specialites.includes(sugg) ? 1 : 0) - (a.specialites.includes(sugg) ? 1 : 0));
  return `<div class="panel">
    <div class="panel-head"><h2>${esc(nomPatient(p))}</h2><span class="muted">${esc(p.ipp || '')}${p.naissance ? `, ${age(p.naissance)} ans` : ''}${p.sexe ? `, ${p.sexe === 'F' ? 'femme' : 'homme'}` : ''}</span></div>
    <p class="muted">${esc(x.numero)}, ${esc(x.specialite || (x.type === 'urgence' ? 'urgence' : 'consultation'))}.</p>
    ${x.motif ? `<p><strong>Motif :</strong> ${esc(x.motif)}</p>` : ''}
    ${bloque ? '<div class="notice bad">Bon de consultation non réglé : envoyez d’abord le patient à la caisse.</div>' : ''}
    ${fige ? '<div class="notice">Le médecin a commencé la consultation : transmettez-lui directement toute nouvelle mesure.</div>' : ''}
    ${c ? `<div class="notice ok">Constantes prises par ${esc(c.par)} ${fmtDateTime(c.le)}, patient orienté vers ${esc(c.medecin)}.</div>` : ''}
    <h3 class="inf-titre">Constantes</h3><div class="constantes">${champs}</div>
    <div id="inf-synthese">${syntheseInf(x)}</div>
    ${champ('Observation pour le médecin', `<textarea id="inf-obs" data-input="infObs" rows="2" maxlength="300" placeholder="Ex. fièvre depuis hier soir"${off}>${esc(ui.observation)}</textarea>`)}
    ${champ('Médecin qui recevra le patient', `<select id="inf-medecin" data-change="infMedecin"${off}><option value="">Choisir le médecin</option>${meds.map(m => `<option value="${m.id}"${String(m.id) === String(ui.medecin) ? ' selected' : ''}>${esc(m.nom)}${m.specialites.length ? ', ' + esc(m.specialites.join(', ').toLowerCase()) : ''}${sugg && m.specialites.includes(sugg) ? ' (spécialité suggérée)' : ''}</option>`).join('')}</select>`,
      meds.length ? '' : 'Aucun médecin habilité pour cette spécialité : vérifiez les comptes dans Paramétrage.')}
    ${bloque || fige ? '' : `<div class="row-actions"><button class="btn" data-action="infEnregistrer">${c ? 'Corriger et orienter' : 'Enregistrer et orienter vers le médecin'}</button></div>`}
  </div>`;
}

Object.assign(ACTIONS, {
  infChoisir: el => { infUI().sel = Number(el.dataset.id); render(); },
  infEnregistrer: async () => {
    const ui = infUI(), x = (E.file_infirmerie || []).find(y => y.passage_id === ui.sel);
    if (!x) return;
    if (!ui.medecin) { toast('Choisissez le médecin qui recevra le patient.', 'bad'); const s = $('#inf-medecin'); if (s) s.focus(); return; }
    const r = await agir(() => api('POST', '/api/constantes', { passage_id: x.passage_id, valeurs: ui.valeurs, medecin_id: Number(ui.medecin), observation: ui.observation }),
      r => `Constantes enregistrées : patient orienté vers ${r.medecin}${r.prioritaire ? ', signalé en priorité' : ''}.`);
    if (r) { ui.pour = null; ui.sel = null; render(); }
  }
});
Object.assign(INPUTS, {
  infValeur: el => {
    const ui = infUI(), k = el.dataset.k;
    ui.valeurs[k] = el.value;
    const p = ((E.file_infirmerie || []).find(y => y.passage_id === ui.sel) || {}).patient;
    const al = $('#inf-al-' + k); if (al) al.innerHTML = infAlerte(k, el.value, p);
    const sy = $('#inf-synthese'); if (sy) sy.innerHTML = syntheseInf((E.file_infirmerie || []).find(y => y.passage_id === ui.sel));
    if (k === 'poids' || k === 'taille') { const i = $('#inf-imc'); if (i) i.value = String(MSI_SPECIALITES.imc(ui.valeurs.taille, ui.valeurs.poids) || '').replace('.', ','); }
  },
  infObs: el => { infUI().observation = el.value; }
});
Object.assign(CHANGES, { infMedecin: el => { infUI().medecin = el.value; } });
ONGLETS.push({ id: 'infirmerie', libelle: 'Infirmerie', icone: 'infirmerie', visible: () => peut('constantes'),
  compteur: () => (E.file_infirmerie || []).filter(x => x.statut === 'a_prendre').length, vue: vInfirmerie });
