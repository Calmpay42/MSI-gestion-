'use strict';
/* Poste Tiers payant : bordereaux par assureur, règlements, rejets, balance âgée (ASS-05 à ASS-08). */
function tpUI() { if (!UI.tp) UI.tp = { sub: 'afacturer', afacturer: null, bordereaux: [], balance: [], version: 0 }; return UI.tp; }
async function chargerTP() {
  const T = tpUI();
  try {
    [T.afacturer, T.bordereaux, T.balance] = await Promise.all([api('GET', '/api/tiers-payant/a-facturer'), api('GET', '/api/bordereaux'), api('GET', '/api/tiers-payant/balance-agee')]);
    T.version = VERSION;
    if (UI.tab === 'tiers' && !modalOuverte()) render();
  } catch (e) { toast(e.message, 'bad'); }
}
const STATUTS_BRD = { emis: ['b-due', 'Émis'], partiel: ['b-warn', 'Réglé en partie'], solde: ['b-ok', 'Soldé'], annule: ['b-muted', 'Annulé'] };
function vTiers() {
  const T = tpUI();
  if (T.afacturer === null || T.version !== VERSION) { if (T.afacturer === null) T.afacturer = []; chargerTP(); }
  const subs = [['afacturer', 'À facturer'], ['bordereaux', 'Bordereaux'], ['balance', 'Balance âgée'], ['cloture', 'Clôture mensuelle']];
  const corps = T.sub === 'bordereaux' ? vBordereaux() : T.sub === 'balance' ? vBalance() : T.sub === 'cloture' ? vCloture() : vAFacturer();
  return `<div class="view-head"><div><h1>Tiers payant</h1><p class="lead">Facturer la part assureur par bordereau, suivre règlements et rejets. Un acte n’est jamais facturé deux fois.</p></div></div>
    <div class="seg" role="group" aria-label="Rubriques">${subs.map(([k, l]) => `<button data-action="tpSub" data-sub="${k}" aria-pressed="${T.sub === k}">${l}</button>`).join('')}</div>${corps}`;
}
function vAFacturer() {
  const l = tpUI().afacturer;
  return `<div class="panel"><h2>Part assureur encaissée, pas encore facturée</h2>${l.length ? `<div class="table-wrap"><table><thead><tr><th>Assureur</th><th class="num">Actes</th><th class="num">Montant</th><th>Depuis le</th><th></th></tr></thead><tbody>${l.map(x => `<tr>
    <td><strong>${esc(x.assureur)}</strong></td><td class="num">${x.lignes}</td><td class="num">${money(x.montant)}</td><td>${fmtDate(x.depuis)}</td>
    <td class="actions"><button class="btn btn-sm" data-action="brdNouveau" data-id="${x.assureur_id}">Créer le bordereau</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Aucune part assureur à facturer.</p>'}
    <p class="hint">Seules les parts assureur des actes réglés par le patient, avec un accord valide, sont facturables.</p></div>`;
}
function vBordereaux() {
  const l = tpUI().bordereaux;
  return `<div class="panel"><h2>Bordereaux</h2>${l.length ? `<div class="table-wrap"><table><thead><tr><th>N°</th><th>Assureur</th><th>Période</th><th class="num">Total</th><th class="num">Réglé</th><th class="num">Rejeté</th><th class="num">Reste dû</th><th>Statut</th><th></th></tr></thead><tbody>${l.map(b => `<tr>
    <td><strong>${esc(b.numero)}</strong></td><td>${esc(b.assureur)}</td><td>${fmtDate(b.du)} au ${fmtDate(b.au)}</td><td class="num">${money(b.total)}</td><td class="num">${money(b.regle)}</td><td class="num">${money(b.rejete)}</td>
    <td class="num">${money(b.reste)}</td><td><span class="badge ${STATUTS_BRD[b.statut][0]}">${STATUTS_BRD[b.statut][1]}</span></td><td class="actions"><button class="btn btn-sm btn-ghost" data-action="brdVoir" data-id="${b.id}">Ouvrir</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Aucun bordereau émis.</p>'}</div>`;
}
function vBalance() {
  const l = tpUI().balance, cles = ['non_facture', 'j30', 'j60', 'j90', 'plus90', 'total'], tot = k => l.reduce((s, x) => s + x[k], 0);
  return `<div class="panel"><h2>Balance âgée des créances sur les assureurs</h2>${l.length ? `<div class="table-wrap"><table><thead><tr><th>Assureur</th><th class="num">Non facturé</th><th class="num">0 à 30 j</th><th class="num">31 à 60 j</th><th class="num">61 à 90 j</th><th class="num">Plus de 90 j</th><th class="num">Total</th></tr></thead><tbody>
    ${l.map(x => `<tr><td><strong>${esc(x.assureur)}</strong></td>${cles.map(k => `<td class="num${k === 'plus90' && x[k] ? ' is-bad' : ''}">${money(x[k])}</td>`).join('')}</tr>`).join('')}
    <tr><td><strong>Total</strong></td>${cles.map(k => `<td class="num"><strong>${money(tot(k))}</strong></td>`).join('')}</tr></tbody></table></div>` : '<p class="muted">Aucune créance en cours.</p>'}
    <p class="hint">Ancienneté comptée depuis l’émission du bordereau. Relancez en priorité les montants de plus de 60 jours.</p></div>`;
}
function bordereauHTML(b) {
  const lignes = b.lignes.filter(l => !l.annule);
  const corps = `<div class="pa-bloc"><div><strong>Assureur :</strong> ${esc(b.assureur)}</div><div><strong>Période :</strong> du ${fmtDate(b.du)} au ${fmtDate(b.au)}</div><div><strong>Nombre d’actes :</strong> ${lignes.length}</div></div>
    <table class="pa-table"><thead><tr><th>Date</th><th>Patient</th><th>N° d’assuré</th><th>N° d’accord</th><th>Acte ou produit</th><th class="num">Qté</th><th class="num">Total</th><th class="num">Taux</th><th class="num">Part assureur</th></tr></thead>
    <tbody>${lignes.map(l => `<tr><td>${fmtDate(jourDe(l.cree_le))}</td><td>${esc(l.nom + ' ' + l.prenoms)}<br><span class="muted">${esc(l.ipp)}</span></td><td>${esc(l.num_assure || '')}</td><td>${esc(l.accord || '')}</td>
      <td>${esc(l.libelle)}</td><td class="num">${l.quantite}</td><td class="num">${NF.format(l.prix * l.quantite)}</td><td class="num">${l.taux}&nbsp;%</td><td class="num">${NF.format(l.montant)}</td></tr>`).join('')}</tbody></table>
    <table class="pa-totaux"><tr class="pa-fort"><td>Total dû par ${esc(b.assureur)}</td><td>${money(b.total)}</td></tr></table>
    <p>Arrêté le présent bordereau à la somme de ${money(b.total)}.</p><div class="pa-signature">Cachet et signature de la clinique</div>`;
  return pieceA4({ titre: 'Bordereau de facturation', numero: b.numero, sous: `émis le ${fmtDate(jourDe(b.cree_le))}`, corps, paysage: true });
}
async function ouvrirBordereau(id) {
  const b = await api('GET', '/api/bordereaux/' + id);
  tpUI().detail = b;
  const actives = b.lignes.filter(l => !l.annule);
  openModal(`<div class="modal-head"><div><h2>${esc(b.numero)}, ${esc(b.assureur)}</h2><p class="muted">Du ${fmtDate(b.du)} au ${fmtDate(b.au)} : total ${money(b.total)}, réglé ${money(b.regle)}, rejeté ${money(b.rejete)}, reste dû ${money(b.reste)}</p></div>${closeBtn()}</div>
    <div class="table-wrap"><table><thead><tr><th></th><th>Patient</th><th>Accord</th><th>Acte</th><th class="num">Part assureur</th><th>Rejet</th></tr></thead><tbody>${actives.map(l => `<tr>
      <td>${l.rejete || b.statut === 'annule' ? '' : `<input type="checkbox" name="brd-ligne" value="${l.id}" aria-label="Rejeter cette ligne">`}</td><td>${esc(l.nom + ' ' + l.prenoms)}</td><td>${esc(l.accord || '')}</td>
      <td>${esc(l.libelle)}</td><td class="num">${money(l.montant)}</td><td>${l.rejete ? `<span class="badge b-bad">${esc(l.motif_rejet)}</span>` : ''}</td></tr>`).join('')}</tbody></table></div>
    ${b.reglements.length ? `<h3>Règlements</h3><ul class="plist">${b.reglements.map(r => `<li><div><strong>${esc(r.mode)}</strong>, réf. ${esc(r.reference)}<div class="muted">${fmtDate(r.date)}</div></div><div class="pl-side">${money(r.montant)}</div></li>`).join('')}</ul>` : ''}
    <div class="modal-actions"><a class="btn btn-ghost" href="/api/bordereaux/${b.id}/csv" download>Fichier Excel</a><button class="btn btn-ghost" data-action="brdImprimer">Imprimer</button>
      ${b.statut !== 'annule' && b.reste > 0 ? '<button class="btn btn-ghost" data-action="brdRejeter">Rejeter la sélection</button><button class="btn" data-action="brdReglement">Enregistrer un règlement</button>' : ''}
      ${(peut('supprimer') || peut('suppression_demander')) && b.statut === 'emis' ? '<button class="btn btn-danger" data-action="brdAnnuler">' + (peut('supprimer') ? 'Annuler le bordereau' : 'Demander l’annulation') + '</button>' : ''}</div>`, { large: true, noFocus: true });
}
const moisPrecedent = () => { const d = new Date(); d.setDate(0); return isoDate(d); };
Object.assign(ACTIONS, {
  tpSub: el => { tpUI().sub = el.dataset.sub; render(); },
  brdNouveau: el => {
    const x = tpUI().afacturer.find(a => String(a.assureur_id) === el.dataset.id);
    tpUI().nouveau = x;
    openModal(`<div class="modal-head"><h2>Bordereau ${esc(x.assureur)}</h2>${closeBtn()}</div><p>${x.lignes} acte(s) à facturer depuis le ${fmtDate(x.depuis)}, soit ${money(x.montant)}.</p>
      <div class="form-grid two">${champ('Du', `<input type="date" id="brd-du" value="${x.depuis}">`)}${champ('Au', `<input type="date" id="brd-au" value="${todayISO()}" max="${todayISO()}">`)}</div>
      <p class="hint">Période usuelle : le mois écoulé, jusqu’au ${fmtDate(moisPrecedent())}. Les actes de la période sont figés sur ce bordereau.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="brdCreer">Émettre le bordereau</button></div>`);
  },
  brdCreer: async () => {
    const r = await agir(() => api('POST', '/api/bordereaux', { assureur_id: tpUI().nouveau.assureur_id, du: $('#brd-du').value, au: $('#brd-au').value }), r => `Bordereau ${r.numero} émis : ${r.lignes} acte(s), ${money(r.total)}.`);
    if (r) { closeModal(); tpUI().sub = 'bordereaux'; await chargerTP(); ouvrirBordereau(r.id); }
  },
  brdVoir: el => ouvrirBordereau(el.dataset.id).catch(e => toast(e.message, 'bad')),
  brdImprimer: () => { closeModal(); apercuA4('Bordereau de facturation', bordereauHTML(tpUI().detail)); },
  brdReglement: () => {
    const b = tpUI().detail;
    openModal(`<div class="modal-head"><h2>Règlement de ${esc(b.assureur)}</h2>${closeBtn()}</div><p>Reste dû sur ${esc(b.numero)} : <strong>${money(b.reste)}</strong></p>
      <div class="form-grid two">${champ('Date', `<input type="date" id="rg-date" value="${todayISO()}">`)}${champ('Mode', '<select id="rg-mode"><option>Virement</option><option>Chèque</option><option>Mobile money</option><option>Espèces</option></select>')}
      ${champ('Référence du virement ou du chèque', '<input id="rg-ref" autocomplete="off">')}${champ('Montant (FCFA)', `<input id="rg-montant" type="number" min="1" max="${b.reste}" value="${b.reste}" inputmode="numeric">`)}</div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="brdReglementOk">Enregistrer</button></div>`);
  },
  brdReglementOk: async () => {
    const b = tpUI().detail;
    if (await agir(() => api('POST', `/api/bordereaux/${b.id}/reglements`, { date: $('#rg-date').value, mode: $('#rg-mode').value, reference: $('#rg-ref').value, montant: Number($('#rg-montant').value) }), 'Règlement enregistré.')) { closeModal(); await chargerTP(); }
  },
  brdRejeter: () => {
    const ids = [...document.querySelectorAll('input[name="brd-ligne"]:checked')].map(x => Number(x.value));
    if (!ids.length) { toast('Cochez les lignes rejetées par l’assureur.', 'bad'); return; }
    tpUI().rejets = ids;
    openModal(`<div class="modal-head"><h2>Rejet de ${ids.length} ligne(s)</h2>${closeBtn()}</div>${champ('Motif du rejet indiqué par l’assureur', '<input id="rj-motif" placeholder="Ex. accord expiré, acte non couvert" autocomplete="off">')}
      <p class="hint">Le montant rejeté sort du reste dû ; il peut être refacturé au patient si la convention le permet.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn btn-danger" data-action="brdRejeterOk">Enregistrer le rejet</button></div>`);
  },
  brdRejeterOk: async () => {
    const b = tpUI().detail, motif = $('#rj-motif').value;
    if (await agir(() => api('POST', `/api/bordereaux/${b.id}/rejets`, { lignes: tpUI().rejets.map(id => ({ id, motif })) }), 'Rejet enregistré.')) { closeModal(); await chargerTP(); }
  },
  brdAnnuler: () => !peut('supprimer') ? demanderSuppression({ objet: 'bordereau', id: tpUI().detail.id, titre: `Demander l’annulation de ${tpUI().detail.numero}`,
    description: 'L’administrateur annulera ce bordereau : ses actes redeviendront facturables à l’assureur.' }) : openModal(`<div class="modal-head"><h2>Annuler ${esc(tpUI().detail.numero)}</h2>${closeBtn()}</div><p>Les actes redeviennent facturables ; le bordereau reste archivé avec son motif.</p>
    ${champ('Motif de l’annulation', '<input id="an-brd" autocomplete="off">')}<div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Garder</button><button class="btn btn-danger" data-action="brdAnnulerOk">Annuler le bordereau</button></div>`),
  brdAnnulerOk: async () => { if (await agir(() => api('POST', `/api/bordereaux/${tpUI().detail.id}/annulation`, { motif: $('#an-brd').value }), 'Bordereau annulé.')) { closeModal(); await chargerTP(); } }
});
ONGLETS.push({ id: 'tiers', libelle: 'Tiers payant', icone: 'tiers', visible: () => peut('tiers_payant'), compteur: () => (UI.tp && UI.tp.afacturer ? UI.tp.afacturer.length : 0), vue: vTiers });

/* Clôture mensuelle (v1.9) : un bordereau par assureur pour le mois, rapport de clôture et impression de tous les bordereaux. */
async function chargerCloture() {
  const T = tpUI();
  if (T.cloCharge) return;
  T.cloCharge = true;
  const p = T.cloMois || todayISO().slice(0, 7);
  try { T.cloture = { periode: p, version: VERSION, rapport: await api('GET', '/api/tiers-payant/cloture?periode=' + p) }; }
  catch (e) { T.cloture = { periode: p, version: VERSION, rapport: null, erreur: e.message }; }
  T.cloCharge = false;
  render();
}
function vCloture() {
  const T = tpUI(), C = T.cloture, p = T.cloMois || todayISO().slice(0, 7);
  if (!T.cloCharge && (!C || C.periode !== p || C.version !== VERSION)) chargerCloture();
  if (!C || !C.rapport) return `<div class="panel"><p class="muted">${C && C.erreur ? esc(C.erreur) : 'Chargement…'}</p></div>`;
  const r = C.rapport, af = r.a_facturer, totalAf = af.reduce((s, x) => s + x.montant, 0);
  const statut = { emis: 'Émis', partiel: 'Partiellement réglé', solde: 'Soldé', annule: 'Annulé' };
  return `<div class="panel"><div class="panel-head"><h2>Clôture de ${esc(r.mois)}</h2><input type="month" data-change="cloMois" value="${esc(r.periode)}" max="${todayISO().slice(0, 7)}" aria-label="Mois à clôturer"></div>
      <p class="muted">Un bordereau par assureur pour les prises en charge du ${fmtDate(r.du)} au ${fmtDate(r.au)}. La clôture se rejoue sans risque : seules les prises en charge non encore facturées sont reprises.</p>
      ${af.length ? `<div class="table-wrap"><table><thead><tr><th>Assureur</th><th class="num">Prises en charge</th><th class="num">Part assureur</th></tr></thead>
        <tbody>${af.map(x => `<tr><td>${esc(x.assureur)}</td><td class="num">${x.lignes}</td><td class="num">${money(x.montant)}</td></tr>`).join('')}</tbody>
        <tfoot><tr><th>Total</th><th class="num">${af.reduce((s, x) => s + x.lignes, 0)}</th><th class="num">${money(totalAf)}</th></tr></tfoot></table></div>
        ${peut('tiers_payant') ? `<div class="row-actions"><button class="btn" data-action="cloLancer">Clôturer le mois : émettre ${af.length} bordereau${af.length > 1 ? 'x' : ''}</button></div>` : ''}`
        : '<div class="notice ok">Toutes les prises en charge du mois sont facturées.</div>'}
    </div>
    <div class="panel"><div class="panel-head"><h2>Bordereaux de ${esc(r.mois)}</h2>${r.bordereaux.length ? '<div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="cloRapport">Imprimer le rapport de clôture</button><button class="btn btn-ghost btn-sm" data-action="cloTous">Imprimer tous les bordereaux</button></div>' : ''}</div>
      ${r.bordereaux.length ? `<div class="table-wrap"><table><thead><tr><th>Bordereau</th><th>Assureur</th><th class="num">Lignes</th><th class="num">Montant</th><th class="num">Réglé</th><th class="num">Reste dû</th><th>Statut</th></tr></thead>
        <tbody>${r.bordereaux.map(b => `<tr><td>${esc(b.numero)}</td><td>${esc(b.assureur)}</td><td class="num">${b.lignes}</td><td class="num">${money(b.total)}</td><td class="num">${money(b.regle)}</td><td class="num">${money(b.reste)}</td><td>${statut[b.statut] || esc(b.statut)}</td></tr>`).join('')}</tbody>
        <tfoot><tr><th colspan="3">Total</th><th class="num">${money(r.total)}</th><th class="num">${money(r.regle)}</th><th class="num">${money(r.reste)}</th><th></th></tr></tfoot></table></div>
        ${r.services.length ? `<h3 class="inf-titre">Répartition par service</h3>${GR.barresH(r.services.map(s => ({ l: s.service, v: s.montant, d: `${s.lignes} prise${s.lignes > 1 ? 's' : ''} en charge` })), { fmt: money })}` : ''}`
        : '<p class="muted">Aucun bordereau émis pour ce mois.</p>'}
      ${r.clotures.length ? `<h3 class="inf-titre">Historique des clôtures</h3><ul class="list">${r.clotures.map(c => `<li><span>${fmtDateTime(c.cree_le)}, ${esc(c.par || '')}</span><small class="muted">${c.bordereaux} bordereau${c.bordereaux > 1 ? 'x' : ''}, ${money(c.total)}</small></li>`).join('')}</ul>` : ''}
    </div>`;
}
function rapportClotureHTML(r) {
  const corps = `<table class="doc-identite"><tbody>
      <tr><th>Période</th><td>Du ${fmtDate(r.du)} au ${fmtDate(r.au)}</td><th>Bordereaux</th><td>${r.bordereaux.length}</td></tr>
      <tr><th>Total facturé</th><td>${money(r.total)}</td><th>Reste dû</th><td>${money(r.reste)}</td></tr></tbody></table>
    <table class="doc-identite"><thead><tr><th>Bordereau</th><th>Assureur</th><th>Lignes</th><th>Montant</th><th>Réglé</th><th>Rejeté</th><th>Reste dû</th></tr></thead>
      <tbody>${r.bordereaux.map(b => `<tr><td>${esc(b.numero)}</td><td>${esc(b.assureur)}</td><td>${b.lignes}</td><td>${money(b.total)}</td><td>${money(b.regle)}</td><td>${money(b.rejete)}</td><td>${money(b.reste)}</td></tr>`).join('')}</tbody></table>
    <h3>Répartition par service</h3>
    <table class="doc-identite"><thead><tr><th>Service</th><th>Prises en charge</th><th>Part assureur</th></tr></thead>
      <tbody>${r.services.map(s => `<tr><td>${esc(s.service)}</td><td>${s.lignes}</td><td>${money(s.montant)}</td></tr>`).join('')}</tbody></table>
    ${r.a_facturer.length ? `<p><strong>Reste à facturer : ${money(r.a_facturer.reduce((s, x) => s + x.montant, 0))}</strong> (${r.a_facturer.map(x => esc(x.assureur)).join(', ')}).</p>` : '<p>Toutes les prises en charge du mois sont facturées.</p>'}
    <div class="bs-signatures"><div>Le facturiste</div><div>Le responsable administratif et financier</div><div>La direction</div></div>`;
  return pieceA4({ titre: 'Clôture mensuelle du tiers payant', numero: r.periode, sous: `Mois de ${r.mois}`, corps });
}
Object.assign(ACTIONS, {
  cloLancer: () => {
    const r = tpUI().cloture.rapport, af = r.a_facturer;
    openModal(`<div class="modal-head"><h2>Clôturer ${esc(r.mois)}</h2>${closeBtn()}</div>
      <p>${af.length} bordereau${af.length > 1 ? 'x' : ''} ser${af.length > 1 ? 'ont' : 'a'} émis (${af.map(x => esc(x.assureur)).join(', ')}), pour un total de <strong>${money(af.reduce((s, x) => s + x.montant, 0))}</strong>. L’opération est tracée au journal.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="cloConfirmer">Émettre les bordereaux</button></div>`);
  },
  cloConfirmer: async () => {
    const T = tpUI();
    const r = await agir(() => api('POST', '/api/tiers-payant/cloture', { periode: T.cloture.periode }), x => `${x.bordereaux.length} bordereau${x.bordereaux.length > 1 ? 'x' : ''} émis : ${money(x.total)}.`);
    if (r) { closeModal(); T.cloture = null; render(); }
  },
  cloRapport: () => apercuA4('Rapport de clôture', rapportClotureHTML(tpUI().cloture.rapport)),
  cloTous: async () => {
    const r = tpUI().cloture.rapport;
    try {
      const details = await Promise.all(r.bordereaux.map(b => api('GET', '/api/bordereaux/' + b.id)));
      apercuA4(`Bordereaux de ${r.mois}`, details.map(d => `<div class="clo-saut">${bordereauHTML(d)}</div>`).join(''));
    } catch (e) { toast(e.message || 'Impression impossible.', 'bad'); }
  }
});
Object.assign(CHANGES, { cloMois: el => { if (/^\d{4}-\d{2}$/.test(el.value)) { tpUI().cloMois = el.value; tpUI().cloture = null; render(); } } });
