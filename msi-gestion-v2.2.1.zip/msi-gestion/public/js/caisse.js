'use strict';
/* Poste Caisse : encaissement acte par acte (CAI-01 à CAI-12). Les montants affichés sont recalculés par le serveur. */
function fileCaisse() {
  const groupes = new Map();
  for (const b of E.bons) {
    if (b.paye || b.annule) continue;
    const key = b.patient_id ? 'p' + b.patient_id : 'v' + b.passage_id;
    if (!groupes.has(key)) groupes.set(key, { key, patientId: b.patient_id, bons: [] });
    groupes.get(key).bons.push(b);
  }
  /* Passages de soins ou de laboratoire ouverts sans bon : la caisse doit pouvoir y saisir les actes prescrits. */
  for (const v of E.passages) {
    const cle = 'p' + v.patient_id;
    if (!v.patient_id || !['soins', 'labo'].includes(v.type) || jourDe(v.cree_le) !== todayISO() || groupes.has(cle)) continue;
    if (E.bons.some(b => b.passage_id === v.id && !b.annule)) continue;
    groupes.set(cle, { key: cle, patientId: v.patient_id, bons: [], aSaisir: true });
  }
  return [...groupes.values()].map(g => ({
    ...g, urgent: g.bons.some(b => b.urgent), attente: g.bons.some(b => b.demande_id),
    du: g.bons.reduce((s, b) => s + b.net, 0), debut: g.bons.length ? Math.min(...g.bons.map(b => Date.parse(b.cree_le))) : Date.now()
  })).sort((a, b) => (b.urgent - a.urgent) || (a.debut - b.debut));
}
const groupeCourant = () => fileCaisse().find(g => g.key === UI.cai.sel) || null;
function assurerCoches(g) {
  const ids = g.bons.filter(b => !b.demande_id).map(b => b.id);
  if (!UI.cai.checked) UI.cai.checked = new Set(ids);
  for (const id of [...UI.cai.checked]) if (!ids.includes(id)) UI.cai.checked.delete(id);
}
function resume(g) {
  const r = UI.cai.remise || 0, sel = g.bons.filter(b => UI.cai.checked.has(b.id));
  let total = 0, pa = 0, pp = 0, rem = 0;
  for (const b of sel) { total += b.total; pa += b.pa; pp += b.pp; rem += b.remise_pct ? b.remise : Math.round(b.pp * r / 100); }
  return { sel, total, pa, pp, rem, net: pp - rem, r };
}
function statutBon(b) {
  if (b.demande_id) return { cls: 'b-warn', txt: 'Remise en attente de la direction' };
  if (b.urgent) return { cls: 'b-bad', txt: 'Urgence à régulariser' };
  if (b.nature === 'reprise') return { cls: 'b-bad', txt: 'Impayé antérieur' };
  if (b.nature === 'produit') return { cls: 'b-due', txt: b.delivre ? 'Délivré en urgence' : 'Pharmacie, à payer' };
  return { cls: 'b-due', txt: 'À payer' };
}
const plafond = () => E.parametres.plafond_remise;

function vCaisse() {
  const s = E.ma_session, q = fileCaisse();
  if (UI.cai.sel && !q.some(g => g.key === UI.cai.sel)) { UI.cai.sel = null; UI.cai.checked = null; }
  return `<div class="view-head"><div><h1>Caisse</h1><p class="lead">Encaisser acte par acte : aucun acte ni produit sans bon payé ou accordé.</p></div>
    ${s ? `<div class="head-actions"><button class="btn btn-ghost" data-action="avanceNouvelle">Avance patient</button><button class="btn btn-ghost" data-action="sortie">Sortie de caisse</button><button class="btn" data-action="cloture">Clôturer ma caisse</button></div>` : ''}</div>
    ${barreSession(s)}
    <div class="grid-2"><section><div class="panel"><h2>File d’attente</h2>${listeFile(q)}</div>${avoirsARembourser(s)}${avancesAVerser(s)}</section>
    <section id="cai-detail">${panneauCaisse(s, q)}</section></div>
    ${s ? recusSession(s) : ''}${cloturesDuJour()}`;
}
function barreSession(s) {
  if (!s) {
    return `<section class="panel sess"><div><h2>Votre caisse est fermée</h2><p class="muted">Ouvrez votre caisse pour encaisser : ${esc(lcFirst(E.vacation))}. Chaque agent a sa propre caisse, clôturée à la passation.</p></div>
      <div class="sess-form">${champ('Fonds de caisse (FCFA)', '<input id="sess-fonds" type="number" min="0" step="500" value="50000" inputmode="numeric">')}
      <button class="btn" data-action="ouvrirCaisse">Ouvrir ma caisse</button></div></section>`;
  }
  const c = s.especes;
  return `<section class="sess-strip"><div><strong>Caisse ouverte</strong>, ${esc(lcFirst(s.vacation))}, depuis ${fmtTime(s.ouverte_le)}.</div>
    <div class="muted">Fonds ${money(s.fonds)}, espèces attendues ${money(c.theorique)}</div></section>`;
}
function listeFile(q) {
  if (!q.length) return '<p class="muted">Aucun bon en attente. Les bons arrivent ici dès l’ouverture d’un passage ou l’envoi d’une ordonnance.</p>';
  return '<ul class="list">' + q.map(g => {
    const p = patientE(g.patientId);
    return `<li><button class="row-btn" data-action="caiChoisir" data-key="${esc(g.key)}"${UI.cai.sel === g.key ? ' aria-current="true"' : ''}>
      <span class="rb-main"><strong>${esc(nomPatient(p))}</strong><span class="muted">${p ? esc(p.ipp) + ', ' : ''}${g.bons.length} ${pl(g.bons.length, 'bon')}</span></span>
      <span class="rb-side"><span class="amount">${money(g.du)}</span>${g.aSaisir ? '<span class="badge b-warn">Actes à saisir</span>' : ''}${g.urgent ? '<span class="badge b-bad">Urgence</span>' : ''}${g.attente ? '<span class="badge b-warn">Remise en attente</span>' : ''}</span></button></li>`;
  }).join('') + '</ul>';
}
function coupon(b) {
  const st = statutBon(b), dis = !!b.demande_id, on = !dis && UI.cai.checked.has(b.id);
  return `<label class="coupon${dis ? ' is-disabled' : ''}">
    <span class="stub"><input type="checkbox" data-change="caiCoche" data-id="${b.id}"${on ? ' checked' : ''}${dis ? ' disabled' : ''} aria-label="Inclure ${esc(b.libelle)}"></span>
    <span class="c-body"><span class="c-title">${esc(b.libelle)}${b.quantite > 1 ? ` <span class="muted">× ${b.quantite}</span>` : ''}</span>
      <span class="c-meta">${money(b.total)}${b.pa ? `, part assureur ${money(b.pa)}` : ''}${b.remise_pct ? `, remise ${b.remise_pct}&nbsp;%` : ''}</span>
      <span class="badge ${st.cls}">${st.txt}</span></span>
    <span class="c-amt">${money(b.net)}</span></label>`;
}
function panneauCaisse(s, q) {
  const g = q.find(x => x.key === UI.cai.sel);
  if (!g) {
    return `<div class="panel empty"><h2>${q.length ? 'Choisissez un patient' : 'Rien à encaisser'}</h2>
      <p class="muted">${q.length ? 'Ses bons à payer s’affichent ici, passage par passage, comme des coupons à détacher.' : 'Ouvrez un passage à l’accueil ou envoyez une ordonnance depuis la pharmacie.'}</p>
      ${UI.cai.dernierRecu ? `<button class="btn btn-ghost" data-action="voirRecu" data-id="${UI.cai.dernierRecu}">Revoir le dernier reçu</button>` : ''}</div>`;
  }
  assurerCoches(g);
  const p = patientE(g.patientId), c = p ? p.couverture : { etat: 'aucune' };
  const blocs = [...new Set(g.bons.map(b => b.passage_id))].map(vid => {
    const v = passageE(vid), bs = g.bons.filter(b => b.passage_id === vid), couvert = bs.find(b => b.assureur_id);
    let ligne;
    if (v.accord && couvert) ligne = `<span class="badge">${esc(E.assureurs.find(a => a.id === couvert.assureur_id).nom)} ${couvert.taux}&nbsp;%, accord ${esc(v.accord)}</span>`;
    else if (p && c.etat === 'valide' && v.type !== 'reprise' && !v.accord && peut('accord')) ligne = `<div class="accord-inline"><span class="muted">Assuré ${esc(c.assureur)} sans n° d’accord : facturé comme non assuré.</span><div class="ai-row"><input id="accord-${v.id}" placeholder="N° d’accord" aria-label="N° d’accord pour ${esc(v.numero)}" autocomplete="off"><button class="btn btn-sm" data-action="caiAccord" data-id="${v.id}">Appliquer</button></div></div>`;
    else if (p && c.etat === 'expiree') ligne = '<span class="badge b-bad">Droits expirés, non assuré</span>';
    else ligne = '<span class="badge b-muted">Non assuré</span>';
    return `<div class="vblock"><div class="vhead"><div><strong>${esc(v.numero)}</strong> <span class="muted">${esc(typeLibelle(v.type))}${v.specialite ? ', ' + esc(lcFirst(v.specialite)) : ''}, ${fmtDateTime(v.cree_le)}</span></div>${ligne}${v.type !== 'reprise' && (peut('passage_annuler') || peut('suppression_demander')) && bs.every(b => !b.delivre && !b.demande_id) && (jourDe(v.cree_le) === todayISO() || peut('valider')) ? `${v.suppression_demandee ? '<span class="badge b-warn">Annulation demandée</span>' : ''}<button class="btn btn-ghost btn-sm" data-action="passageAnnuler" data-id="${v.id}" data-numero="${esc(v.numero)}">${peut('passage_annuler') ? 'Annuler le passage' : 'Demander l’annulation'}</button>` : ''}</div>${bs.map(coupon).join('')}</div>`;
  }).join('');
  const duJour = p && E.passages.some(v => v.patient_id === p.id && jourDe(v.cree_le) === todayISO() && v.type !== 'reprise');
  const r = resume(g);
  return `<div class="panel">
    <div class="pat-head"><div><h2 class="pat-name">${esc(nomPatient(p))}</h2><p class="muted">${p ? esc(p.ipp) + (p.naissance ? ', ' + age(p.naissance) + ' ans' : '') : 'Vente au comptoir de la pharmacie'}</p></div>${p ? covBadge(p) : ''}</div>
    ${blocs}
    ${p && peut('actes_ajouter') ? (duJour ? `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="ajouterActes">${icon('plus', 16)}Ajouter des actes prescrits</button></div>` : '<p class="hint">Pour ajouter des actes, ouvrez d’abord un passage à l’accueil.</p>') : ''}
    ${p ? actionsPatient(p) : ''}
    <div class="sum">
      <div id="cai-sum-lignes">${lignesResume(r)}</div>
      ${champ('Remise (%)', `<input id="cai-remise" type="number" min="0" max="100" step="1" inputmode="numeric" value="${UI.cai.remise || ''}" placeholder="0" data-input="caiRemise">`)}
      <p class="hint">Plafond sans validation de la direction : ${plafond()}&nbsp;%.</p>
      <div id="cai-sum-action">${actionResume(r, s)}</div>
    </div></div>`;
}
function lignesResume(r) {
  return `<div class="kvline"><span>Total des actes</span><strong>${money(r.total)}</strong></div>
    <div class="kvline"><span>Part assureur</span><strong>${money(r.pa)}</strong></div>
    <div class="kvline"><span>Part patient</span><strong>${money(r.pp)}</strong></div>
    ${r.rem ? `<div class="kvline"><span>Remise</span><strong>\u2212\u00a0${money(r.rem)}</strong></div>` : ''}
    <div class="kvline total"><span>Net à payer</span><strong>${money(r.net)}</strong></div>`;
}
function actionResume(r, s) {
  if (!r.sel.length) return '<p class="hint">Cochez les bons à encaisser.</p>';
  if (r.r > plafond()) {
    return `<div class="notice warn">Remise de ${r.r}&nbsp;% au-delà du plafond de ${plafond()}&nbsp;% : validation de la direction requise.</div>
      ${champ('Motif de la remise', `<input id="cai-motif" value="${esc(UI.cai.motif)}" data-input="caiMotif" placeholder="Ex. patient en difficulté, avis social" autocomplete="off">`)}
      <button class="btn btn-ghost btn-block" data-action="demanderRemise">Demander la validation de la direction</button>`;
  }
  if (!s) return `<button class="btn btn-accent btn-block" disabled>Encaisser ${money(r.net)}</button><p class="hint">Ouvrez votre caisse pour encaisser.</p>`;
  return `<button class="btn btn-accent btn-block" data-action="payer">${r.net > 0 ? 'Encaisser ' + money(r.net) : 'Valider sans paiement, 0\u00a0FCFA'}</button>`;
}
function rafraichirResume() {
  const g = groupeCourant();
  if (!g) return;
  const r = resume(g);
  $('#cai-sum-lignes').innerHTML = lignesResume(r);
  $('#cai-sum-action').innerHTML = actionResume(r, E.ma_session);
}

/* Paiement */
function fenetrePaiement(focusSel) {
  const P = UI.pay;
  const corps = P.net === 0
    ? '<div class="notice ok">Rien à payer par le patient : la part assureur couvre le montant. Validez pour éditer le reçu.</div>'
    : P.lignes.map((l, i) => `<div class="pay-line">
        ${champ('Mode', `<select data-change="payMode" data-i="${i}">${MOI.ref.modes.map(m => `<option${m === l.mode ? ' selected' : ''}>${m}</option>`).join('')}</select>`)}
        ${champ('Montant', `<input type="number" min="0" step="5" inputmode="numeric" value="${esc(l.montant)}" data-input="payMontant" data-i="${i}">`)}
        ${l.mode === 'Espèces'
          ? champ('Remis par le patient', `<input type="number" min="0" step="5" inputmode="numeric" value="${esc(l.remis)}" placeholder="${esc(l.montant)}" data-input="payRemis" data-i="${i}">`)
          : l.mode === 'Avance du patient' ? `<p class="hint">Solde d’avance disponible : ${money(soldeAvanceCourant())}</p>` : champ(l.mode === 'Chèque' ? 'N° du chèque' : 'Référence de transaction', `<input value="${esc(l.ref)}" placeholder="Obligatoire" data-input="payRef" data-i="${i}" autocomplete="off">`)}
        ${P.lignes.length > 1 ? `<button class="icon-btn" data-action="payRetirer" data-i="${i}" aria-label="Retirer ce mode de paiement">${icon('close', 18)}</button>` : '<span></span>'}
      </div>`).join('') + '<div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="payAjouter">Ajouter un mode de paiement</button></div>';
  openModal(`<div class="modal-head"><div><h2>Encaisser ${money(P.net)}</h2><p class="muted">${esc(P.libelle)}, ${P.bonIds.length} ${pl(P.bonIds.length, 'bon')}${P.remise ? `, remise ${P.remise}&nbsp;%` : ''}</p></div>${closeBtn()}</div>
    ${corps}<div class="pay-total" id="pay-total">${totalPaiement()}</div>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn btn-accent" data-action="payValider">Valider l’encaissement</button></div>`, { noFocus: !!focusSel });
  if (focusSel) { const el = document.querySelector(focusSel); if (el) el.focus(); }
}
function totalPaiement() {
  const P = UI.pay;
  if (P.net === 0) return `<div class="kvline"><span>Net à payer</span><strong>${money(0)}</strong></div>`;
  const somme = P.lignes.reduce((s, l) => s + (Math.round(Number(l.montant)) || 0), 0), reste = P.net - somme;
  const esp = P.lignes.find(l => l.mode === 'Espèces');
  const rendu = esp && esp.remis !== '' ? Math.max(0, (Number(esp.remis) || 0) - (Number(esp.montant) || 0)) : 0;
  return `<div class="kvline"><span>Total saisi</span><strong>${money(somme)}</strong></div>
    ${reste !== 0 ? `<div class="kvline is-bad"><span>${reste > 0 ? 'Reste à répartir' : 'Excédent à corriger'}</span><strong>${money(Math.abs(reste))}</strong></div>` : '<div class="kvline is-ok"><span>Répartition</span><strong>Complète</strong></div>'}
    ${esp ? `<div class="kvline"><span>Monnaie à rendre</span><strong>${money(rendu)}</strong></div>` : ''}`;
}

/* Reçu : aperçu à l'écran et impression sur ticket de 80 mm */
function ticket(r) {
  const e = r.etablissement, p = r.patient;
  return `<div class="ticket" role="document" aria-label="Reçu ${esc(r.numero)}">
    <div class="t-center">${logo(64)}<div class="t-strong">${esc(e.raison)}</div><div>${esc(e.forme)}</div><div>${esc(e.adresse)}</div><div>${esc(e.rccm)}</div><div>${esc(e.ncc)}</div><div>${esc(e.telephone)}</div></div>
    <div class="t-rule"></div>
    <div class="t-row"><span>Reçu</span><strong>${esc(r.numero)}</strong></div>
    <div class="t-row"><span>Date</span><span>${fmtDate(jourDe(r.cree_le))} à ${fmtTime(r.cree_le)}</span></div>
    <div class="t-row"><span>Vacation</span><span>${esc(r.vacation)}</span></div>
    <div class="t-row"><span>Caisse</span><span>${esc(r.caissier)}</span></div>
    <div class="t-row"><span>Patient</span><span>${esc(nomPatient(p))}${p ? ' (' + esc(p.ipp) + ')' : ''}</span></div>
    <div class="t-row"><span>Passage</span><span>${esc(r.passages.join(', '))}</span></div>
    ${r.couverture.length ? `<div class="t-row"><span>Couverture</span><span>${esc(r.couverture.join(', '))}${r.accords.length ? ', accord ' + esc(r.accords.join(', ')) : ''}</span></div>` : ''}
    <div class="t-rule"></div>
    ${r.bons.map(b => `<div class="t-row"><span>${esc(b.libelle)}${b.quantite > 1 ? ' × ' + b.quantite : ''}</span><span>${NF.format(b.total)}</span></div>
      ${b.pa ? `<div class="t-row t-sub"><span>part assureur</span><span>\u2212\u00a0${NF.format(b.pa)}</span></div>` : ''}
      ${b.remise ? `<div class="t-row t-sub"><span>remise ${b.remise_pct}&nbsp;%</span><span>\u2212\u00a0${NF.format(b.remise)}</span></div>` : ''}`).join('')}
    <div class="t-rule"></div>
    <div class="t-row"><span>Total des actes</span><span>${NF.format(r.total)}</span></div>
    <div class="t-row"><span>Part assureur</span><span>${NF.format(r.part_assureur)}</span></div>
    ${r.remise ? `<div class="t-row"><span>Remise</span><span>${NF.format(r.remise)}</span></div>` : ''}
    <div class="t-row t-total"><span>Net payé</span><span>${money(r.net)}</span></div>
    ${r.paiements.map(l => `<div class="t-row t-sub"><span>${esc(l.mode)}${l.reference ? ', réf. ' + esc(l.reference) : ''}</span><span>${NF.format(l.montant)}</span></div>
      ${l.mode === 'Espèces' && l.remis > l.montant ? `<div class="t-row t-sub"><span>remis ${NF.format(l.remis)}, rendu</span><span>${NF.format(l.remis - l.montant)}</span></div>` : ''}`).join('')}
    ${r.annule ? `<div class="t-cancel">Annulé, avoir ${esc(r.avoir)}</div>` : ''}
    <div class="t-qr">${r.qr_svg}</div>
    <div class="t-center t-sub">Code de contrôle ${esc(r.code_controle)}</div>
    <div class="t-center t-slogan">${esc(e.slogan)}</div>
    ${r.formation ? '<div class="t-center t-demo">Base de formation : reçu sans valeur comptable.</div>' : ''}
  </div>`;
}
async function afficherRecu(id) {
  try {
    const r = await api('GET', '/api/recus/' + id);
    UI.cai.recu = r;
    openModal(`<div class="modal-head"><h2>Reçu ${esc(r.numero)}</h2>${closeBtn()}</div>${ticket(r)}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button><button class="btn" data-action="imprimerRecu">Imprimer le reçu</button></div>`, { noFocus: true });
  } catch (e) { toast(e.message, 'bad'); }
}

/* Listes de la vacation */
function recusSession(s) {
  const rs = E.recus.filter(r => r.session_id === s.id), deps = E.depenses.filter(d => d.session_id === s.id);
  const enAttente = id => E.demandes.some(d => d.type === 'annulation' && d.statut === 'en_attente' && d.donnees.recu_id === id);
  const modes = r => E.paiements.filter(p => p.recu_id === r.id).map(p => p.mode);
  return `<section class="panel mt"><h2>Mes reçus de la vacation</h2>${rs.length ? `<div class="table-wrap"><table><thead><tr><th>Reçu</th><th>Heure</th><th>Patient</th><th>Modes</th><th class="num">Net payé</th><th>Statut</th><th></th></tr></thead><tbody>${rs.map(r => `<tr>
    <td><strong>${esc(r.numero)}</strong></td><td>${fmtTime(r.cree_le)}</td><td>${esc(nomPatient(patientE(r.patient_id)))}</td><td>${modes(r).length ? esc(modes(r).join(', ')) : 'Sans paiement'}</td><td class="num">${money(r.net)}</td>
    <td>${r.annule ? `<span class="badge b-muted">Annulé, ${esc(r.avoir)}</span>` : enAttente(r.id) ? '<span class="badge b-warn">Annulation demandée</span>' : '<span class="badge b-ok">Valide</span>'}</td>
    <td class="actions"><button class="btn btn-sm btn-ghost" data-action="voirRecu" data-id="${r.id}">Voir</button>${r.patient_id ? `<button class="btn btn-sm btn-ghost" data-action="factureNouvelle" data-p="${r.patient_id}">Facture</button>` : ''}${!r.annule && !enAttente(r.id) ? `<button class="btn btn-sm btn-ghost" data-action="demanderAnnulation" data-id="${r.id}">Annuler</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Aucun reçu sur cette vacation pour l’instant.</p>'}
    ${deps.length ? `<h3>Sorties de caisse</h3><ul class="plist">${deps.map(d => `<li><div><strong>${esc(d.libelle)}</strong><div class="muted">Compte ${esc(d.categorie)}, justificatif ${esc(d.justificatif)}</div></div><div class="pl-side">\u2212\u00a0${money(d.montant)}<div class="muted">${fmtTime(d.cree_le)}</div></div></li>`).join('')}</ul>` : ''}</section>`;
}
function avoirsARembourser(s) {
  const rs = E.recus.filter(r => r.annule && !r.rembourse_session_id);
  if (!rs.length) return '';
  return `<div class="panel"><h2>Avoirs à rembourser</h2><p class="muted">Annulations validées après la clôture de la caisse d’origine.</p><ul class="plist">${rs.map(r => `<li><div><strong>${esc(r.avoir)}</strong> <span class="muted">reçu ${esc(r.numero)}</span><div class="muted">${esc(nomPatient(patientE(r.patient_id)))}</div></div>
    <div class="pl-side">${money(r.net)}${s ? `<button class="btn btn-sm" data-action="rembourser" data-id="${r.id}">Rembourser</button>` : '<div class="muted">Ouvrez votre caisse</div>'}</div></li>`).join('')}</ul></div>`;
}
function cloturesDuJour() {
  const cs = E.sessions.filter(s => s.fermee_le);
  if (!cs.length) return '';
  return `<section class="panel mt"><h2>Caisses clôturées aujourd’hui</h2><div class="table-wrap"><table><thead><tr><th>Agent</th><th>Vacation</th><th>Clôture</th><th class="num">Attendu</th><th class="num">Compté</th><th class="num">Écart</th></tr></thead><tbody>${cs.map(s => `<tr>
    <td>${esc(utilisateur(s.caissier_id))}</td><td>${esc(s.vacation)}</td><td>${fmtTime(s.fermee_le)}</td><td class="num">${money(s.theorique)}</td><td class="num">${money(s.compte)}</td>
    <td class="num${s.ecart ? ' is-bad' : ''}">${s.ecart ? signed(s.ecart) + (s.ecart_valide_le ? ', validé' : ', à valider') : 'Aucun'}</td></tr>`).join('')}</tbody></table></div></section>`;
}

/* Clôture avec billetage */
function totalBilletage() { return MOI.ref.coupures.reduce((s, c) => s + (UI.clo.comptes[c.k] || 0) * c.v, 0); }
function resumeCloture() {
  const s = E.ma_session, c = s.especes, compte = totalBilletage(), ecart = compte - c.theorique;
  return `<div class="kvline small"><span>Fonds de caisse</span><span>${money(s.fonds)}</span></div>
    <div class="kvline small"><span>Encaissé en espèces</span><span>${money(c.encaisse)}</span></div>
    ${c.rembourse ? `<div class="kvline small"><span>Remboursements</span><span>\u2212\u00a0${money(c.rembourse)}</span></div>` : ''}
    <div class="kvline small"><span>Sorties de caisse</span><span>\u2212\u00a0${money(c.depenses)}</span></div>
    <div class="kvline"><span>Espèces attendues</span><strong>${money(c.theorique)}</strong></div>
    <div class="kvline"><span>Espèces comptées</span><strong>${money(compte)}</strong></div>
    <div class="kvline total ${ecart !== 0 ? 'is-bad' : 'is-ok'}"><span>Écart</span><strong>${ecart === 0 ? 'Aucun' : signed(ecart)}</strong></div>`;
}

Object.assign(ACTIONS, {
  ouvrirCaisse: () => agir(() => api('POST', '/api/caisse/ouverture', { fonds: Number($('#sess-fonds').value) }), 'Caisse ouverte.'),
  caiChoisir: el => { UI.cai.sel = el.dataset.key; UI.cai.checked = null; UI.cai.remise = 0; UI.cai.motif = ''; render(); scrollToId('cai-detail'); },
  caiAccord: el => {
    const n = ($('#accord-' + el.dataset.id) || {}).value || '';
    if (!n.trim()) { toast('Saisissez le n° d’accord.', 'bad'); return; }
    agir(() => api('POST', `/api/passages/${el.dataset.id}/accord`, { accord: n.trim() }), 'Accord enregistré : part assureur appliquée.');
  },
  ajouterActes: () => {
    const g = groupeCourant();
    const v = E.passages.filter(x => x.patient_id === g.patientId && jourDe(x.cree_le) === todayISO() && x.type !== 'reprise').sort((a, b) => b.cree_le.localeCompare(a.cree_le))[0];
    UI.add = { vid: v.id, q: {} };
    const familles = [...new Set(E.actes.filter(a => a.actif && a.famille !== 'Consultation').map(a => a.famille))];
    openModal(`<div class="modal-head"><div><h2>Ajouter des actes prescrits</h2><p class="muted">Passage ${esc(v.numero)} : saisie depuis la prescription papier.</p></div>${closeBtn()}</div>
      ${familles.map(f => `<h3>${esc(f)}</h3><div class="acte-grid">${E.actes.filter(a => a.actif && a.famille === f).map(a => `<div class="acte"><div><strong>${esc(a.libelle)}</strong><div class="muted">${esc(a.code)}, ${money(a.prix_non)}${a.a_valider && !E.formation ? ', tarif à valider' : ''}</div></div>
        <div class="stepper"><button class="icon-btn" data-action="pas" data-id="${a.id}" data-d="-1" aria-label="Retirer">\u2212</button><output id="q-${a.id}">0</output><button class="icon-btn" data-action="pas" data-id="${a.id}" data-d="1" aria-label="Ajouter">+</button></div></div>`).join('')}</div>`).join('')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="ajouterActesValider">Créer les bons</button></div>`, { large: true, noFocus: true });
  },
  pas: el => { const id = el.dataset.id, q = Math.max(0, Math.min(50, (UI.add.q[id] || 0) + Number(el.dataset.d))); UI.add.q[id] = q; $('#q-' + id).textContent = q; },
  ajouterActesValider: async () => {
    const actes = Object.entries(UI.add.q).filter(([, q]) => q > 0).map(([id, q]) => ({ acte_id: Number(id), quantite: q }));
    if (!actes.length) { toast('Choisissez au moins un acte.', 'bad'); return; }
    const vid = UI.add.vid;
    if (await agir(() => api('POST', `/api/passages/${vid}/actes`, { actes }), 'Bons créés : ils apparaissent à encaisser.')) { closeModal(); UI.cai.checked = null; render(); }
  },
  demanderRemise: async () => {
    const g = groupeCourant(), r = resume(g), motif = ($('#cai-motif') || {}).value || '';
    const ok = await agir(() => api('POST', '/api/caisse/remise', { bon_ids: r.sel.map(b => b.id), pct: r.r, motif }), 'Demande envoyée à la direction : les bons concernés sont bloqués jusqu’à la décision.');
    if (ok) { UI.cai.remise = 0; UI.cai.motif = ''; UI.cai.checked = null; render(); }
  },
  payer: () => {
    const g = groupeCourant(), r = resume(g);
    if (!r.sel.length) { toast('Cochez au moins un bon.', 'bad'); return; }
    UI.pay = { libelle: nomPatient(patientE(g.patientId)), bonIds: r.sel.map(b => b.id), remise: r.r, net: r.net, lignes: r.net > 0 ? [{ mode: 'Espèces', montant: String(r.net), ref: '', remis: '' }] : [] };
    fenetrePaiement();
  },
  payAjouter: () => {
    const P = UI.pay, somme = P.lignes.reduce((s, l) => s + (Math.round(Number(l.montant)) || 0), 0);
    const pris = P.lignes.map(l => l.mode), mode = MOI.ref.modes.find(m => m !== 'Espèces' && !pris.includes(m)) || 'Wave';
    P.lignes.push({ mode, montant: String(Math.max(0, P.net - somme)), ref: '', remis: '' });
    fenetrePaiement(`[data-input="payMontant"][data-i="${P.lignes.length - 1}"]`);
  },
  payRetirer: el => { UI.pay.lignes.splice(Number(el.dataset.i), 1); fenetrePaiement(); },
  payValider: async () => {
    const P = UI.pay;
    const paiements = P.lignes.map(l => ({ mode: l.mode, montant: Math.round(Number(l.montant)) || 0, reference: l.mode === 'Espèces' ? null : l.ref.trim(), remis: l.mode === 'Espèces' && l.remis !== '' ? Math.round(Number(l.remis)) : null }));
    const r = await agir(() => api('POST', '/api/caisse/encaissement', { bon_ids: P.bonIds, remise: P.remise, paiements }));
    if (!r) return;
    closeModal();
    UI.cai.sel = null; UI.cai.checked = null; UI.cai.remise = 0; UI.cai.dernierRecu = r.id;
    render();
    toast(`Reçu ${r.numero} édité.`);
    afficherRecu(r.id);
  },
  voirRecu: el => afficherRecu(el.dataset.id),
  imprimerRecu: () => imprimer(ticket(UI.cai.recu)),
  demanderAnnulation: el => {
    const r = E.recus.find(x => x.id === Number(el.dataset.id));
    openModal(`<div class="modal-head"><h2>Annuler le reçu ${esc(r.numero)}</h2>${closeBtn()}</div>
      <p>Un reçu n’est jamais supprimé. L’annulation crée un avoir numéroté, après validation par la direction.</p>
      ${champ('Motif de l’annulation', '<textarea id="an-motif" rows="2"></textarea>')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Garder le reçu</button><button class="btn btn-danger" data-action="annulationEnvoyer" data-id="${r.id}">Demander l’annulation</button></div>`);
  },
  annulationEnvoyer: async el => {
    if (await agir(() => api('POST', `/api/recus/${el.dataset.id}/annulation`, { motif: $('#an-motif').value }), 'Demande d’annulation envoyée à la direction.')) closeModal();
  },
  rembourser: el => agir(() => api('POST', `/api/recus/${el.dataset.id}/remboursement`), 'Remboursement enregistré sur votre caisse.'),
  sortie: () => openModal(`<div class="modal-head"><h2>Sortie de caisse</h2>${closeBtn()}</div>
    <div class="form-grid two">${champ('Catégorie SYSCOHADA', `<select id="dp-cat">${MOI.ref.categories_depenses.map(c => `<option value="${c.code}">${esc(c.l)}</option>`).join('')}</select>`)}
    ${champ('Libellé', '<input id="dp-lib" placeholder="Ex. achat de papier thermique" autocomplete="off">')}
    ${champ('Montant (FCFA)', '<input id="dp-montant" type="number" min="1" inputmode="numeric">')}
    ${champ('N° du justificatif', '<input id="dp-just" placeholder="Obligatoire" autocomplete="off">')}</div>
    <p class="hint">Disponible en espèces : ${money(E.ma_session.especes.theorique)}. Joignez la pièce au dossier de caisse.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="sortieValider">Enregistrer la sortie</button></div>`),
  sortieValider: async () => {
    const d = { categorie: $('#dp-cat').value, libelle: $('#dp-lib').value, montant: Number($('#dp-montant').value), justificatif: $('#dp-just').value };
    if (await agir(() => api('POST', '/api/caisse/sortie', d), 'Sortie de caisse enregistrée.')) closeModal();
  },
  cloture: () => {
    UI.clo = { comptes: {} };
    const s = E.ma_session, modes = {};
    for (const r of E.recus.filter(x => x.session_id === s.id && !x.annule)) for (const p of E.paiements.filter(x => x.recu_id === r.id)) modes[p.mode] = (modes[p.mode] || 0) + p.montant;
    openModal(`<div class="modal-head"><div><h2>Clôturer ma caisse</h2><p class="muted">${esc(lcFirst(s.vacation))}, ouverte à ${fmtTime(s.ouverte_le)}</p></div>${closeBtn()}</div>
      <div class="clo-grid"><div><h3>Billetage</h3><div class="billetage">${MOI.ref.coupures.map(c => `<label class="bill"><span>${esc(c.l)}</span><input type="number" min="0" step="1" inputmode="numeric" placeholder="0" data-input="cloCompte" data-k="${c.k}"></label>`).join('')}</div></div>
      <div><h3>Rapprochement</h3><div id="clo-sum">${resumeCloture()}</div><h3>Encaissements par mode</h3>${Object.keys(modes).length ? Object.entries(modes).map(([m, v]) => `<div class="kvline small"><span>${esc(m)}</span><span>${money(v)}</span></div>`).join('') : '<p class="muted">Aucun encaissement.</p>'}</div></div>
      ${champ('Justification de l’écart, obligatoire en cas d’écart', '<textarea id="clo-justif" rows="2"></textarea>')}
      <p class="hint">Après clôture, la caisse n’est plus modifiable. Un écart est transmis à la direction pour validation.</p>
      <div id="clo-alerte" class="notice bad" role="alert" hidden></div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn btn-accent" data-action="clotureValider">Clôturer la caisse</button></div>`, { large: true });
  },
  clotureValider: async el => {
    /* Rien de compté, ou écart important : on fait recompter avant d'accepter la clôture. */
    const compte = totalBilletage(), ecart = compte - E.ma_session.especes.theorique, alerte = $('#clo-alerte');
    if (alerte && el.dataset.confirme !== '1' && (compte === 0 || Math.abs(ecart) >= 5000)) {
      alerte.hidden = false;
      alerte.textContent = compte === 0 ? 'Aucun billet ni aucune pièce n’est saisi : recomptez la caisse. Si elle est réellement vide, confirmez la clôture.'
        : `Écart de ${money(ecart)} : recomptez billets et pièces avant de clôturer. Si le comptage est juste, confirmez la clôture.`;
      el.dataset.confirme = '1'; el.textContent = 'Clôturer malgré l’écart';
      return;
    }
    const r = await agir(() => api('POST', '/api/caisse/cloture', { billetage: UI.clo.comptes, justification: $('#clo-justif').value }),
      r => (r.ecart === 0 ? 'Caisse clôturée sans écart.' : 'Caisse clôturée : écart justifié et transmis à la direction.'));
    if (r) closeModal();
  }
});
Object.assign(INPUTS, {
  caiRemise: el => { let n = Math.round(Number(el.value)); if (!isFinite(n) || n < 0) n = 0; if (n > 100) n = 100; UI.cai.remise = n; rafraichirResume(); },
  caiMotif: el => { UI.cai.motif = el.value; },
  payMontant: el => { UI.pay.lignes[Number(el.dataset.i)].montant = el.value; $('#pay-total').innerHTML = totalPaiement(); },
  payRemis: el => { UI.pay.lignes[Number(el.dataset.i)].remis = el.value; $('#pay-total').innerHTML = totalPaiement(); },
  payRef: el => { UI.pay.lignes[Number(el.dataset.i)].ref = el.value; },
  cloCompte: el => {
    let n = Math.floor(Number(el.value)); if (!isFinite(n) || n < 0) n = 0; UI.clo.comptes[el.dataset.k] = n; $('#clo-sum').innerHTML = resumeCloture();
    const b = $('[data-action="clotureValider"]'); if (b && b.dataset.confirme) { delete b.dataset.confirme; b.textContent = 'Clôturer la caisse'; $('#clo-alerte').hidden = true; }
  }
});
Object.assign(CHANGES, {
  caiCoche: el => { const id = Number(el.dataset.id); if (el.checked) UI.cai.checked.add(id); else UI.cai.checked.delete(id); rafraichirResume(); },
  payMode: el => {
    const i = Number(el.dataset.i), l = UI.pay.lignes[i];
    l.mode = el.value;
    if (l.mode === 'Espèces') l.ref = ''; else l.remis = '';
    fenetrePaiement(l.mode === 'Espèces' ? `[data-input="payRemis"][data-i="${i}"]` : `[data-input="payRef"][data-i="${i}"]`);
  }
});
ONGLETS.push({ id: 'caisse', libelle: 'Caisse', icone: 'caisse', visible: () => peut('caisse'), compteur: () => fileCaisse().length, vue: vCaisse });

/* Avances des patients (CAI-10) et factures récapitulatives (CAI-07) */
const soldeAvanceCourant = () => { const g = groupeCourant(), p = g && patientE(g.patientId); return p ? p.avance || 0 : 0; };
function actionsPatient(p) {
  return `<div class="row-actions">${p.avance ? `<span class="badge b-ok">Avance disponible : ${money(p.avance)}</span>` : ''}
    <button class="btn btn-ghost btn-sm" data-action="factureNouvelle" data-p="${p.id}">Facture récapitulative</button>
    ${p.avance ? `<button class="btn btn-ghost btn-sm" data-action="avanceRemboursement" data-p="${p.id}">Rembourser l’avance</button>` : ''}</div>`;
}
function avancesAVerser(s) {
  const l = E.avances_a_verser || [];
  if (!l.length) return '';
  return `<div class="panel"><h2>Remboursements d’avance à verser</h2><p class="muted">Validés par la direction.</p><ul class="plist">${l.map(a => `<li><div><strong>${esc(a.nom + ' ' + a.prenoms)}</strong><div class="muted">${esc(a.numero)}${a.motif ? ', ' + esc(a.motif) : ''}</div></div>
    <div class="pl-side">${money(a.montant)}${s ? `<button class="btn btn-sm" data-action="avanceVerser" data-id="${a.id}">Verser</button>` : '<div class="muted">Ouvrez votre caisse</div>'}</div></li>`).join('')}</ul></div>`;
}
function ticketAvance(r, p, montant, mode) {
  const e = E.parametres;
  return `<div class="ticket"><div class="t-center">${logo(64)}<div class="t-strong">${esc(e.raison)}</div><div>${esc(e.adresse)}</div><div>${esc(e.telephone)}</div></div><div class="t-rule"></div>
    <div class="t-row"><span>Reçu d’avance</span><strong>${esc(r.numero)}</strong></div><div class="t-row"><span>Date</span><span>${fmtDate(todayISO())} à ${fmtTime(new Date())}</span></div>
    <div class="t-row"><span>Patient</span><span>${esc(nomPatient(p))} (${esc(p.ipp)})</span></div><div class="t-row"><span>Caisse</span><span>${esc(MOI.utilisateur.nom)}</span></div><div class="t-rule"></div>
    <div class="t-row t-total"><span>Avance versée</span><span>${money(montant)}</span></div><div class="t-row t-sub"><span>${esc(mode)}</span><span></span></div>
    <div class="t-row"><span>Solde d’avance</span><span>${money(r.solde)}</span></div><div class="t-center t-slogan">${esc(e.slogan)}</div>${E.formation ? '<div class="t-center t-demo">Base de formation : reçu sans valeur.</div>' : ''}</div>`;
}
function factureHTML(f) {
  const x = f.donnees, t = x.totaux;
  const corps = `<div class="pa-bloc"><div><strong>Facturé à :</strong> ${esc(f.destinataire)}</div><div><strong>Patient :</strong> ${esc(x.patient.nom)}, ${esc(x.patient.ipp)}${x.patient.num_assure ? ', n° d’assuré ' + esc(x.patient.num_assure) : ''}</div>
    <div><strong>Passage :</strong> ${esc(x.passage)} du ${fmtDate(x.date_passage)}${x.accord ? ', accord ' + esc(x.accord) : ''}</div></div>
    <table class="pa-table"><thead><tr><th>Date</th><th>Désignation</th><th class="num">Qté</th><th class="num">Total</th><th class="num">Part assureur</th><th class="num">Remise</th><th class="num">Part patient</th><th>Reçu</th></tr></thead>
    <tbody>${x.lignes.map(l => `<tr><td>${fmtDate(l.date)}</td><td>${esc(l.libelle)}${l.assureur ? `<br><span class="muted">${esc(l.assureur)} ${l.taux}&nbsp;%</span>` : ''}</td><td class="num">${l.quantite}</td><td class="num">${NF.format(l.total)}</td>
      <td class="num">${NF.format(l.pa)}</td><td class="num">${NF.format(l.remise)}</td><td class="num">${NF.format(l.net)}</td><td>${l.recu ? esc(l.recu) : 'À régler'}</td></tr>`).join('')}</tbody></table>
    <table class="pa-totaux"><tr><td>Total des actes</td><td>${money(t.total)}</td></tr><tr><td>Part assureur</td><td>${money(t.part_assureur)}</td></tr><tr><td>Remises</td><td>${money(t.remise)}</td></tr>
      <tr><td>Part patient</td><td>${money(t.part_patient)}</td></tr><tr><td>Déjà réglé</td><td>${money(t.regle)}</td></tr><tr class="pa-fort"><td>Reste à payer</td><td>${money(t.reste)}</td></tr></table>
    <p>Arrêtée à la somme de ${money(t.total)}.</p><div class="pa-signature">Cachet et signature</div>`;
  return pieceA4({ titre: 'Facture récapitulative', numero: f.numero, sous: `du ${fmtDate(jourDe(f.cree_le))}`, corps });
}
Object.assign(ACTIONS, {
  avanceNouvelle: () => {
    const g = groupeCourant(), p = g && patientE(g.patientId);
    UI.av = { patient: p || null, res: [] };
    openModal(`<div class="modal-head"><h2>Avance ou dépôt du patient</h2>${closeBtn()}</div>
      <div id="av-patient">${p ? `<p>Patient : <strong>${esc(nomPatient(p))}</strong>, ${esc(p.ipp)}</p>` : `${champ('Patient (nom, téléphone ou IPP)', '<input id="av-q" autocomplete="off" data-enter="avanceChercher">')}<button class="btn btn-ghost btn-sm" data-action="avanceChercher">Chercher</button><div id="av-res"></div>`}</div>
      <div class="form-grid two">${champ('Montant (FCFA)', '<input id="av-montant" type="number" min="500" step="500" inputmode="numeric">')}
      ${champ('Mode', `<select id="av-mode">${MOI.ref.modes.filter(m => m !== 'Avance du patient').map(m => `<option>${m}</option>`).join('')}</select>`)}
      ${champ('Référence (hors espèces)', '<input id="av-ref" autocomplete="off">')}${champ('Objet de l’avance', '<input id="av-motif" placeholder="Ex. hospitalisation, intervention" autocomplete="off">')}</div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="avanceEnregistrer">Enregistrer l’avance</button></div>`);
  },
  avanceChercher: async () => {
    try {
      UI.av.res = await api('GET', '/api/patients?q=' + encodeURIComponent($('#av-q').value.trim()));
      $('#av-res').innerHTML = UI.av.res.length ? `<ul class="list">${UI.av.res.slice(0, 8).map(x => `<li><button class="row-btn" data-action="avanceChoisir" data-id="${x.id}"><span class="rb-main"><strong>${esc(nomPatient(x))}</strong><span class="muted">${esc(x.ipp)}${x.telephone ? ', ' + esc(x.telephone) : ''}</span></span></button></li>`).join('')}</ul>` : '<p class="muted">Aucun patient trouvé.</p>';
    } catch (e) { toast(e.message, 'bad'); }
  },
  avanceChoisir: el => { UI.av.patient = UI.av.res.find(x => x.id === Number(el.dataset.id)); $('#av-patient').innerHTML = `<p>Patient : <strong>${esc(nomPatient(UI.av.patient))}</strong>, ${esc(UI.av.patient.ipp)}</p>`; },
  avanceEnregistrer: async () => {
    const p = UI.av.patient;
    if (!p) { toast('Choisissez le patient.', 'bad'); return; }
    const montant = Number($('#av-montant').value), mode = $('#av-mode').value;
    const r = await agir(() => api('POST', '/api/avances', { patient_id: p.id, montant, mode, reference: $('#av-ref').value, motif: $('#av-motif').value }), r => `Avance ${r.numero} enregistrée.`);
    if (r) { UI.cai.recu = null; UI.ticketAvance = ticketAvance(r, p, montant, mode); openModal(`<div class="modal-head"><h2>Reçu d’avance ${esc(r.numero)}</h2>${closeBtn()}</div>${UI.ticketAvance}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button><button class="btn" data-action="avanceImprimer">Imprimer le reçu</button></div>`, { noFocus: true }); }
  },
  avanceImprimer: () => imprimer(UI.ticketAvance),
  avanceRemboursement: el => {
    const p = patientE(Number(el.dataset.p));
    UI.av = { patient: p };
    openModal(`<div class="modal-head"><h2>Rembourser l’avance de ${esc(nomPatient(p))}</h2>${closeBtn()}</div><p>Solde disponible : <strong>${money(p.avance)}</strong>. Le remboursement est validé par la direction, puis versé par une caisse ouverte.</p>
      <div class="form-grid two">${champ('Montant (FCFA)', `<input id="rb-montant" type="number" min="1" max="${p.avance}" value="${p.avance}" inputmode="numeric">`)}${champ('Motif', '<input id="rb-motif" autocomplete="off">')}</div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="avanceRemboursementOk">Demander la validation</button></div>`);
  },
  avanceRemboursementOk: async () => {
    if (await agir(() => api('POST', '/api/avances/remboursement', { patient_id: UI.av.patient.id, montant: Number($('#rb-montant').value), motif: $('#rb-motif').value }), 'Demande transmise à la direction.')) closeModal();
  },
  avanceVerser: el => agir(() => api('POST', `/api/avances/${el.dataset.id}/versement`), 'Remboursement versé et enregistré sur votre caisse.'),
  factureNouvelle: async el => {
    /* Historique complet du patient : une facture peut être demandée des jours après le passage. */
    let fiche;
    try { fiche = await api('GET', '/api/patients/' + Number(el.dataset.p)); } catch (e) { toast(e.message, 'bad'); return; }
    const p = fiche.patient, vs = fiche.passages.filter(v => v.bons.some(b => !b.annule));
    if (!vs.length) { toast('Aucun passage facturable pour ce patient.', 'bad'); return; }
    openModal(`<div class="modal-head"><h2>Facture récapitulative</h2>${closeBtn()}</div><p>${esc(nomPatient(p))}, ${esc(p.ipp)}</p>
      ${champ('Passage', `<select id="fa-passage">${vs.map(v => `<option value="${v.id}">${esc(v.numero)}, ${esc(typeLibelle(v.type))}, ${fmtDateTime(v.cree_le)}</option>`).join('')}</select>`)}
      ${champ('Facturé à', `<input id="fa-dest" value="${esc(nomPatient(p))}" placeholder="Patient, employeur ou organisme" autocomplete="off">`)}
      <p class="hint">La facture est numérotée et figée : elle récapitule les actes, la part assureur, les remises, les règlements et le reste à payer.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="factureCreer">Établir la facture</button></div>`);
  },
  factureCreer: async () => {
    const r = await agir(() => api('POST', '/api/factures', { passage_id: Number($('#fa-passage').value), destinataire: $('#fa-dest').value }), r => `Facture ${r.numero} établie.`);
    if (r) apercuA4('Facture récapitulative', factureHTML(await api('GET', '/api/factures/' + r.id)));
  }
});
