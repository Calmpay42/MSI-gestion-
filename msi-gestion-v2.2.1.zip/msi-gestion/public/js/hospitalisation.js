'use strict';
/* Hospitalisation (v1.7) : chambres standard et VIP, patients hospitalisés, infirmiers assignés, soins, transfert et sortie.
   Journées et soins facturés deviennent des bons du séjour, réglés à la caisse et pris en charge par l'assureur. */
const hospUI = () => (UI.hosp = UI.hosp || { sel: null, dossier: null, q: '', resultats: [], patient: null, soin: 'constantes' });
const CAT_CHAMBRE = { standard: 'Standard', vip: 'VIP' };
const joursDepuis = iso => Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 864e5));
const CONSTANTES_HOSP = ['ta', 'pouls', 'temperature', 'spo2', 'fr', 'glycemie', 'eva'];

function vHospitalisation() {
  const H = E.hospitalisation || { chambres: [], hospitalisations: [], tarifs: {} }, ui = hospUI(), auj = todayISO();
  const enCours = H.hospitalisations.filter(h => h.statut === 'en_cours'), ouvertes = H.chambres.filter(c => c.actif);
  const lits = ouvertes.reduce((s, c) => s + c.lits, 0), occupes = ouvertes.reduce((s, c) => s + c.occupants.length, 0);
  const sel = ui.sel ? H.hospitalisations.find(h => h.id === ui.sel) : null;
  const sorties = H.hospitalisations.filter(h => h.statut === 'sortie');
  const stat = (l, v, s) => `<div class="hosp-stat"><small>${l}</small><strong>${v}</strong>${s ? `<small>${s}</small>` : ''}</div>`;
  return `<div class="page-head"><div><h1>Hospitalisation</h1><p class="lead">Chambres, patients hospitalisés, soins et sorties.</p></div>${peut('hosp_admettre') ? '<button class="btn" data-action="hospAdmettre">Admettre un patient</button>' : ''}</div>
    <div class="hosp-stats">
      ${stat('Lits occupés', `${occupes} / ${lits}`, lits ? `Taux d’occupation ${Math.round(occupes * 100 / lits)} %` : 'Aucune chambre ouverte')}
      ${stat('Patients hospitalisés', enCours.length, enCours.filter(h => h.constantes && h.constantes.alertes.length).length ? `<span class="alerte-file">${enCours.filter(h => h.constantes && h.constantes.alertes.length).length} en alerte</span>` : '')}
      ${stat('Admissions du jour', H.hospitalisations.filter(h => h.admis_le.slice(0, 10) === auj).length)}
      ${stat('Sorties du jour', sorties.filter(h => (h.sortie_le || '').slice(0, 10) === auj).length)}
    </div>
    ${!H.chambres.length ? '<div class="notice">Aucune chambre configurée : la direction les ajoute dans Paramétrage, Chambres.</div>' : ''}
    ${sel ? dossierHosp(sel, H) : ''}
    <div class="hosp-grille">${H.chambres.filter(c => c.actif || c.occupants.length).map(c => carteChambre(c, H)).join('')}</div>
    ${sorties.length ? `<div class="panel"><h2>Sorties récentes et quitus à délivrer</h2><ul class="list">${sorties.map(h => `<li><button class="row-btn" data-action="hospChoisir" data-id="${h.id}">
      <span><strong>${esc(nomPatient(h.patient))}</strong><small class="muted">${esc(h.numero)}, sorti ${fmtDateTime(h.sortie_le)} : ${esc(h.mode_sortie || '')}</small></span>${h.quitus_le ? '<span class="badge b-ok">Quitus délivré</span>' : '<span class="badge b-due">Quitus à délivrer</span>'}</button></li>`).join('')}</ul></div>` : ''}`;
}

function carteChambre(c, H) {
  const occ = c.occupants.map(id => H.hospitalisations.find(h => h.id === id)).filter(Boolean), ui = hospUI();
  return `<div class="hosp-chambre${c.categorie === 'vip' ? ' vip' : ''}${occ.length >= c.lits ? ' pleine' : ''}${c.actif ? '' : ' fermee'}">
    <div class="hc-tete"><strong>${esc(c.code)}</strong><span class="badge ${c.categorie === 'vip' ? 'b-warn' : 'b-muted'}">${CAT_CHAMBRE[c.categorie]}</span><span class="muted">${occ.length}/${c.lits} lit${c.lits > 1 ? 's' : ''}</span></div>
    ${occ.map(h => `<button class="hc-patient${ui.sel === h.id ? ' actif' : ''}" data-action="hospChoisir" data-id="${h.id}"><strong>${esc(nomPatient(h.patient))}</strong>
      <small>${esc(h.motif)}</small><small class="muted">${joursDepuis(h.admis_le)} j, ${esc(h.medecin.nom)}</small>
      ${h.constantes && h.constantes.alertes.length ? `<small class="alerte-file">${esc(h.constantes.alertes.map(a => a.texte).join(', '))}</small>` : ''}</button>`).join('')}
    ${Array.from({ length: Math.max(0, c.lits - occ.length) }, () => `<div class="hc-libre">${c.actif ? 'Lit libre' : 'Chambre fermée'}</div>`).join('')}
  </div>`;
}

function dossierHosp(h, H) {
  const ui = hospUI(), d = ui.dossier && ui.dossier.id === h.id ? ui.dossier : null, j = d && d.journees;
  const prix = c => (H.tarifs[c] ? H.tarifs[c].prix : 0), estim = j ? j.standard * prix('standard') + j.vip * prix('vip') : 0;
  const S = MSI_SPECIALITES;
  return `<div class="panel hosp-dossier" id="hosp-dossier">
    <div class="panel-head"><h2>${esc(nomPatient(h.patient))} <span class="muted">${esc(h.numero)}</span></h2><button class="btn btn-ghost btn-sm" data-action="hospFermer">Fermer</button></div>
    <dl class="hosp-infos">
      <div><dt>Chambre</dt><dd>${h.chambre ? `${esc(h.chambre.code)}, ${CAT_CHAMBRE[h.chambre.categorie]}` : '—'}</dd></div>
      <div><dt>Admission</dt><dd>${fmtDateTime(h.admis_le)}${h.statut === 'en_cours' ? `, ${joursDepuis(h.admis_le)} j` : ''}</dd></div>
      <div><dt>Médecin référent</dt><dd>${esc(h.medecin.nom)}</dd></div>
      <div><dt>Motif</dt><dd>${esc(h.motif)}</dd></div>
      <div><dt>Infirmiers assignés</dt><dd>${h.infirmiers.length ? h.infirmiers.map(i => esc(i.nom)).join(', ') : '<span class="muted">Aucun</span>'}</dd></div>
      ${j ? `<div><dt>Journées à ce jour</dt><dd>${[j.standard ? `${j.standard} standard` : '', j.vip ? `${j.vip} VIP` : ''].filter(Boolean).join(', ')}, environ ${money(estim)}</dd></div>` : ''}
    </dl>
    ${h.statut === 'en_cours' ? `<div class="row-actions">
      ${peut('hosp_soins') ? '<button class="btn" data-action="hospSoin">Ajouter un soin</button>' : ''}
      ${peut('hosp_gerer') ? '<button class="btn btn-ghost" data-action="hospInfirmiers">Infirmiers</button><button class="btn btn-ghost" data-action="hospTransfert">Transférer</button>' : ''}
      ${peut('hosp_sortie') ? '<button class="btn btn-ghost" data-action="hospSortie">Prononcer la sortie</button>' : ''}</div>`
      : blocQuitus(h)}
    <h3 class="inf-titre">Historique des soins</h3>
    ${!d ? '<p class="muted">Chargement…</p>' : d.soins.length ? `<ol class="hosp-soins">${d.soins.map(s => `<li class="${s.alertes.length ? 'alerte' : ''}">
      <div class="hs-tete"><strong>${{ constantes: 'Constantes', soin: 'Soin', observation: 'Observation' }[s.type]}</strong><span class="muted">${fmtDateTime(s.realise_le)}, ${esc(s.par || '')}</span></div>
      ${s.valeurs ? `<div>${Object.entries(s.valeurs).map(([k, v]) => `${esc(S.CONSTANTES[k] ? S.CONSTANTES[k].l : k)} <strong>${esc(v)}</strong>`).join(' · ')}</div>` : ''}
      ${s.acte ? `<div>${esc(s.acte)}${s.quantite > 1 ? ' × ' + s.quantite : ''} <span class="badge b-muted">Facturé</span></div>` : ''}
      ${s.description ? `<div>${esc(s.description)}</div>` : ''}
      ${s.alertes.length ? `<div class="alerte-file">${esc(s.alertes.map(a => `${a.texte} (${a.valeur})`).join(', '))}</div>` : ''}</li>`).join('')}</ol>` : '<p class="muted">Aucun soin enregistré pour le moment.</p>'}
    ${d && d.compte_rendu ? `<h3 class="inf-titre">Compte rendu de sortie</h3><p>${esc(d.compte_rendu)}</p>` : ''}
  </div>`;
}

async function rechargerSejour() {
  const ui = hospUI();
  if (ui.sel) { try { ui.dossier = await api('GET', '/api/hospitalisations/' + ui.sel); } catch (e) { ui.dossier = null; } }
  render();
}
const hospSel = () => ((E.hospitalisation || {}).hospitalisations || []).find(h => h.id === hospUI().sel);
function chambresLibres(exclure) {
  return ((E.hospitalisation || {}).chambres || []).filter(c => c.actif && c.occupants.length < c.lits && c.id !== exclure)
    .map(c => `<option value="${c.id}">${esc(c.code)}, ${CAT_CHAMBRE[c.categorie]}, ${c.lits - c.occupants.length} lit${c.lits - c.occupants.length > 1 ? 's' : ''} libre${c.lits - c.occupants.length > 1 ? 's' : ''}</option>`).join('');
}
function formulaireAdmission() {
  const ui = hospUI(), H = E.hospitalisation, p = ui.patient;
  openModal(`<div class="modal-head"><h2>Admettre un patient</h2>${closeBtn()}</div>
    ${p ? `<div class="notice ok">Patient : <strong>${esc(nomPatient(p))}</strong>, ${esc(p.ipp || '')} <button class="btn btn-ghost btn-sm" data-action="hospAutrePatient">Changer</button></div>`
      : `${champ('Rechercher le patient', `<input id="ha-q" data-input="hospQ" value="${esc(ui.q)}" placeholder="Nom, prénom, IPP ou téléphone" autocomplete="off">`)}<div id="ha-res" class="hosp-resultats">${resultatsAdmission()}</div>`}
    ${champ('Motif d’hospitalisation', '<textarea id="ha-motif" rows="2" maxlength="300" placeholder="Ex. paludisme grave, réhydratation"></textarea>')}
    <div class="form-grid">
      ${champ('Médecin référent', `<select id="ha-medecin"><option value="">Choisir</option>${(H.medecins || []).map(m => `<option value="${m.id}">${esc(m.nom)}</option>`).join('')}</select>`)}
      ${champ('Chambre', `<select id="ha-chambre"><option value="">Choisir</option>${chambresLibres()}</select>`)}
      ${champ('N° d’accord de l’assureur (facultatif)', '<input id="ha-accord" maxlength="60" autocomplete="off">')}
    </div>
    ${H.infirmiers.length ? `<fieldset class="cases"><legend>Infirmiers assignés</legend>${H.infirmiers.map(i => `<label><input type="checkbox" name="ha-inf" value="${i.id}"> ${esc(i.nom)}</label>`).join('')}</fieldset>` : ''}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="hospEnregistrerAdmission">Admettre</button></div>`, { noFocus: !!p });
}
function resultatsAdmission() {
  const ui = hospUI();
  if (ui.q.trim().length < 2) return '<p class="muted">Saisissez au moins deux caractères.</p>';
  return ui.resultats.length ? `<ul class="list">${ui.resultats.map(p => `<li><button class="row-btn" data-action="hospPatient" data-id="${p.id}"><span><strong>${esc(nomPatient(p))}</strong><small class="muted">${esc(p.ipp || '')}${p.naissance ? `, ${age(p.naissance)} ans` : ''}</small></span></button></li>`).join('')}</ul>`
    : '<p class="muted">Aucun patient trouvé : créez d’abord son dossier à l’accueil.</p>';
}
let hospMinuteur = null;
Object.assign(INPUTS, {
  hospQ: el => {
    const ui = hospUI(); ui.q = el.value; clearTimeout(hospMinuteur);
    hospMinuteur = setTimeout(async () => {
      try { ui.resultats = ui.q.trim().length >= 2 ? await api('GET', '/api/patients?q=' + encodeURIComponent(ui.q.trim())) : []; } catch (e) { ui.resultats = []; }
      const r = $('#ha-res'); if (r) r.innerHTML = resultatsAdmission();
    }, 250);
  }
});
Object.assign(ACTIONS, {
  hospChoisir: async el => { const ui = hospUI(); ui.sel = Number(el.dataset.id); ui.dossier = null; render(); await rechargerSejour(); const d = $('#hosp-dossier'); if (d && d.scrollIntoView) d.scrollIntoView({ block: 'start', behavior: 'smooth' }); },
  hospFermer: () => { const ui = hospUI(); ui.sel = null; ui.dossier = null; render(); },
  hospAdmettre: () => { const ui = hospUI(); ui.q = ''; ui.resultats = []; formulaireAdmission(); },
  hospPatient: el => { const ui = hospUI(); ui.patient = ui.resultats.find(p => String(p.id) === el.dataset.id) || null; formulaireAdmission(); },
  hospAutrePatient: () => { const ui = hospUI(); ui.patient = null; formulaireAdmission(); },
  hospDepuisAccueil: () => { const ui = hospUI(); ui.patient = { ...UI.acc.fiche.patient }; ui.q = ''; ui.resultats = []; UI.tab = 'hospitalisation'; render(); formulaireAdmission(); },
  hospEnregistrerAdmission: async () => {
    const ui = hospUI();
    if (!ui.patient) { toast('Choisissez d’abord le patient.', 'bad'); return; }
    const corps = { patient_id: ui.patient.id, motif: $('#ha-motif').value, medecin_id: Number($('#ha-medecin').value) || null, chambre_id: Number($('#ha-chambre').value) || null,
      accord: $('#ha-accord').value, infirmiers: [...document.querySelectorAll('input[name="ha-inf"]:checked')].map(x => Number(x.value)) };
    const r = await agir(() => api('POST', '/api/hospitalisations', corps), r => `Patient admis : ${r.numero}, chambre ${r.chambre}.`);
    if (r) { closeModal(); ui.patient = null; ui.sel = r.id; ui.dossier = null; await rechargerSejour(); }
  },
  hospSoin: () => {
    const ui = hospUI(), H = E.hospitalisation, S = MSI_SPECIALITES, t = ui.soin;
    openModal(`<div class="modal-head"><h2>Ajouter un soin</h2>${closeBtn()}</div>
      <div class="seg" role="group" aria-label="Type de soin">${[['constantes', 'Constantes'], ['soin', 'Soin ou traitement'], ['observation', 'Observation']].map(([k, l]) => `<button type="button" data-action="hospTypeSoin" data-t="${k}" aria-pressed="${t === k}">${l}</button>`).join('')}</div>
      ${t === 'constantes' ? `<div class="constantes">${CONSTANTES_HOSP.map(k => `<label class="f"><span>${esc(S.CONSTANTES[k].l)}${S.CONSTANTES[k].unite ? ` (${esc(S.CONSTANTES[k].unite)})` : ''}</span><input id="hs-${k}" inputmode="${k === 'ta' ? 'text' : 'decimal'}" autocomplete="off"></label>`).join('')}</div>`
        : t === 'soin' ? `<div class="form-grid">${champ('Acte facturé (facultatif)', `<select id="hs-acte"><option value="">Aucun, soin non facturé</option>${H.actes_soins.map(a => `<option value="${a.id}">${esc(a.libelle)}</option>`).join('')}</select>`)}${champ('Quantité', '<input id="hs-qte" type="number" min="1" max="20" value="1">')}</div>
          ${champ('Description', '<textarea id="hs-desc" rows="2" maxlength="1000" placeholder="Ex. artésunate 120 mg IV, perfusion de sérum salé"></textarea>')}`
        : champ('Observation', '<textarea id="hs-desc" rows="3" maxlength="1000" placeholder="Ex. patient apyrétique, bonne tolérance du traitement"></textarea>')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="hospEnregistrerSoin">Enregistrer</button></div>`);
  },
  hospTypeSoin: el => { hospUI().soin = el.dataset.t; ACTIONS.hospSoin(); },
  hospEnregistrerSoin: async () => {
    const ui = hospUI(), t = ui.soin, v = id => ($('#' + id) || {}).value || '';
    const corps = t === 'constantes' ? { type: t, valeurs: Object.fromEntries(CONSTANTES_HOSP.map(k => [k, v('hs-' + k)])) }
      : t === 'soin' ? { type: t, acte_id: Number(v('hs-acte')) || null, quantite: Number(v('hs-qte')) || 1, description: v('hs-desc') } : { type: t, description: v('hs-desc') };
    const r = await agir(() => api('POST', `/api/hospitalisations/${ui.sel}/soins`, corps),
      r => (r.alertes.length ? `Constantes anormales (${r.alertes.map(a => a.texte.toLowerCase()).join(', ')}) : le médecin référent est prévenu.` : r.bon_id ? 'Soin enregistré et facturé sur le séjour.' : 'Soin enregistré.'));
    if (r) { closeModal(); await rechargerSejour(); }
  },
  hospInfirmiers: () => {
    const h = hospSel(), H = E.hospitalisation;
    openModal(`<div class="modal-head"><h2>Infirmiers assignés</h2>${closeBtn()}</div>
      ${H.infirmiers.length ? `<fieldset class="cases"><legend>${esc(nomPatient(h.patient))}</legend>${H.infirmiers.map(i => `<label><input type="checkbox" name="hi-inf" value="${i.id}"${h.infirmiers.some(x => x.id === i.id) ? ' checked' : ''}> ${esc(i.nom)}</label>`).join('')}</fieldset>` : '<p class="muted">Aucun compte infirmier : créez-les dans Paramétrage, Comptes.</p>'}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="hospEnregistrerInfirmiers">Enregistrer</button></div>`);
  },
  hospEnregistrerInfirmiers: async () => {
    const ids = [...document.querySelectorAll('input[name="hi-inf"]:checked')].map(x => Number(x.value));
    const r = await agir(() => api('POST', `/api/hospitalisations/${hospUI().sel}/infirmiers`, { infirmiers: ids }), r => `Infirmiers assignés : ${r.infirmiers.join(', ') || 'aucun'}.`);
    if (r) { closeModal(); await rechargerSejour(); }
  },
  hospTransfert: () => {
    const h = hospSel(), libres = chambresLibres(h.chambre && h.chambre.id);
    openModal(`<div class="modal-head"><h2>Transférer ${esc(nomPatient(h.patient))}</h2>${closeBtn()}</div>
      ${libres ? champ('Nouvelle chambre', `<select id="ht-chambre">${libres}</select>`) : '<p class="muted">Aucune autre chambre libre.</p>'}
      <p class="hint">Chaque nuit est facturée au tarif de la chambre occupée à minuit.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button>${libres ? '<button class="btn" data-action="hospEnregistrerTransfert">Transférer</button>' : ''}</div>`);
  },
  hospEnregistrerTransfert: async () => {
    const r = await agir(() => api('POST', `/api/hospitalisations/${hospUI().sel}/transfert`, { chambre_id: Number($('#ht-chambre').value) }), r => `Patient transféré en chambre ${r.chambre}.`);
    if (r) { closeModal(); await rechargerSejour(); }
  },
  hospSortie: () => {
    const h = hospSel(), H = E.hospitalisation, d = hospUI().dossier, j = d && d.journees;
    const prix = c => (H.tarifs[c] ? H.tarifs[c].prix : 0);
    openModal(`<div class="modal-head"><h2>Sortie de ${esc(nomPatient(h.patient))}</h2>${closeBtn()}</div>
      ${champ('Mode de sortie', `<select id="hx-mode"><option value="">Choisir</option>${H.modes_sortie.map(m => `<option>${esc(m)}</option>`).join('')}</select>`)}
      ${champ('Compte rendu de sortie', '<textarea id="hx-cr" rows="4" maxlength="4000" placeholder="Évolution, traitement de sortie, rendez-vous de contrôle"></textarea>')}
      ${j ? `<div class="notice">La sortie facture ${[j.standard ? `${j.standard} journée${j.standard > 1 ? 's' : ''} standard` : '', j.vip ? `${j.vip} journée${j.vip > 1 ? 's' : ''} VIP` : ''].filter(Boolean).join(' et ')},
        soit ${money(j.standard * prix('standard') + j.vip * prix('vip'))} avant prise en charge. Le patient règle sa part à la caisse.</div>` : ''}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="hospEnregistrerSortie">Confirmer la sortie</button></div>`);
  },
  hospEnregistrerSortie: async () => {
    const r = await agir(() => api('POST', `/api/hospitalisations/${hospUI().sel}/sortie`, { mode: $('#hx-mode').value, compte_rendu: $('#hx-cr').value }),
      r => `Sortie enregistrée : ${r.facture} facturée${r.journees.standard + r.journees.vip > 1 ? 's' : ''}, à régler à la caisse.`);
    if (r) { closeModal(); await rechargerSejour(); }
  }
});
ONGLETS.push({ id: 'hospitalisation', libelle: 'Hospitalisation', icone: 'lit', visible: () => peut('hosp_lire'), vue: vHospitalisation });

/* Quitus de sortie (reprise 1.7, anti-fuite) : délivré par la caisse quand la part patient est soldée ;
   la direction peut passer outre, avec un motif tracé au journal. Bon de sortie imprimable en A4. */
function blocQuitus(h) {
  const mode = `Sortie médicale ${fmtDateTime(h.sortie_le)} : ${esc(h.mode_sortie || '')}.`;
  if (h.quitus_le) return `<div class="notice ok">${mode} Quitus délivré ${fmtDateTime(h.quitus_le)} par ${esc(h.quitus_par || '')}${h.quitus_motif ? `, malgré un reste à payer (motif : ${esc(h.quitus_motif)})` : ''}.</div>
    <div class="row-actions"><button class="btn btn-ghost" data-action="hospBonSortie">Imprimer le bon de sortie</button></div>`;
  const reste = h.reste || 0;
  return `<div class="notice ${reste ? 'bad' : 'ok'}">${mode} ${reste ? `Reste à payer : <strong>${money(reste)}</strong>, à encaisser à la caisse avant le quitus.` : 'Séjour soldé : le quitus peut être délivré.'}</div>
    ${peut('hosp_quitus') && (!reste || peut('valider')) ? `<div class="row-actions"><button class="btn" data-action="hospQuitus">${reste ? 'Délivrer le quitus malgré le reste à payer' : 'Délivrer le quitus de sortie'}</button></div>` : ''}`;
}
/* Sur un document imprimé, les dates sont absolues (« 03/10/2026 à 19 h 23 ») : le papier sera relu les jours suivants. */
function dateHeureAbsolue(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return `${d.toLocaleDateString('fr-FR')} à ${String(d.getHours()).padStart(2, '0')} h ${String(d.getMinutes()).padStart(2, '0')}`;
}
function bonSortieHTML(h, d) {
  const p = h.patient, sejours = (d && d.sejours) || [];
  const corps = `<table class="doc-identite"><tbody>
      <tr><th>Patient</th><td>${esc(nomPatient(p))}</td><th>IPP</th><td>${esc(p.ipp || '')}</td></tr>
      <tr><th>Sexe</th><td>${p.sexe === 'F' ? 'Féminin' : p.sexe === 'M' ? 'Masculin' : '—'}</td><th>Date de naissance</th><td>${p.naissance ? `${fmtDate(p.naissance)} (${age(p.naissance)} ans)` : '—'}</td></tr>
      <tr><th>Admission</th><td>${dateHeureAbsolue(h.admis_le)}</td><th>Sortie</th><td>${dateHeureAbsolue(h.sortie_le)}</td></tr>
      <tr><th>Mode de sortie</th><td>${esc(h.mode_sortie || '')}</td><th>Médecin référent</th><td>${esc(h.medecin.nom)}</td></tr>
      <tr><th>Chambres</th><td colspan="3">${sejours.map(s => `${esc(s.code)} (${CAT_CHAMBRE[s.categorie]}) du ${dateHeureAbsolue(s.debut)}${s.fin ? ` au ${dateHeureAbsolue(s.fin)}` : ''}`).join(' ; ') || '—'}</td></tr>
      <tr><th>Règlement</th><td colspan="3">${h.reste ? `<strong>Reste dû : ${money(h.reste)}</strong>. Quitus délivré par la direction, motif : ${esc(h.quitus_motif || '')}` : 'Séjour soldé.'}</td></tr>
      <tr><th>Quitus</th><td colspan="3">Délivré ${dateHeureAbsolue(h.quitus_le)} par ${esc(h.quitus_par || '')}</td></tr>
    </tbody></table>
    <p>Le patient ci-dessus est autorisé à quitter la clinique.</p>
    <div class="bs-signatures"><div>La caisse</div><div>Le médecin référent</div><div>Contrôle à la sortie</div></div>`;
  return pieceA4({ titre: 'Bon de sortie', numero: h.numero, sous: `Hospitalisation du ${fmtDate(h.admis_le.slice(0, 10))} au ${fmtDate(h.sortie_le.slice(0, 10))}`, corps });
}
Object.assign(ACTIONS, {
  hospQuitus: async () => {
    const h = (E.hospitalisation.hospitalisations || []).find(x => x.id === hospUI().sel);
    if (!h) return;
    if (h.reste > 0) {
      openModal(`<div class="modal-head"><h2>Quitus malgré un reste à payer</h2>${closeBtn()}</div>
        <div class="notice bad">Reste à payer : <strong>${money(h.reste)}</strong>. Le quitus sera délivré au nom de la direction et tracé en alerte au journal.</div>
        ${champ('Motif', '<textarea id="hq-motif" rows="3" maxlength="300" placeholder="Ex. patient indigent, prise en charge sociale validée"></textarea>', '10 caractères au moins.')}
        <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="hospQuitusForce">Délivrer le quitus</button></div>`);
      return;
    }
    const r = await agir(() => api('POST', `/api/hospitalisations/${h.id}/quitus`, {}), 'Quitus délivré : le patient peut sortir.');
    if (r) rechargerSejour();
  },
  hospQuitusForce: async () => {
    const h = (E.hospitalisation.hospitalisations || []).find(x => x.id === hospUI().sel);
    if (!h) return;
    const r = await agir(() => api('POST', `/api/hospitalisations/${h.id}/quitus`, { motif: $('#hq-motif').value }), 'Quitus délivré par la direction, tracé au journal.');
    if (r) { closeModal(); rechargerSejour(); }
  },
  hospBonSortie: async () => {
    const ui = hospUI(), h = (E.hospitalisation.hospitalisations || []).find(x => x.id === ui.sel);
    if (!h) return;
    const d = ui.dossier && ui.dossier.id === h.id ? ui.dossier : await api('GET', '/api/hospitalisations/' + h.id);
    apercuA4('Bon de sortie', bonSortieHTML(h, d));
  }
});
