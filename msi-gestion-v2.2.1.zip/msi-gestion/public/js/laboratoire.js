'use strict';
/* Poste Laboratoire : examens payés à réaliser, saisie des résultats, validation, compte rendu imprimable. */
const STATUTS_LAB = { a_realiser: ['b-due', 'À réaliser'], en_cours: ['b-warn', 'En cours'], valide: ['b-ok', 'Validé'], a_payer: ['b-muted', 'À régler à la caisse'] };
function labUI() { if (!UI.lab) UI.lab = { file: null, version: 0, sel: null, ex: null, lignes: [], conclusion: '' }; return UI.lab; }
async function chargerFileLabo() {
  const L = labUI();
  try { L.file = await api('GET', '/api/laboratoire/file'); L.version = VERSION; if (UI.tab === 'laboratoire' && !modalOuverte()) render(); } catch (e) { toast(e.message, 'bad'); }
}
function vLaboratoire() {
  const L = labUI();
  if (L.file === null || L.version !== VERSION) { if (L.file === null) L.file = []; chargerFileLabo(); }
  const groupes = ['a_realiser', 'en_cours', 'a_payer', 'valide'].map(st => [st, L.file.filter(x => x.statut === st).sort((a, b) => b.urgent - a.urgent)]);
  return `<div class="view-head"><div><h1>Laboratoire</h1><p class="lead">Seuls les examens réglés, ou prescrits en urgence, se réalisent. Un résultat validé est transmis au médecin et ne se modifie plus.</p></div></div>
    <div class="grid-2"><section>${groupes.filter(([, l]) => l.length).map(([st, l]) => `<div class="panel"><h2>${STATUTS_LAB[st][1]} <span class="muted">(${l.length})</span></h2><ul class="list">${l.map(x => `<li>
      <button class="row-btn" data-action="labChoisir" data-id="${x.bon_id}"${L.sel === x.bon_id ? ' aria-current="true"' : ''}><span class="rb-main"><strong>${esc(x.libelle)}</strong>
      <span class="muted">${esc(nomPatient(x.patient))}, ${esc(x.patient.ipp || '')}, ${fmtDateTime(x.cree_le)}</span></span><span class="rb-side">${x.urgent ? '<span class="badge b-bad">Urgence</span>' : ''}<span class="badge ${STATUTS_LAB[st][0]}">${STATUTS_LAB[st][1]}</span></span></button></li>`).join('')}</ul></div>`).join('') || vide('Aucun examen', 'Les examens de laboratoire apparaissent ici dès leur prescription.')}</section>
    <section id="lab-detail">${L.ex ? ficheExamen(L.ex) : vide('Aucun examen sélectionné', 'Choisissez un examen dans la liste.')}</section></div>`;
}
function ficheExamen(ex) {
  const L = labUI(), p = ex.patient, lecture = ex.statut === 'valide', bloque = ex.statut === 'a_payer';
  const tete = `<div class="pat-head"><div><h2 class="pat-name">${esc(ex.libelle)}</h2><p class="muted">${esc(nomPatient(p))}, ${esc(p.ipp)}${p.sexe ? ', ' + (p.sexe === 'F' ? 'femme' : 'homme') : ''}${p.naissance ? ', ' + age(p.naissance) + ' ans' : ''}, ${esc(ex.passage)}</p></div><span class="badge ${STATUTS_LAB[ex.statut][0]}">${STATUTS_LAB[ex.statut][1]}</span></div>`;
  if (bloque) return `<div class="panel">${tete}<div class="notice bad">Examen non réglé : le patient doit passer à la caisse avant le prélèvement.</div></div>`;
  const normes = l => (l.min != null || l.max != null ? `${l.min != null ? NF.format(l.min) : ''} – ${l.max != null ? NF.format(l.max) : ''}` : '');
  return `<div class="panel">${tete}
    ${ex.historique.length ? `<p class="hint">${ex.historique.length} version(s) rectifiée(s) : ${ex.historique.map(h => esc(h.motif_rectification || '')).join(' ; ')}</p>` : ''}
    <div class="table-wrap"><table><thead><tr><th>Paramètre</th><th>Résultat</th><th>Unité</th><th>Normes</th><th></th></tr></thead><tbody>${L.lignes.map((l, i) => `<tr>
      <td>${lecture ? esc(l.p) : `<input value="${esc(l.p)}" data-input="labChamp" data-i="${i}" data-c="p" aria-label="Paramètre">`}</td>
      <td>${lecture ? `<strong>${esc(l.valeur)}</strong>` : `<input value="${esc(l.valeur)}" data-input="labChamp" data-i="${i}" data-c="valeur" aria-label="Résultat ${esc(l.p)}" autocomplete="off">`}</td>
      <td>${esc(l.unite)}</td><td class="muted">${normes(l)}</td><td>${l.drapeau ? `<span class="badge b-bad">${l.drapeau === 'H' ? 'Élevé' : 'Bas'}</span>` : ''}</td></tr>`).join('')}</tbody></table></div>
    ${lecture ? '' : '<div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="labLigne">Ajouter un paramètre</button></div>'}
    ${champ('Conclusion', `<textarea rows="2" data-input="labConclusion"${lecture ? ' readonly' : ''}>${esc(L.conclusion)}</textarea>`)}
    <div class="row-actions">${lecture
      ? '<button class="btn btn-ghost" data-action="labRectifier">Rectifier</button><button class="btn" data-action="labImprimer">Imprimer le compte rendu</button>'
      : '<button class="btn btn-ghost" data-action="labEnregistrer">Enregistrer</button><button class="btn" data-action="labValider">Valider et transmettre</button>'}</div></div>`;
}
async function ouvrirExamen(bonId) {
  const L = labUI();
  L.sel = bonId;
  L.ex = await api('GET', '/api/laboratoire/examens/' + bonId);
  L.lignes = (L.ex.resultat ? L.ex.resultat.donnees : L.ex.modele).map(l => ({ ...l }));
  L.conclusion = L.ex.resultat ? L.ex.resultat.conclusion || '' : '';
  render(); scrollToId('lab-detail');
}
const sauverResultat = () => api('POST', '/api/laboratoire/examens/' + labUI().sel, { lignes: labUI().lignes, conclusion: labUI().conclusion });
function compteRenduLabo(ex) {
  const r = ex.resultat, p = ex.patient;
  const corps = `<div class="pa-bloc"><div><strong>Patient :</strong> ${esc(nomPatient(p))}, ${esc(p.ipp)}${p.naissance ? ', ' + age(p.naissance) + ' ans' : ''}</div><div><strong>Passage :</strong> ${esc(ex.passage)}, prélèvement du ${fmtDate(jourDe(ex.cree_le))}</div></div>
    <table class="pa-table"><thead><tr><th>Paramètre</th><th>Résultat</th><th>Unité</th><th>Valeurs de référence</th><th></th></tr></thead><tbody>${r.donnees.map(l => `<tr><td>${esc(l.p)}</td><td><strong>${esc(l.valeur)}</strong></td><td>${esc(l.unite)}</td>
      <td>${l.min != null || l.max != null ? `${l.min != null ? NF.format(l.min) : ''} – ${l.max != null ? NF.format(l.max) : ''}` : ''}</td><td>${l.drapeau ? (l.drapeau === 'H' ? '↑ élevé' : '↓ bas') : ''}</td></tr>`).join('')}</tbody></table>
    ${r.conclusion ? `<p><strong>Conclusion :</strong> ${esc(r.conclusion)}</p>` : ''}<p class="muted">Validé le ${fmtDate(jourDe(r.valide_le))} à ${fmtTime(r.valide_le)}.</p><div class="pa-signature">Le biologiste</div>`;
  return pieceA4({ titre: 'Compte rendu d’analyses', numero: ex.libelle, corps });
}
Object.assign(ACTIONS, {
  labChoisir: el => ouvrirExamen(Number(el.dataset.id)).catch(e => toast(e.message, 'bad')),
  labLigne: () => { labUI().lignes.push({ p: 'Paramètre', valeur: '', unite: '', min: null, max: null }); render(); },
  labEnregistrer: () => agir(sauverResultat, r => (r.anormaux ? `Enregistré : ${r.anormaux} valeur(s) hors normes.` : 'Résultat enregistré.')).then(r => r && ouvrirExamen(labUI().sel)),
  labValider: async () => {
    const r = await agir(async () => { const s = await sauverResultat(); await api('POST', `/api/laboratoire/resultats/${s.id}/validation`); return s; }, 'Résultat validé et transmis au médecin.');
    if (r) await ouvrirExamen(labUI().sel);
  },
  labRectifier: () => openModal(`<div class="modal-head"><h2>Rectifier le résultat</h2>${closeBtn()}</div><p>Le résultat validé reste archivé ; une nouvelle version est ouverte, à valider à nouveau.</p>
    ${champ('Motif de la rectification', '<input id="lab-motif" autocomplete="off">')}<div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="labRectifierOk">Rectifier</button></div>`),
  labRectifierOk: async () => {
    const L = labUI();
    if (await agir(() => api('POST', `/api/laboratoire/resultats/${L.ex.resultat.id}/rectification`, { motif: $('#lab-motif').value }), 'Nouvelle version ouverte.')) { closeModal(); await ouvrirExamen(L.sel); }
  },
  labImprimer: () => apercuA4('Compte rendu d’analyses', compteRenduLabo(labUI().ex))
});
Object.assign(INPUTS, {
  labChamp: el => { labUI().lignes[Number(el.dataset.i)][el.dataset.c] = el.value; },
  labConclusion: el => { labUI().conclusion = el.value; }
});
ONGLETS.push({ id: 'laboratoire', libelle: 'Laboratoire', icone: 'laboratoire', visible: () => peut('laboratoire'),
  compteur: () => (UI.lab && UI.lab.file ? UI.lab.file.filter(x => x.statut === 'a_realiser').length : 0), vue: vLaboratoire });
