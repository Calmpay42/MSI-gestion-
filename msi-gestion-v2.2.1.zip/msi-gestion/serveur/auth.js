'use strict';
/* Comptes nominatifs, mots de passe hachés (scrypt), sessions à expiration, droits par profil. */
const crypto = require('crypto');
const { maintenant, err } = require('./outils');

const COOKIE = 'msi_session';
const DUREE_MAX_H = 12;

const ROLES = {
  accueil: 'Accueil, accord assurance',
  caisse: 'Accueil, facturation (caisse)',
  pharmacie: 'Pharmacie',
  pharmacien: 'Gérant de la pharmacie',
  medecin: 'Médecin ou praticien',
  infirmier: 'Infirmier ou infirmière',
  laboratoire: 'Laboratoire',
  raf: 'Responsable administratif et financier',
  facturiste: 'Facturiste (factures et assurances)',
  comptable: 'Comptable',
  rh: 'Ressources humaines',
  direction: 'Direction',
  admin: 'Administrateur système'
};

/* Moindre privilège : chaque droit liste les profils autorisés. */
const DROITS = {
  patient_lire: ['accueil', 'caisse', 'pharmacie', 'pharmacien', 'direction', 'raf', 'medecin', 'infirmier', 'laboratoire', 'facturiste'],
  consulter: ['medecin'],
  constantes: ['infirmier'],
  hosp_lire: ['accueil', 'caisse', 'medecin', 'infirmier', 'direction'],
  hosp_admettre: ['accueil', 'medecin', 'direction'],
  hosp_soins: ['infirmier', 'medecin'],
  hosp_gerer: ['medecin', 'infirmier', 'direction'],
  hosp_sortie: ['medecin', 'direction'],
  hosp_quitus: ['caisse', 'direction'],
  rdv_lire: ['accueil', 'caisse', 'medecin', 'direction'],
  rdv_ecrire: ['accueil', 'medecin'],
  prescriptions: ['pharmacie', 'pharmacien'],
  laboratoire: ['laboratoire'],
  tiers_payant: ['raf', 'facturiste', 'direction'],
  factures: ['caisse', 'raf', 'facturiste', 'direction'],
  patient_ecrire: ['accueil', 'medecin', 'direction'],
  patient_fusionner: ['admin'],
  passage_ouvrir: ['accueil', 'direction'],
  passage_annuler: ['admin'],
  accord: ['accueil', 'caisse', 'direction'],
  actes_ajouter: ['accueil', 'caisse'],
  caisse: ['caisse'],
  pharmacie: ['pharmacie', 'pharmacien'],
  stock_ajuster: ['pharmacie', 'pharmacien', 'direction'],
  valider: ['direction'],
  pilotage: ['direction', 'raf'],
  exports: ['direction', 'raf', 'facturiste', 'comptable'],
  compta_lire: ['comptable', 'raf', 'direction'],
  compta_parametrer: ['comptable', 'direction'],
  supprimer: ['admin'],
  suppression_demander: ['accueil', 'caisse', 'direction', 'raf', 'rh', 'facturiste', 'comptable', 'pharmacie', 'pharmacien', 'medecin', 'infirmier', 'laboratoire'],
  referentiels: ['direction', 'raf'],
  catalogue: ['pharmacien', 'direction'],
  rh_lire: ['rh', 'direction', 'raf'],
  rh_gerer: ['rh', 'direction'],
  paie_preparer: ['rh', 'raf', 'direction'],
  paie_valider: ['direction'],
  paie_payer: ['raf', 'direction'],
  parametres: ['direction'],
  utilisateurs: ['admin'],
  sauvegardes: ['admin', 'direction'],
  audit: ['direction', 'admin']
};
const peut = (u, droit) => !!u && (DROITS[droit] || []).some(r => u.roles.includes(r));

const OPTS = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
function hacher(mdp) {
  const sel = crypto.randomBytes(16);
  return 'scrypt$' + sel.toString('hex') + '$' + crypto.scryptSync(String(mdp), sel, 64, OPTS).toString('hex');
}
function verifierMdp(mdp, stocke) {
  const [algo, sel, h] = String(stocke || '').split('$');
  if (algo !== 'scrypt' || !sel || !h) return false;
  const calc = crypto.scryptSync(String(mdp), Buffer.from(sel, 'hex'), 64, OPTS);
  const ref = Buffer.from(h, 'hex');
  return ref.length === calc.length && crypto.timingSafeEqual(ref, calc);
}
function mdpProvisoire() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let s = '';
  for (const x of crypto.randomBytes(12)) s += a[x % a.length];
  return s.slice(0, 4) + '-' + s.slice(4, 8) + '-' + s.slice(8, 12);
}
function controlerMdp(m) {
  const s = String(m || '');
  if (s.length < 10 || !/[A-Za-z]/.test(s) || !/\d/.test(s)) throw err(400, 'Mot de passe trop faible : 10 caractères minimum, avec des lettres et des chiffres.');
  return s;
}
const empreinte = j => crypto.createHash('sha256').update(j).digest('hex');

function lireCookie(req, nom) {
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === nom) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}
function poserCookie(req, res, jeton, maxAge) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE}=${jeton}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure}`);
}
function ouvrirSession(db, u, req, res) {
  const jeton = crypto.randomBytes(32).toString('hex');
  const t = maintenant();
  db.prepare('INSERT INTO sessions(jeton, utilisateur_id, cree_le, vu_le, ip) VALUES (?,?,?,?,?)').run(empreinte(jeton), u.id, t, t, req.ip || null);
  poserCookie(req, res, jeton, DUREE_MAX_H * 3600);
}
function fermerSession(db, req, res) {
  const j = lireCookie(req, COOKIE);
  if (j) db.prepare('DELETE FROM sessions WHERE jeton = ?').run(empreinte(j));
  poserCookie(req, res, '', 0);
}

/* Charge l'utilisateur de la session ; déconnexion automatique après inactivité. */
function authentifier(db, inactiviteMin) {
  const lire = db.prepare('SELECT s.jeton, s.cree_le, s.vu_le, u.id, u.login, u.nom, u.roles, u.actif, u.changer_mdp, u.specialites, u.ordre FROM sessions s JOIN utilisateurs u ON u.id = s.utilisateur_id WHERE s.jeton = ?');
  const toucher = db.prepare('UPDATE sessions SET vu_le = ? WHERE jeton = ?');
  const supprimer = db.prepare('DELETE FROM sessions WHERE jeton = ?');
  return (req, res, next) => {
    const j = lireCookie(req, COOKIE);
    if (!j) return next();
    const h = empreinte(j);
    const s = lire.get(h);
    if (!s) return next();
    const now = Date.now();
    const inactif = now - Date.parse(s.vu_le) > inactiviteMin() * 60000;
    const tropVieux = now - Date.parse(s.cree_le) > DUREE_MAX_H * 3600000;
    if (!s.actif || inactif || tropVieux) { supprimer.run(h); return next(); }
    /* Les rafraîchissements automatiques des écrans ne comptent pas comme une activité de l'agent. */
    if (req.get('X-MSI-Auto') !== '1' && now - Date.parse(s.vu_le) > 30000) toucher.run(new Date(now).toISOString(), h);
    req.user = { id: s.id, login: s.login, nom: s.nom, roles: s.roles.split(',').filter(Boolean), changerMdp: !!s.changer_mdp, specialites: s.specialites || '', ordre: s.ordre || '' };
    next();
  };
}
function exiger(droit) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ erreur: 'Session expirée : reconnectez-vous.' });
    if (req.user.changerMdp) return res.status(403).json({ erreur: 'Changez votre mot de passe avant de continuer.', changer_mdp: true });
    if (droit && !peut(req.user, droit)) return res.status(403).json({ erreur: 'Action non autorisée pour votre profil.' });
    next();
  };
}

module.exports = { COOKIE, ROLES, DROITS, peut, hacher, verifierMdp, mdpProvisoire, controlerMdp, ouvrirSession, fermerSession, authentifier, exiger };
