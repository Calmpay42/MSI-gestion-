'use strict';
/* Recette de la version 1.9 : clôture mensuelle du tiers payant, tableau de bord personnel du médecin, rappel de clôture. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');
const R = require('../serveur/regles');
const S = require('../public/js/specialites');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, infirmier, meda, medb, fact;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const idDe = login => db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(login).id;
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
const periode = new Date().toISOString().slice(0, 7);
let n = 0;
async function passage(assure) {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'cloture' + n, prenoms: 'awa', sexe: 'F', naissance: '1985-04-12', telephone: `07 55 00 00 ${String(n).padStart(2, '0')}`,
    ...(assure ? { assureur_id: assure, num_assure: 'CL-' + n, taux: 80, validite: '2030-12-31' } : {}) });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const v = await accueil.post('/api/passages', { patient_id: p.data.id, type: 'consultation', acte_id: consultationMG(), ...(assure ? { accord: 'ACC-CL-' + n } : {}) });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0').all(v.data.id);
  const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode: 'Espèces', montant: bons.reduce((s, b) => s + R.montants(b).net, 0) }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return { patient_id: p.data.id, passage_id: v.data.id };
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v19-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('infirmier', 'infirmier'); compte('meda', 'medecin', 'Médecine générale'); compte('medb', 'medecin', 'Médecine générale'); compte('fact', 'facturiste');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, infirmier, meda, medb, fact] = await Promise.all(['accueil', 'caisse', 'infirmier', 'meda', 'medb', 'fact'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 50000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Clôture mensuelle : un bordereau par assureur, rejouable sans double facturation, rapport par service, historique inaltérable', async () => {
  const [a1, a2] = db.prepare('SELECT id, nom FROM assureurs WHERE actif = 1 ORDER BY id LIMIT 2').all();
  await passage(a1.id); await passage(a2.id);
  const avant = (await fact.get('/api/tiers-payant/cloture?periode=' + periode)).data;
  assert.ok(avant.a_facturer.some(x => x.assureur_id === a1.id) && avant.a_facturer.some(x => x.assureur_id === a2.id), JSON.stringify(avant.a_facturer));
  const attendu = avant.a_facturer.reduce((s, x) => s + x.montant, 0);
  assert.equal((await caisse.post('/api/tiers-payant/cloture', { periode })).status, 403, 'réservé au tiers payant');
  assert.equal((await fact.post('/api/tiers-payant/cloture', { periode: '2026-13' })).status, 400);
  assert.equal((await fact.post('/api/tiers-payant/cloture', { periode: '2099-01' })).status, 400, 'mois non commencé');
  const c = await fact.post('/api/tiers-payant/cloture', { periode });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  assert.equal(c.data.bordereaux.length, avant.a_facturer.length, 'un bordereau par assureur');
  assert.equal(c.data.total, attendu);
  const encore = await fact.post('/api/tiers-payant/cloture', { periode });
  assert.equal(encore.status, 409, 'rien à refacturer');
  assert.match(encore.data.erreur, /déjà sur un bordereau/);
  await passage(a1.id);
  const c2 = await fact.post('/api/tiers-payant/cloture', { periode });
  assert.equal(c2.status, 200, JSON.stringify(c2.data));
  assert.deepEqual(c2.data.bordereaux.map(b => b.assureur), [a1.nom], 'seule la prise en charge tardive est facturée');
  const r = (await fact.get('/api/tiers-payant/cloture?periode=' + periode)).data;
  assert.equal(r.a_facturer.length, 0);
  assert.equal(r.clotures.length, 2);
  assert.ok(r.services.some(s => s.service === 'Consultation' && s.montant > 0), JSON.stringify(r.services));
  assert.ok(r.total >= c.data.total + c2.data.total);
  assert.equal(r.reste, r.total - r.regle - r.rejete);
  assert.throws(() => db.prepare('DELETE FROM clotures_mensuelles').run(), /Suppression interdite/);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Clôture mensuelle'").get());
});

test('Tableau de bord du médecin : patients du jour et du mois, examens demandés, alertes infirmières, rendez-vous ; cloisonné par médecin', async () => {
  const { patient_id, passage_id } = await passage();
  assert.equal((await infirmier.post('/api/constantes', { passage_id, valeurs: { ta: '170/110' }, medecin_id: idDe('meda') })).status, 200);
  const c = await meda.post('/api/consultations', { passage_id });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  const exa = S.BILAN.flatMap(g => g.items).slice(0, 2);
  const d = await meda.post('/api/documents', { type: 'examens', consultation_id: c.data.id, donnees: { items: exa } });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  assert.equal((await accueil.post('/api/rdv', { patient_id, date: demain, heure: '10:00', medecin_id: idDe('meda'), specialite: 'Médecine générale', motif: 'Contrôle tensionnel' })).status, 200);
  const t = (await meda.get('/api/medecin/tableau')).data;
  assert.ok(t.aujourdhui.consultations >= 1 && t.mois_courant.patients >= 1, JSON.stringify(t.aujourdhui));
  assert.equal(t.serie.length, 30);
  assert.ok(t.serie[29].n >= 1, 'consultation du jour dans la courbe');
  assert.equal(t.examens.demandes, 1);
  assert.deepEqual(t.examens.top.map(x => x.l).sort(), [...exa].sort());
  const al = t.alertes.find(a => a.source === 'infirmerie');
  assert.ok(al && al.alertes.some(x => x.k === 'ta') && al.recu === true, JSON.stringify(t.alertes));
  assert.ok(t.rdv.some(r => r.motif === 'Contrôle tensionnel'));
  assert.ok(t.documents.some(x => x.type === 'examens' && x.n === 1));
  assert.equal((await accueil.get('/api/medecin/tableau')).status, 403);
  const autre = (await medb.get('/api/medecin/tableau')).data;
  assert.equal(autre.aujourdhui.consultations, 0, 'chaque médecin ne voit que son activité');
  assert.equal(autre.alertes.length, 0);
});

test('Rappel de clôture : le facturiste est prévenu en début de mois tant que le mois précédent n’est pas facturé', async () => {
  const [a1] = db.prepare('SELECT id FROM assureurs WHERE actif = 1 ORDER BY id LIMIT 1').all();
  const { passage_id } = await passage(a1.id);
  const d = new Date(); d.setUTCDate(0);
  const finMoisPrec = d.toISOString().slice(0, 10) + 'T10:00:00.000Z';
  /* Un reçu ne se modifie jamais (protection anti-fraude). Pour simuler un reçu du mois précédent, la règle est levée
     sur cette seule base de test puis rétablie à l'identique depuis sa définition enregistrée. */
  const regles = db.prepare("SELECT name, sql FROM sqlite_master WHERE type = 'trigger' AND tbl_name = 'recus' AND sql LIKE '%UPDATE%'").all();
  assert.ok(regles.length, 'protection des reçus présente');
  for (const t of regles) db.exec(`DROP TRIGGER ${t.name}`);
  db.prepare('UPDATE recus SET cree_le = ? WHERE id IN (SELECT recu_id FROM bons WHERE passage_id = ?)').run(finMoisPrec, passage_id);
  for (const t of regles) db.exec(t.sql);
  assert.throws(() => db.prepare('UPDATE recus SET cree_le = cree_le WHERE id IN (SELECT recu_id FROM bons WHERE passage_id = ?)').run(passage_id), /non modifiable/, 'protection rétablie');
  const notif = (await fact.get('/api/etat')).data.notifications.find(x => x.titre === 'Clôture mensuelle à faire');
  if (new Date().getUTCDate() <= 10) assert.ok(notif && /à facturer/.test(notif.message), 'rappel attendu en début de mois');
  else assert.ok(!notif, 'pas de rappel après le 10 du mois');
});
