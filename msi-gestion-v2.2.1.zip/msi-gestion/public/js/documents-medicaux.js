'use strict';
/* Documents médicaux : saisie, émission (numérotée, jamais modifiable) et impression A5 à l'en-tête de MSI.
   Pas de signature ni de cachet numériques : l'espace est réservé à la signature manuscrite et au cachet. */
const LIB_DOC = { ordonnance: 'Ordonnance médicale', examens: 'Demande d’examens', lunettes: 'Ordonnance de lunettes', certificat: 'Certificat', compte_rendu: 'Compte rendu', orientation: 'Lettre d’orientation', note: 'Note complémentaire', rdv: 'Rendez-vous', conseils: 'Fiches conseils' };
const ENTETE_SPECIALITES = 'Cardiologie · Néphrologie · Rhumatologie · Dermatologie · Diabétologie · Ophtalmologie · Infectiologie · Pédiatrie médicale · Chirurgie pédiatrique · Gynécologie-obstétrique · Médecine générale';
const spCourante = () => SP.SPECIALITES[etatCons().c.specialite];
const valeur = sel => { const el = $(sel); return el ? el.value : ''; };
const piedModal = libelle => `<div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="docEmettre">${libelle}</button></div>`;
const chipsCible = (cible, liste) => (liste && liste.length ? `<div class="chips">${liste.map(v => `<button class="chip" data-action="chipCible" data-cible="${cible}" data-v="${esc(v)}">${esc(v)}</button>`).join('')}</div>` : '');
const facturableMSI = code => !!code && E.actes.some(a => a.code === code && a.actif);

function listeDocuments(docs) {
  if (!docs.length) return '<p class="muted">Aucun document émis.</p>';
  return `<ul class="plist">${docs.map(x => `<li><div><strong>${esc(x.numero)}</strong><div class="muted">${esc(LIB_DOC[x.type])}${x.specialite ? ', ' + esc(lcFirst(x.specialite)) : ''}, ${fmtDateTime(x.cree_le)}</div></div>
    <div class="pl-side"><button class="btn btn-sm btn-ghost" data-action="docVoir" data-id="${x.id}">Voir et imprimer</button></div></li>`).join('')}</ul>`;
}
function ongletDocuments(c, sp) {
  const docs = ((etatCons().dossier || {}).documents || []).filter(x => x.consultation_id === c.id);
  const auteur = c.medecin_id === MOI.utilisateur.id;
  return `${auteur ? `<div class="panel"><h2>Émettre un document</h2>${!MOI.utilisateur.ordre && !E.formation ? '<div class="notice warn">Votre n° d’inscription à l’Ordre des médecins n’est pas renseigné : il manquera sur vos ordonnances et certificats. Demandez à l’administrateur de le saisir (Paramétrage, Utilisateurs).</div>' : ''}<div class="row-actions wrap">${sp.documents.map(t => `<button class="btn btn-ghost btn-sm" data-action="docNouveau" data-type="${t}">${esc(LIB_DOC[t])}</button>`).join('')}
    ${c.valide_le ? '<button class="btn btn-ghost btn-sm" data-action="docNouveau" data-type="note">Note complémentaire</button>' : ''}</div>
    <p class="hint">Les examens marqués « Caisse MSI » créent un bon : le patient les règle avant leur réalisation.</p></div>` : ''}
    <div class="panel"><h2>Documents de cette consultation</h2>${listeDocuments(docs)}</div>
    ${galeriePieces(((etatCons().dossier || {}).pieces || []).filter(x => x.consultation_id === c.id), auteur)}`;
}

/* Fenêtres de saisie */
function lignesOrdMedicale() {
  return UI.doc.lignes.map((l, i) => `<div class="ord-ligne">
    <label class="f"><span>Médicament</span><input list="dl-medocs" value="${esc(l.medicament)}" data-input="ordChamp" data-change="ordMedoc" data-i="${i}" data-c="medicament" autocomplete="off"></label>
    <label class="f"><span>Posologie</span><input value="${esc(l.posologie)}" data-input="ordChamp" data-i="${i}" data-c="posologie" placeholder="1 comprimé matin et soir" autocomplete="off"></label>
    <label class="f"><span>Durée</span><input value="${esc(l.duree)}" data-input="ordChamp" data-i="${i}" data-c="duree" placeholder="7 jours, 3 mois, au long cours" autocomplete="off"></label>
    ${UI.doc.lignes.length > 1 ? `<button class="icon-btn" data-action="ordRetirer" data-i="${i}" aria-label="Retirer ce médicament">${icon('close', 18)}</button>` : '<span></span>'}</div>`).join('');
}
const FORMULAIRES = {
  ordonnance: sp => {
    UI.doc.lignes = [{ medicament: '', posologie: '', duree: '' }];
    return `<datalist id="dl-medocs">${sp.medicaments.map(m => `<option value="${esc(m[0])}">${esc([m[1], m[3]].filter(Boolean).join(', '))}</option>`).join('')}</datalist>
      <div id="ord-lignes">${lignesOrdMedicale()}</div><div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="ordAjouter">Ajouter un médicament</button></div>
      ${champ('Conseils au patient', '<textarea id="doc-conseils" rows="2"></textarea>')}
      <p class="hint">Posologies proposées à titre indicatif : adaptez-les au patient (âge, poids, fonction rénale, grossesse).</p>${piedModal('Émettre l’ordonnance')}`;
  },
  examens: sp => `${sp.examens.length ? `<h3>Examens de ${esc(lcFirst(sp.nom))}</h3><div class="coches">${sp.examens.map(e => `<label class="case"><input type="checkbox" name="exa" value="${esc(e.l)}"> ${esc(e.l)}${facturableMSI(e.code) ? ' <span class="badge b-due">Caisse MSI</span>' : ''}</label>`).join('')}</div>` : ''}
    ${sp.bilan ? `<details class="constats"><summary>Bilan biologique (bulletin MSI)</summary>${SP.BILAN.map(gr => `<div class="constats-groupe"><strong>${esc(gr.title)}</strong><div class="coches">${gr.items.map(i => `<label class="case"><input type="checkbox" name="exa" value="${esc(i)}"> ${esc(i)}${facturableMSI(SP.LABO[i]) ? ' <span class="badge b-due">Caisse MSI</span>' : ''}</label>`).join('')}</div></div>`).join('')}</details>` : ''}
    ${champ('Autres examens (texte libre)', '<textarea id="exa-autres" rows="2"></textarea>')}
    ${champ('Renseignement clinique', '<textarea id="exa-rens" rows="2"></textarea>')}${chipsCible('exa-rens', sp.infos_examens)}
    <label class="case"><input type="checkbox" id="exa-urgent"> Examen urgent</label>${piedModal('Émettre la demande')}`,
  lunettes: () => `<div class="table-wrap"><table class="table-lunettes"><thead><tr><th></th><th>Sphère</th><th>Cylindre</th><th>Axe</th><th>Addition</th></tr></thead><tbody>
    ${['od', 'og'].map(o => `<tr><th>${o.toUpperCase()}</th>${['sphere', 'cylindre', 'axe', 'addition'].map(k => `<td><input data-lun="${o}.${k}" inputmode="decimal" aria-label="${o.toUpperCase()} ${k}" autocomplete="off"></td>`).join('')}</tr>`).join('')}</tbody></table></div>
    <div class="form-grid two">${champ('Écart pupillaire (mm)', '<input id="lun-ecart" inputmode="decimal">')}${champ('Vision', '<select id="lun-vision"><option>Vision de loin</option><option>Vision de près</option><option>Vision de loin et de près</option></select>')}
    ${champ('Type de verres', '<select id="lun-verres"><option>Unifocaux</option><option>Progressifs</option><option>Bifocaux</option><option>Mi-distance</option></select>')}</div>
    <fieldset class="cases"><legend>Options</legend>${['Antireflet', 'Photochromique', 'Filtre lumière bleue', 'Teinté', 'Aminci', 'Polycarbonate (enfant)'].map(o => `<label><input type="checkbox" name="lun-opt" value="${o}"> ${o}</label>`).join('')}</fieldset>
    ${champ('Remarques', '<textarea id="lun-rem" rows="2"></textarea>')}${piedModal('Émettre l’ordonnance de lunettes')}`,
  certificat: sp => {
    const arret = UI.doc.sous === 'arret';
    return `<div class="seg" role="group"><button data-action="certType" data-s="medical" aria-pressed="${!arret}">Certificat médical</button><button data-action="certType" data-s="arret" aria-pressed="${arret}">Arrêt de travail</button></div>
    ${arret ? `<div class="form-grid two">${champ('Nombre de jours', '<input id="cert-jours" type="number" min="1" max="365" value="3">')}${champ('À compter du', `<input id="cert-debut" type="date" value="${todayISO()}">`)}</div>
      ${champ('Motif (usage interne, non imprimé)', '<input id="cert-motif" autocomplete="off">')}`
    : `${champ('Objet', `<select id="cert-objet" data-change="certObjet">${SP.CERTIF_OBJETS.map(o => `<option>${esc(o)}</option>`).join('')}</select>`)}
      <div id="cert-libre" hidden>${champ('Objet précisé', '<input id="cert-objet-libre" autocomplete="off">')}</div><div id="cert-modeles">${modelesCertificat(sp, SP.CERTIF_OBJETS[0])}</div>
      ${champ('Constatations', '<textarea id="cert-constat" rows="3"></textarea>')}${champ('Conclusion', '<textarea id="cert-conclusion" rows="3"></textarea>')}`}
    ${piedModal('Émettre le certificat')}`;
  },
  compte_rendu: sp => {
    if (!UI.doc.cle) UI.doc.cle = sp.comptes_rendus[0].cle;
    const m = sp.comptes_rendus.find(x => x.cle === UI.doc.cle);
    return `${champ('Examen ou intervention', `<select data-change="crType">${sp.comptes_rendus.map(x => `<option value="${x.cle}"${x.cle === UI.doc.cle ? ' selected' : ''}>${esc(x.l)}</option>`).join('')}</select>`)}
      ${Object.keys(m.modeles).length ? `<div class="chips">${Object.keys(m.modeles).map(n => `<button class="chip" data-action="crModele" data-n="${esc(n)}">Modèle : ${esc(n)}</button>`).join('')}</div>` : ''}
      ${m.champs.map(f => f.t === 'liste' ? champ(esc(f.l), `<select data-cr="${f.k}"><option value=""></option>${f.options.map(o => `<option>${esc(o)}</option>`).join('')}</select>`)
        : f.t === 'zone' ? champ(esc(f.l), `<textarea data-cr="${f.k}" rows="${f.lignes || 2}"></textarea>`) : champ(esc(f.l) + (f.unite ? ` (${esc(f.unite)})` : ''), `<input data-cr="${f.k}" autocomplete="off">`)).join('')}
      ${piedModal('Émettre le compte rendu')}`;
  },
  orientation: sp => `${champ('Adressé à', `<select id="ori-dest" data-change="oriDest"><option value="">Choisir</option>${SP.noms().filter(n => n !== sp.nom).map(n => `<option>${esc(n)}</option>`).join('')}<option value="__autre">Autre (confrère ou établissement extérieur)</option></select>`)}
    <div id="ori-libre" hidden>${champ('Destinataire', '<input id="ori-dest-libre" autocomplete="off">')}</div>
    ${champ('Motif et renseignements cliniques', '<textarea id="ori-motif" rows="4"></textarea>')}<div id="ori-sugg"></div>
    <label class="case"><input type="checkbox" id="ori-urgent"> Orientation urgente</label>${piedModal('Émettre la lettre')}`,
  rdv: sp => `<div class="form-grid two">${champ('Date', `<input id="rdv-date" type="date" min="${todayISO()}" value="${esc(etatCons().d.prochain_controle || '')}">`)}${champ('Heure', '<input id="rdv-heure" type="time">')}</div>
    ${champ('Motif', `<input id="rdv-motif" list="dl-rdv" autocomplete="off"><datalist id="dl-rdv">${sp.rdv_motifs.map(m => `<option value="${esc(m)}">`).join('')}</datalist>`)}
    <p class="hint">Le rendez-vous apparaît à l’accueil, qui peut rappeler le patient la veille.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rdvEnregistrer">Enregistrer le rendez-vous</button></div>`,
  conseils: () => `<p class="hint">Cochez les fiches à remettre au patient : elles s’impriment à la suite, sous votre nom.</p>
    <div class="exam-grid">${spCourante().conseils.map(f => `<label class="case"><input type="checkbox" name="cons-fiche" value="${esc(f.code)}"> ${esc(f.titre)}</label>`).join('')}</div>${piedModal('Émettre les fiches')}`,
  note: () => `${champ('Note complémentaire', '<textarea id="note-texte" rows="5"></textarea>')}<p class="hint">La note est datée et rattachée à la consultation validée, qui reste inchangée.</p>${piedModal('Ajouter la note')}`
};
function modelesCertificat(sp, objet) {
  const m = sp.certificats[objet] || [];
  return m.length ? `<div class="chips">${m.map((x, i) => `<button class="chip" data-action="certModele" data-o="${esc(objet)}" data-i="${i}">Modèle : ${esc(x.label)}</button>`).join('')}</div>` : '';
}
function ouvrirDocument(type) {
  UI.doc = { type, sous: (UI.doc && UI.doc.type === type && UI.doc.sous) || 'medical', cle: UI.doc && UI.doc.type === type ? UI.doc.cle : null };
  const sp = spCourante();
  openModal(`<div class="modal-head"><div><h2>${esc(LIB_DOC[type])}</h2><p class="muted">${esc(nomPatient(ligneFile(etatCons().sel).patient))}, ${esc(sp.nom)}</p></div>${closeBtn()}</div>${FORMULAIRES[type](sp)}`, { large: true });
}
function lireDocumentSaisi(type) {
  switch (type) {
    case 'ordonnance': return { lignes: UI.doc.lignes, conseils: valeur('#doc-conseils') };
    case 'examens': return { items: [...document.querySelectorAll('input[name="exa"]:checked')].map(x => ({ l: x.value })), autres: valeur('#exa-autres'), renseignement: valeur('#exa-rens'), urgent: $('#exa-urgent').checked };
    case 'lunettes': {
      const o = { od: {}, og: {} };
      document.querySelectorAll('[data-lun]').forEach(x => { const [oeil, k] = x.dataset.lun.split('.'); o[oeil][k] = x.value; });
      return { ...o, ecart: valeur('#lun-ecart'), vision: valeur('#lun-vision'), verres: valeur('#lun-verres'), options: [...document.querySelectorAll('input[name="lun-opt"]:checked')].map(x => x.value), remarques: valeur('#lun-rem') };
    }
    case 'certificat': return UI.doc.sous === 'arret'
      ? { sous_type: 'arret', jours: Number(valeur('#cert-jours')), debut: valeur('#cert-debut'), motif_interne: valeur('#cert-motif') }
      : { sous_type: 'medical', objet: valeur('#cert-objet') === 'Autre (préciser)' ? valeur('#cert-objet-libre') : valeur('#cert-objet'), constat: valeur('#cert-constat'), conclusion: valeur('#cert-conclusion') };
    case 'compte_rendu': return { cle: UI.doc.cle, champs: Object.fromEntries([...document.querySelectorAll('[data-cr]')].map(x => [x.dataset.cr, x.value])) };
    case 'orientation': return { destinataire: valeur('#ori-dest') === '__autre' ? valeur('#ori-dest-libre') : valeur('#ori-dest'), motif: valeur('#ori-motif'), urgent: $('#ori-urgent').checked };
    case 'conseils': return { codes: [...document.querySelectorAll('input[name="cons-fiche"]:checked')].map(x => x.value) };
    case 'note': return { texte: valeur('#note-texte') };
    default: return {};
  }
}

/* Impression A5 */
function corpsDocument(d) {
  const x = d.donnees, p = d.patient;
  const civ = p ? (p.sexe === 'F' ? 'Madame' : p.sexe === 'M' ? 'Monsieur' : '') : '';
  const qui = `${civ} ${esc(nomPatient(p))}${p && p.naissance ? `, né${p.sexe === 'F' ? 'e' : ''} le ${fmtDate(p.naissance)}` : ''}`;
  switch (d.type) {
    case 'ordonnance': return `<ol class="doc-lignes">${x.lignes.map(l => `<li><strong>${esc(l.medicament)}</strong>${l.posologie ? `<div>${esc(l.posologie)}</div>` : ''}${l.duree ? `<div>Durée : ${esc(l.duree)}</div>` : ''}</li>`).join('')}</ol>${x.conseils ? `<p><strong>Conseils :</strong> ${esc(x.conseils)}</p>` : ''}`;
    case 'examens': return `${x.urgent ? '<p class="doc-urgent">Examen urgent</p>' : ''}<ul class="doc-lignes">${x.items.map(i => `<li>${esc(i.l)}</li>`).join('')}</ul>${x.autres ? `<p>${esc(x.autres)}</p>` : ''}${x.renseignement ? `<p><strong>Renseignement clinique :</strong> ${esc(x.renseignement)}</p>` : ''}`;
    case 'lunettes': return `<table class="doc-table"><thead><tr><th></th><th>Sphère</th><th>Cylindre</th><th>Axe</th><th>Addition</th></tr></thead><tbody>${['od', 'og'].map(o => `<tr><th>${o === 'od' ? 'Œil droit' : 'Œil gauche'}</th>${['sphere', 'cylindre', 'axe', 'addition'].map(k => `<td>${esc(x[o][k] || '')}${k === 'axe' && x[o][k] ? '°' : ''}</td>`).join('')}</tr>`).join('')}</tbody></table>
      <p>${esc(x.vision)}, verres ${esc(lcFirst(x.verres))}${x.options.length ? ', ' + esc(x.options.join(', ').toLowerCase()) : ''}${x.ecart ? `. Écart pupillaire : ${esc(x.ecart)} mm` : ''}.</p>${x.remarques ? `<p>${esc(x.remarques)}</p>` : ''}`;
    case 'certificat': return x.sous_type === 'arret'
      ? `<p>Je soussigné(e), ${esc(d.medecin)}, certifie avoir examiné ce jour ${qui}, et que son état de santé nécessite un arrêt de travail de <strong>${x.jours} jour${x.jours > 1 ? 's' : ''}</strong> à compter du ${fmtDate(x.debut)}, sauf complications.</p><p>Reprise du travail prévue le ${fmtDate(x.reprise)}.</p>`
      : `<p>Je soussigné(e), ${esc(d.medecin)}, certifie avoir examiné ce jour ${qui}.</p><p>${esc(x.constat)}</p><p>${esc(x.conclusion)}</p><p>Certificat établi à la demande de l’intéressé(e) et remis en main propre pour servir et valoir ce que de droit.</p>`;
    case 'compte_rendu': {
      const m = (SP.SPECIALITES[d.specialite].comptes_rendus.find(c => c.cle === x.cle) || { champs: [] });
      return `<p class="doc-soustitre">${esc(x.titre)}</p>${m.champs.filter(f => x.champs[f.k]).map(f => `<p><strong>${esc(f.l)}${f.unite ? ` (${esc(f.unite)})` : ''} :</strong><br>${esc(x.champs[f.k])}</p>`).join('')}`;
    }
    case 'orientation': return `<p><strong>À l’attention de :</strong> ${esc(x.destinataire)}${x.urgent ? ' <span class="doc-urgent">(urgent)</span>' : ''}</p><p>Cher(e) confrère,</p><p>Je vous adresse ${qui}, pour avis et prise en charge.</p><p>${esc(x.motif)}</p><p>Je vous remercie de votre collaboration. Bien confraternellement.</p>`;
    case 'conseils': return x.fiches.map(f => `<p class="doc-soustitre">${esc(f.titre)}</p><ul class="doc-lignes">${f.items.map(i => `<li>${esc(i)}</li>`).join('')}</ul>`).join('');
    case 'note': return `<p>${esc(x.texte)}</p>`;
    default: return '';
  }
}
function documentHTML(d) {
  const e = d.etablissement, p = d.patient, ville = String(e.adresse || '').split(',')[0], m = d.mesures || {};
  const titre = d.type === 'certificat' ? (d.donnees.sous_type === 'arret' ? 'Certificat d’arrêt de travail' : 'Certificat médical') : d.libelle;
  const identite = d.type === 'certificat' || !p ? '' : `<table class="doc-identite"><tbody>
      <tr><th>Patient</th><td>${esc(nomPatient(p))}</td><th>IPP</th><td>${esc(p.ipp || '')}</td></tr>
      <tr><th>Sexe</th><td>${p.sexe === 'F' ? 'Féminin' : p.sexe === 'M' ? 'Masculin' : '—'}</td><th>Date de naissance</th><td>${p.naissance ? `${fmtDate(p.naissance)} (${age(p.naissance)} ans)` : '—'}</td></tr>
      ${m.poids || m.taille ? `<tr><th>Poids</th><td>${m.poids ? esc(m.poids) + ' kg' : '—'}</td><th>Taille</th><td>${m.taille ? esc(m.taille) + ' cm' : '—'}</td></tr>` : ''}
    </tbody></table>`;
  return `<div class="doc doc-a4">
    <header class="doc-tete-a4"><img src="/img/logo-msi.png" alt="Maison de Santé Innov’Care" class="doc-logo">
      <div class="doc-clinique"><strong>${esc(e.raison)}</strong><div>${esc(e.forme)}</div><div>${esc(e.adresse)}</div><div>Tél. ${esc(e.telephone)}</div><div>${esc(e.rccm)}, ${esc(e.ncc)}</div></div></header>
    <div class="doc-specs">${ENTETE_SPECIALITES}</div>
    <div class="doc-entete"><div><strong>${esc(d.medecin)}</strong><div>${esc(d.specialite)}</div>${d.medecin_ordre ? `<div>N° d’inscription à l’Ordre : ${esc(d.medecin_ordre)}</div>` : ''}</div>
      <div class="doc-lieu">${esc(ville)}, le ${fmtDate(jourDe(d.cree_le))}<br>Document ${esc(d.numero)}</div></div>
    <h1 class="doc-titre">${esc(titre)}</h1>
    ${identite}
    <div class="doc-corps">${corpsDocument(d)}</div>
    <div class="doc-signature"><strong>${esc(d.medecin)}</strong><span>Signature et cachet</span></div>
    <footer class="doc-pied">${esc(e.raison)}, ${esc(e.forme)}, ${esc(e.adresse)}, ${esc(e.telephone)}<br>${esc(e.rccm)}, ${esc(e.ncc)}. Document ${esc(d.numero)} édité le ${fmtDate(jourDe(d.cree_le))}${d.formation ? ' : base de formation, sans valeur' : ''}</footer>
  </div>`;
}
async function voirDocument(id) {
  try {
    const d = await api('GET', '/api/documents/' + id);
    UI.docImprime = d;
    openModal(`<div class="modal-head"><h2>${esc(d.numero)}</h2>${closeBtn()}</div><div class="doc-apercu">${documentHTML(d)}</div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button><button class="btn" data-action="docImprimer">Imprimer (A4)</button></div>`, { large: true, noFocus: true });
  } catch (e) { toast(e.message, 'bad'); }
}

Object.assign(ACTIONS, {
  docNouveau: el => ouvrirDocument(el.dataset.type),
  docVoir: el => voirDocument(el.dataset.id),
  docImprimer: () => imprimer(documentHTML(UI.docImprime)),
  docEmettre: async () => {
    const s = etatCons(), type = UI.doc.type;
    const r = await agir(() => api('POST', '/api/documents', { type, consultation_id: s.cid, donnees: lireDocumentSaisi(type) }),
      r => `${r.numero} émis${r.factures ? ` : ${r.factures} examen${r.factures > 1 ? 's' : ''} envoyé${r.factures > 1 ? 's' : ''} à la caisse` : ''}.`);
    if (!r) return;
    closeModal();
    await rechargerDossier();
    etatCons().onglet = 'documents';
    render();
    voirDocument(r.id);
  },
  ordAjouter: () => { UI.doc.lignes.push({ medicament: '', posologie: '', duree: '' }); $('#ord-lignes').innerHTML = lignesOrdMedicale(); },
  ordRetirer: el => { UI.doc.lignes.splice(Number(el.dataset.i), 1); $('#ord-lignes').innerHTML = lignesOrdMedicale(); },
  chipCible: el => { const t = $('#' + el.dataset.cible); if (t) t.value = t.value.trim() ? t.value.trim() + '\n' + el.dataset.v : el.dataset.v; },
  certType: el => { UI.doc.sous = el.dataset.s; ouvrirDocument('certificat'); },
  certModele: el => { const m = spCourante().certificats[el.dataset.o][Number(el.dataset.i)]; $('#cert-constat').value = m.constat; $('#cert-conclusion').value = m.conclusion; },
  crModele: el => {
    const m = spCourante().comptes_rendus.find(x => x.cle === UI.doc.cle).modeles[el.dataset.n];
    document.querySelectorAll('[data-cr]').forEach(x => { if (m[x.dataset.cr] !== undefined) x.value = m[x.dataset.cr]; });
  },
  rdvEnregistrer: async () => {
    const x = ligneFile(etatCons().sel);
    const ok = await agir(() => api('POST', '/api/rdv', { patient_id: x.patient.id, date: valeur('#rdv-date'), heure: valeur('#rdv-heure'), motif: valeur('#rdv-motif'), specialite: spCourante().nom }), 'Rendez-vous enregistré.');
    if (ok) { closeModal(); await rechargerDossier(); render(); }
  }
});
Object.assign(INPUTS, { ordChamp: el => { UI.doc.lignes[Number(el.dataset.i)][el.dataset.c] = el.value; } });
Object.assign(CHANGES, {
  ordMedoc: el => {
    /* Posologie usuelle proposée dans son seul champ, sans redessiner les lignes : le champ où le médecin vient de cliquer garde sa saisie. */
    const i = Number(el.dataset.i), l = UI.doc.lignes[i], m = spCourante().medicaments.find(x => x[0] === el.value);
    if (m && !l.posologie) { l.posologie = m[2]; const champ = document.querySelector(`#ord-lignes [data-c="posologie"][data-i="${i}"]`); if (champ) champ.value = m[2]; }
  },
  certObjet: el => { $('#cert-libre').hidden = el.value !== 'Autre (préciser)'; $('#cert-modeles').innerHTML = modelesCertificat(spCourante(), el.value); },
  crType: el => { UI.doc.cle = el.value; ouvrirDocument('compte_rendu'); },
  oriDest: el => { $('#ori-libre').hidden = el.value !== '__autre'; $('#ori-sugg').innerHTML = chipsCible('ori-motif', spCourante().orientation[el.value]); }
});

/* Photos et documents scannés du dossier (fond d'œil, lésion cutanée, résultat d'examen extérieur…) */
function galeriePieces(pieces, ajout) {
  if (!pieces.length && !ajout) return '';
  return `<div class="panel"><div class="panel-head"><h2>Photos et documents joints</h2>${ajout ? '<button class="btn btn-ghost btn-sm" data-action="pieceNouvelle">Ajouter une photo ou un PDF</button>' : ''}</div>
    ${pieces.length ? `<div class="pieces">${pieces.map(x => `<a class="piece" href="/api/pieces/${x.id}" target="_blank" rel="noopener">${x.mime.startsWith('image/')
      ? `<img src="/api/pieces/${x.id}" alt="${esc(x.legende || x.nom)}" loading="lazy">` : '<span class="piece-pdf">PDF</span>'}
      <span class="piece-leg">${esc(x.legende || x.nom)}<br><span class="muted">${fmtDate(jourDe(x.cree_le))}${x.specialite ? ', ' + esc(x.specialite) : ''}</span></span></a>`).join('')}</div>`
      : '<p class="muted">Aucune photo ni document joint.</p>'}</div>`;
}
/* Réduit une photo à 1 600 pixels au plus (JPEG) : le dossier reste léger et la sauvegarde rapide. */
function reduirePhoto(fichier) {
  /* Lecture en data: (autorisée par la politique de sécurité du site, contrairement aux adresses blob:). */
  return new Promise((ok, ko) => {
    const lecteur = new FileReader();
    lecteur.onerror = () => ko(new Error('Image illisible.'));
    lecteur.onload = () => {
      const img = new Image();
      img.onload = () => {
        const r = Math.min(1, 1600 / Math.max(img.width, img.height)), c = document.createElement('canvas');
        c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        ok(c.toDataURL('image/jpeg', 0.85).split(',')[1]);
      };
      img.onerror = () => ko(new Error('Image illisible.'));
      img.src = lecteur.result;
    };
    lecteur.readAsDataURL(fichier);
  });
}
const lireBase64 = f => new Promise((ok, ko) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1]); r.onerror = () => ko(new Error('Fichier illisible.')); r.readAsDataURL(f); });
Object.assign(ACTIONS, {
  pieceNouvelle: () => openModal(`<div class="modal-head"><h2>Ajouter une photo ou un document scanné</h2>${closeBtn()}</div>
    ${champ('Fichier (photo ou PDF, 3 Mo au plus)', '<input type="file" id="piece-fichier" accept="image/jpeg,image/png,image/webp,application/pdf" capture="environment">')}
    ${champ('Légende', '<input id="piece-legende" placeholder="Ex. rétinophotographie OD, résultat de laboratoire extérieur" autocomplete="off">')}
    <p class="hint">Les photos sont réduites automatiquement. Une pièce jointe ne peut plus être modifiée ni supprimée.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="pieceEnregistrer">Joindre au dossier</button></div>`),
  pieceEnregistrer: async () => {
    const f = ($('#piece-fichier').files || [])[0];
    if (!f) { toast('Choisissez un fichier.', 'bad'); return; }
    let contenu, mime = f.type;
    try {
      if (mime === 'application/pdf') contenu = await lireBase64(f);
      else if (mime.startsWith('image/')) { contenu = await reduirePhoto(f); mime = 'image/jpeg'; }
      else { toast('Format accepté : photo ou PDF.', 'bad'); return; }
    } catch (e) { toast(e.message, 'bad'); return; }
    const s = etatCons();
    const r = await agir(() => api('POST', '/api/pieces', { consultation_id: s.cid, mime, nom: f.name, contenu, legende: $('#piece-legende').value }), 'Pièce jointe au dossier.');
    if (r) { closeModal(); s.dossier = await api('GET', '/api/dossiers/' + s.dossier.patient.id); render(); }
  }
});
