'use strict';
/* Recette complémentaire de la version 2.2 : encaissement suspendu pendant une demande d'annulation de passage,
   liste des demandes de l'administrateur, fiche du patient corrigée par un médecin. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');
const R = require('../serveur/regles');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, med, adm;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
let n = 0;
const fiche = extra => { n++; return { nom: 'fiche' + n, prenoms: 'awa', sexe: 'F', naissance: '1990-04-12', telephone: `07 33 00 00 ${String(n).padStart(2, '0')}`, ...extra }; };

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v22b-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('med', 'medecin', 'Médecine générale'); compte('adm', 'admin');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, med, adm] = await Promise.all(['accueil', 'caisse', 'med', 'adm'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Demande d’annulation : passage signalé, encaissement suspendu jusqu’à la décision, encaissable après un refus motivé', async () => {
  const pid = (await accueil.post('/api/patients', fiche())).data.id;
  const v = (await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: consultationMG() })).data;
  const d = await accueil.post('/api/suppressions', { objet: 'passage', id: v.id, motif: 'Passage ouvert pour le mauvais patient' });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.equal((await caisse.get('/api/etat')).data.passages.find(x => x.id === v.id).suppression_demandee, true, 'signalé à la caisse');
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0').all(v.id), payer = () => caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode: 'Espèces', montant: bons.reduce((s, b) => s + R.montants(b).net, 0) }] });
  const refus = await payer();
  assert.equal(refus.status, 409);
  assert.match(refus.data.erreur, /encaissement suspendu/);
  const liste = (await adm.get('/api/etat')).data.suppressions;
  assert.ok(liste.some(x => x.id === d.data.id && x.statut === 'en_attente' && /mauvais patient/.test(x.motif)), 'l’administrateur voit la demande et son motif');
  assert.equal((await accueil.get('/api/etat')).data.suppressions, undefined, 'la liste est réservée à l’administrateur');
  assert.equal((await adm.post(`/api/demandes/${d.data.id}/decision`, { accepte: false, reponse: 'Le patient est bien venu : encaissez normalement.' })).status, 200);
  assert.equal((await caisse.get('/api/etat')).data.passages.find(x => x.id === v.id).suppression_demandee, false);
  assert.equal((await payer()).status, 200, 'encaissable après le refus');
  const nt = (await accueil.get('/api/etat')).data.notifications.find(x => x.titre === 'Demande refusée');
  assert.ok(nt && nt.prioritaire === 1, 'le demandeur est prévenu du refus');
});

test('Fiche du patient : un médecin la corrige, la caisse ne le peut pas', async () => {
  const pid = (await accueil.post('/api/patients', fiche())).data.id;
  const corrige = { ...fiche({ nom: 'fichecorrigee', naissance: '2015-04-12' }) };
  assert.equal((await caisse.put('/api/patients/' + pid, corrige)).status, 403);
  const r = await med.put('/api/patients/' + pid, corrige);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const p = db.prepare('SELECT nom, naissance FROM patients WHERE id = ?').get(pid);
  assert.equal(p.naissance, '2015-04-12');
  assert.match(p.nom, /FICHECORRIGEE/i);
});
