'use strict';
/* Espace comptable (v2.1) : écritures SYSCOHADA générées depuis les opérations du logiciel. Synthèse, journal, grand livre,
   balance, plan de correspondance, export CSV pour le logiciel du comptable. */
const cptUI = () => (UI.cpt = UI.cpt || { sub: 'synthese', du: todayISO().slice(0, 8) + '01', au: todayISO(), journal: '', compte: '', cache: null, charge: false });
async function chargerCompta() {
  const c = cptUI();
  if (c.charge) return;
  c.charge = true;
  const q = `du=${c.du}&au=${c.au}`;
  try {
    const [j, b, p] = await Promise.all([api('GET', '/api/compta/journal?' + q), api('GET', '/api/compta/balance?' + q), api('GET', '/api/compta/plan')]);
    c.cache = { cle: `${c.du}|${c.au}`, j, b, p, erreur: null, le: new Date() };
  } catch (e) { c.cache = { cle: `${c.du}|${c.au}`, erreur: e.message || 'Chargement impossible.' }; }
  c.charge = false;
  render();
}
const cptPeriode = (du, au) => `du ${fmtDate(du)} au ${fmtDate(au)}`;
function cptPeriodes(c) {
  const t = todayISO(), d = new Date(t + 'T00:00:00Z'), y = d.getUTCFullYear(), m = d.getUTCMonth();
  const iso = x => x.toISOString().slice(0, 10), debutPrec = new Date(Date.UTC(y, m - 1, 1)), finPrec = new Date(Date.UTC(y, m, 0));
  const choix = [['Ce mois', t.slice(0, 8) + '01', t], ['Mois précédent', iso(debutPrec), iso(finPrec)], ['Cette année', `${y}-01-01`, t]];
  return `<div class="cpt-periode">${choix.map(([l, du, au]) => `<button type="button" class="btn btn-ghost btn-sm" data-action="cptPeriode" data-du="${du}" data-au="${au}" aria-pressed="${c.du === du && c.au === au}">${l}</button>`).join('')}
    <label class="f f-inline"><span>Du</span><input type="date" data-change="cptDu" value="${c.du}"></label><label class="f f-inline"><span>au</span><input type="date" data-change="cptAu" value="${c.au}"></label>
    <button type="button" class="btn btn-ghost btn-sm" data-action="cptActualiser" title="Recalculer les écritures avec les dernières opérations">Actualiser${c.cache && c.cache.le ? ` <small class="muted">(${String(c.cache.le.getHours()).padStart(2, '0')} h ${String(c.cache.le.getMinutes()).padStart(2, '0')})</small>` : ''}</button>
    <a class="btn btn-sm" href="/api/compta/export?du=${c.du}&amp;au=${c.au}" download>Exporter les écritures (CSV)</a></div>`;
}
function vCompta() {
  const c = cptUI(), k = c.cache;
  if (!c.charge && (!k || k.cle !== `${c.du}|${c.au}`)) chargerCompta();
  const subs = [['synthese', 'Synthèse'], ['journal', 'Journal'], ['grandlivre', 'Grand livre'], ['balance', 'Balance'], ['plan', 'Plan comptable']];
  const tete = `<div class="view-head"><div><h1>Comptabilité</h1><p class="lead">Écritures SYSCOHADA générées automatiquement depuis les opérations, ${cptPeriode(c.du, c.au)}.</p></div></div>
    <div class="seg" role="tablist">${subs.map(([s, l]) => `<button type="button" data-action="cptSub" data-sub="${s}" aria-pressed="${c.sub === s}">${l}</button>`).join('')}</div>${cptPeriodes(c)}`;
  if (!k || (k.cle !== `${c.du}|${c.au}` && !k.j)) return tete + '<p class="muted">Chargement…</p>';
  if (k.erreur) return tete + `<div class="notice bad">${esc(k.erreur)}</div>`;
  const corps = c.sub === 'journal' ? cptJournal(k) : c.sub === 'grandlivre' ? cptGrandLivre(k) : c.sub === 'balance' ? cptBalance(k) : c.sub === 'plan' ? cptPlan(k) : cptSynthese(k);
  return tete + corps;
}
function cptControles(j) {
  const x = j.controles, m = [];
  m.push(x.equilibre ? '<div class="notice ok">Toutes les écritures de la période sont équilibrées (total des débits égal au total des crédits).</div>'
    : `<div class="notice bad">Écritures déséquilibrées : ${x.desequilibrees.map(esc).join(', ')}. Signalez-les à l’administrateur.</div>`);
  if (x.receptions_sans_prix) m.push(`<div class="notice">${x.receptions_sans_prix} réception${x.receptions_sans_prix > 1 ? 's' : ''} de stock sans prix d’achat : non comptabilisée${x.receptions_sans_prix > 1 ? 's' : ''} en achats.</div>`);
  return m.join('');
}
function cptSynthese(k) {
  const b = k.b, classe = n => b.comptes.filter(x => x.compte.startsWith(n));
  return `${cptControles(k.j)}
    <div class="pil-kpis">
      ${GR.kpi({ lib: 'Produits (classe 7)', val: money(b.produits), sous: `${k.j.ecritures.filter(e => e.journal === 'VE').length} écriture${k.j.ecritures.filter(e => e.journal === 'VE').length > 1 ? 's' : ''} de vente` })}
      ${GR.kpi({ lib: 'Charges (classe 6)', val: money(b.charges), sous: 'achats, dépenses, salaires, pertes' })}
      ${GR.kpi({ lib: 'Résultat provisoire', val: money(b.resultat), sous: 'avant écritures d’inventaire', alerte: b.resultat < 0 })}
      ${GR.kpi({ lib: 'Créances sur les assureurs', val: money(b.creances_assureurs), sous: 'variation de la période (compte 4111)' })}
    </div>
    <div class="pil-grille">
      <div class="panel"><h2>Produits par compte</h2>${GR.barresH(classe('7').map(x => ({ l: `${x.compte} ${x.libelle}`, v: x.credit - x.debit })).filter(x => x.v > 0), { fmt: money, videTxt: 'Aucun produit sur la période.' })}</div>
      <div class="panel"><h2>Charges par compte</h2>${GR.barresH(classe('6').map(x => ({ l: `${x.compte} ${x.libelle}`, v: x.debit - x.credit })).filter(x => x.v > 0), { fmt: money, videTxt: 'Aucune charge sur la période.' })}</div>
    </div>
    <p class="hint">Le résultat provisoire n’intègre pas les écritures d’inventaire (variation de stock, amortissements, charges sociales patronales, provisions), qui restent du ressort du comptable.</p>`;
}
const cptMontant = v => (v ? money(v) : '');
function cptTableEcritures(liste) {
  return `<div class="table-wrap"><table class="cpt-table"><thead><tr><th>Date</th><th>Jnl</th><th>Pièce</th><th>Compte</th><th>Libellé</th><th>Tiers</th><th class="num">Débit</th><th class="num">Crédit</th></tr></thead>
    <tbody>${liste.map(e => e.lignes.map((l, i) => `<tr${i === 0 ? ' class="cpt-debut"' : ''}><td>${i === 0 ? fmtDate(e.date.slice(0, 10)) : ''}</td><td>${i === 0 ? esc(e.journal) : ''}</td><td>${i === 0 ? esc(e.piece) : ''}</td>
      <td><strong>${esc(l.compte)}</strong> <small class="muted">${esc(l.libelle_compte || '')}</small></td><td>${i === 0 ? esc(e.libelle) : ''}</td><td>${esc(l.tiers || '')}</td><td class="num">${cptMontant(l.debit)}</td><td class="num">${cptMontant(l.credit)}</td></tr>`).join('')).join('')}</tbody>
    <tfoot><tr><th colspan="6">Total</th><th class="num">${money(liste.reduce((s, e) => s + e.lignes.reduce((t, l) => t + l.debit, 0), 0))}</th><th class="num">${money(liste.reduce((s, e) => s + e.lignes.reduce((t, l) => t + l.credit, 0), 0))}</th></tr></tfoot></table></div>`;
}
function cptJournal(k) {
  const c = cptUI(), liste = c.journal ? k.j.ecritures.filter(e => e.journal === c.journal) : k.j.ecritures;
  return `${cptControles(k.j)}<div class="panel"><div class="panel-head"><h2>Journal${c.journal ? ' ' + esc(k.j.journaux[c.journal]) : ' général'} (${liste.length} écriture${liste.length > 1 ? 's' : ''})</h2>
      <div class="row-actions"><select data-change="cptJournalFiltre" aria-label="Journal"><option value="">Tous les journaux</option>${Object.entries(k.j.journaux).map(([code, l]) => `<option value="${code}"${c.journal === code ? ' selected' : ''}>${code}, ${esc(l)}</option>`).join('')}</select>
      ${liste.length ? '<button class="btn btn-ghost btn-sm" data-action="cptImprimerJournal">Imprimer</button>' : ''}</div></div>
    ${liste.length ? cptTableEcritures(liste) : '<p class="muted">Aucune écriture sur la période.</p>'}</div>`;
}
function cptGrandLivre(k) {
  const c = cptUI(), comptes = k.b.comptes;
  if (!comptes.length) return '<div class="panel"><p class="muted">Aucun mouvement sur la période.</p></div>';
  const choisi = comptes.some(x => x.compte === c.compte) ? c.compte : comptes[0].compte;
  let solde = 0;
  const mvts = [];
  for (const e of k.j.ecritures) for (const l of e.lignes) if (l.compte === choisi) { solde += l.debit - l.credit; mvts.push({ e, l, solde }); }
  const info = comptes.find(x => x.compte === choisi);
  return `<div class="panel"><div class="panel-head"><h2>Grand livre</h2><select data-change="cptCompte" aria-label="Compte">${comptes.map(x => `<option value="${x.compte}"${x.compte === choisi ? ' selected' : ''}>${esc(x.compte)} ${esc(x.libelle)}</option>`).join('')}</select></div>
    <div class="table-wrap"><table class="cpt-table"><thead><tr><th>Date</th><th>Jnl</th><th>Pièce</th><th>Libellé</th><th>Tiers</th><th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde</th></tr></thead>
      <tbody>${mvts.map(x => `<tr><td>${fmtDate(x.e.date.slice(0, 10))}</td><td>${esc(x.e.journal)}</td><td>${esc(x.e.piece)}</td><td>${esc(x.e.libelle)}</td><td>${esc(x.l.tiers || '')}</td><td class="num">${cptMontant(x.l.debit)}</td><td class="num">${cptMontant(x.l.credit)}</td><td class="num">${money(Math.abs(x.solde))} ${x.solde >= 0 ? 'D' : 'C'}</td></tr>`).join('')}</tbody>
      <tfoot><tr><th colspan="5">Total ${esc(info.compte)}</th><th class="num">${money(info.debit)}</th><th class="num">${money(info.credit)}</th><th class="num">${money(Math.abs(info.debit - info.credit))} ${info.debit >= info.credit ? 'D' : 'C'}</th></tr></tfoot></table></div></div>`;
}
function cptBalance(k) {
  const b = k.b;
  return `<div class="panel"><div class="panel-head"><h2>Balance des comptes</h2>${b.comptes.length ? '<button class="btn btn-ghost btn-sm" data-action="cptImprimerBalance">Imprimer</button>' : ''}</div>
    ${b.comptes.length ? `<div class="table-wrap"><table class="cpt-table"><thead><tr><th>Compte</th><th>Libellé</th><th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde débiteur</th><th class="num">Solde créditeur</th></tr></thead>
      <tbody>${b.comptes.map(x => `<tr><td><strong>${esc(x.compte)}</strong></td><td>${esc(x.libelle)}</td><td class="num">${cptMontant(x.debit)}</td><td class="num">${cptMontant(x.credit)}</td><td class="num">${cptMontant(x.solde_debiteur)}</td><td class="num">${cptMontant(x.solde_crediteur)}</td></tr>`).join('')}</tbody>
      <tfoot><tr><th colspan="2">Total</th><th class="num">${money(b.totaux.debit)}</th><th class="num">${money(b.totaux.credit)}</th><th class="num">${money(b.comptes.reduce((s, x) => s + x.solde_debiteur, 0))}</th><th class="num">${money(b.comptes.reduce((s, x) => s + x.solde_crediteur, 0))}</th></tr></tfoot></table></div>`
      : '<p class="muted">Aucun mouvement sur la période.</p>'}</div>`;
}
const CPT_SECTIONS = [
  ['services', 'Produits par service', { _autres: 'Autres actes', _produits: 'Pharmacie (produits vendus)' }],
  ['tresorerie', 'Trésorerie par mode de paiement', {}],
  ['depenses', 'Sorties de caisse par catégorie', { 60: '60 Achats', 61: '61 Transports', 62: '62 Services extérieurs A', 63: '63 Services extérieurs B', 64: '64 Impôts et taxes', 65: '65 Autres charges', 66: '66 Charges de personnel' }],
  ['tiers', 'Comptes de tiers', { assureurs: 'Assureurs (tiers payant)', avances: 'Avances des patients', avoirs: 'Avoirs à rembourser', fournisseurs: 'Fournisseurs' }],
  ['divers', 'Opérations diverses', { remises: 'Remises accordées', achats: 'Achats de médicaments', rejets: 'Rejets des assureurs', manquants: 'Manquants de caisse', excedents: 'Excédents de caisse', avances_salaire: 'Trésorerie des avances sur salaire' }],
  ['paie', 'Paie', { brut: 'Salaires bruts', CNPS: 'Retraite CNPS (part salariale)', CMU: 'CMU (part salariale)', ITS: 'Impôt sur salaires (ITS)', AVANCE: 'Avances sur salaire', autres: 'Autres retenues', net: 'Net à payer' }]
];
function cptPlan(k) {
  /* Les modifications sont gardées en brouillon dès la frappe. Pas de longueur maximale sur les numéros de compte : un collage ou une saisie prédictive
     sur un champ limité peut être tronqué par le navigateur ; le serveur contrôle le format (de 2 à 8 chiffres). */
  const P = k.p.plan, ok = peut('compta_parametrer'), off = ok ? '' : ' disabled', B = cptUI().brouillon || {};
  const val = (s, cle) => (B[s] && B[s][cle] !== undefined ? B[s][cle] : P[s][cle]);
  const enCours = Object.keys(B).some(s => s !== 'lib' && Object.keys(B[s] || {}).length) || (B.lib && (B.lib.compte || B.lib.texte));
  return `<div class="panel"><h2>Plan de correspondance</h2>
    <p class="muted">Chaque opération du logiciel est imputée sur le compte SYSCOHADA indiqué ci-dessous. Les comptes proposés sont à valider par votre expert-comptable ; une modification s’applique à toutes les écritures recalculées, et elle est tracée au journal.</p>
    <div class="cpt-plan">${CPT_SECTIONS.map(([s, titre, noms]) => `<fieldset class="cases"><legend>${titre}</legend>${Object.keys(P[s]).map(cle => `<label class="f f-inline"><span>${esc(noms[cle] || cle)}</span><input class="cpt-code" id="cpt-${s}-${String(cle).replace(/[^A-Za-z0-9_]/g, '_')}" data-input="cptCode" data-section="${s}" data-cle="${esc(cle)}" value="${esc(val(s, cle))}" inputmode="numeric" autocomplete="off"${off}><small class="muted">${esc(k.p.comptes[val(s, cle)] || '')}</small></label>`).join('')}</fieldset>`).join('')}</div>
    ${ok ? `<fieldset class="cases"><legend>Libellé d’un compte</legend><label class="f f-inline"><span>Compte</span><input id="cpt-lib-compte" data-input="cptLib" data-champ="compte" value="${esc((B.lib && B.lib.compte) || '')}" inputmode="numeric" autocomplete="off" placeholder="70611"></label><label class="f f-inline"><span>Libellé</span><input id="cpt-lib-texte" data-input="cptLib" data-champ="texte" value="${esc((B.lib && B.lib.texte) || '')}" maxlength="80" placeholder="Consultations de médecine générale"></label></fieldset>
      ${enCours ? '<div class="notice">Modifications non enregistrées.</div>' : ''}<div class="row-actions">${enCours ? '<button class="btn btn-ghost" data-action="cptAbandonnerPlan">Abandonner</button>' : ''}<button class="btn" data-action="cptEnregistrerPlan">Enregistrer le plan</button></div>` : '<p class="hint">Seuls le comptable et la direction modifient le plan.</p>'}</div>`;
}
function cptPiece(titre, corps, paysage) { const c = cptUI(); return pieceA4({ titre, numero: `${c.du} au ${c.au}`, sous: `Période ${cptPeriode(c.du, c.au)}`, corps, paysage }); }
Object.assign(ACTIONS, {
  cptSub: el => { cptUI().sub = el.dataset.sub; render(); },
  cptActualiser: () => { cptUI().cache = null; render(); },
  cptPeriode: el => { const c = cptUI(); c.du = el.dataset.du; c.au = el.dataset.au; c.cache = null; render(); },
  cptImprimerJournal: () => { const c = cptUI(), k = c.cache, liste = c.journal ? k.j.ecritures.filter(e => e.journal === c.journal) : k.j.ecritures; apercuA4('Journal', cptPiece(`Journal${c.journal ? ' ' + k.j.journaux[c.journal] : ' général'}`, cptTableEcritures(liste), true)); },
  cptImprimerBalance: () => apercuA4('Balance', cptPiece('Balance des comptes', cptBalance(cptUI().cache).replace(/<button[^>]*>Imprimer<\/button>/, ''), false)),
  cptEnregistrerPlan: async () => {
    const B = cptUI().brouillon || {}, d = {};
    for (const [s, v] of Object.entries(B)) if (s !== 'lib') d[s] = Object.fromEntries(Object.entries(v).map(([k, x]) => [k, String(x).trim()]));
    if (B.lib && B.lib.compte && B.lib.texte) d.libelles = { [B.lib.compte.trim()]: B.lib.texte.trim() };
    const r = await agir(() => api('PUT', '/api/compta/plan', d), 'Plan de correspondance enregistré : les écritures sont recalculées.');
    if (r) { const c = cptUI(); c.brouillon = null; c.cache = null; render(); }
  },
  cptAbandonnerPlan: () => { cptUI().brouillon = null; render(); }
});
Object.assign(INPUTS, {
  cptCode: el => { const c = cptUI(); c.brouillon = c.brouillon || {}; (c.brouillon[el.dataset.section] = c.brouillon[el.dataset.section] || {})[el.dataset.cle] = el.value; },
  cptLib: el => { const c = cptUI(); c.brouillon = c.brouillon || {}; (c.brouillon.lib = c.brouillon.lib || {})[el.dataset.champ] = el.value; }
});
Object.assign(CHANGES, {
  cptDu: el => { if (el.value) { const c = cptUI(); c.du = el.value; c.cache = null; render(); } },
  cptAu: el => { if (el.value) { const c = cptUI(); c.au = el.value; c.cache = null; render(); } },
  cptJournalFiltre: el => { cptUI().journal = el.value; render(); },
  cptCompte: el => { cptUI().compte = el.value; render(); }
});
ONGLETS.push({ id: 'compta', libelle: 'Comptabilité', icone: 'compta', visible: () => peut('compta_lire'), vue: vCompta });
