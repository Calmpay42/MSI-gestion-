'use strict';
/* Recette : reprise des données OphtaSuite, photos et documents du dossier, fiches conseils. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
let db, srv, base, dir, ophta, cardio, caisse, accueil;

function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    const type = r.headers.get('content-type') || '';
    return { status: r.status, type, data: type.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}),
    async login(login) { const r = await req('POST', '/api/connexion', { login, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, specialites) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, 'Dr ' + login, roles, A.hacher(MDP), new Date().toISOString(), specialites || null);
const n = table => db.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n;
const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);

/* Sauvegarde au format d'OphtaSuite (noms de champs du logiciel d'origine). */
const sauvegarde = {
  patients: [
    { id: 'pt_1', nom: 'Kouassi', prenom: 'Aya Marie-Josée', dateNaissance: '1991-04-12', sexe: 'F', telephone: '0708123456', adresse: 'Bingerville', antecedents: 'Myopie forte', suiviGlaucome: true, numeroSuivi: 'OPH-0001', dateCreation: '2025-05-02' },
    { id: 'pt_2', nom: 'Yao', prenom: 'Koffi', dateNaissance: '1960-02-01', sexe: 'Masculin', telephone: '0102030405', adresse: 'Cocody' }
  ],
  consultations: [
    { id: 'cs_1', patientId: 'pt_1', date: '2025-06-10', medecin: 'Dr Ophta', motif: 'Baisse de vision', atcdFamiliaux: 'Glaucome dans la famille', toOD: '24', toOG: '19', avODsc: '4/10', avOGsc: '9/10',
      segmentOD: 'Cornée transparente', fondOD: 'Excavation papillaire augmentée', diagnostic: 'Glaucome primitif à angle ouvert', conduite: 'Timolol', porteVerres: 'Oui', nextGlaucomeRdv: '2025-09-10' },
    { id: 'cs_2', patientId: 'pt_2', date: '2025-07-01', motif: 'Rougeur', diagnostic: 'Conjonctivite' },
    { id: 'cs_x', patientId: 'pt_inconnu', date: '2025-07-02', motif: 'Fiche orpheline' }
  ],
  ordonnancesMed: [{ id: 'rm_1', patientId: 'pt_1', date: '2025-06-10', medicaments: [{ nom: 'Timoptol', posologie: '1 goutte 2 fois/jour', duree: '3 mois', quantite: '1' }], prescripteur: 'Dr Ophta' }],
  ordonnancesLunettes: [{ id: 'rl_1', patientId: 'pt_1', date: '2025-06-10', od_loin_sph: '-2.00', od_loin_cyl: '-0.50', od_loin_axe: '90', og_loin_sph: '-1.75', od_pres_sph: '+1.00', typeVerre: 'Progressifs', options: ['Antireflet'] }],
  certificats: [{ id: 'ct_1', patientId: 'pt_2', date: '2025-07-01', jours: '3', dateDebut: '2025-07-01', dateReprise: '2025-07-04', motif: 'Conjonctivite' }],
  certificatsMedicaux: [{ id: 'cm_1', patientId: 'pt_1', date: '2025-06-10', objet: 'Aptitude sportive', constat: 'Examen normal', conclusion: 'Apte' }],
  interpretations: [
    { id: 'it_1', patientId: 'pt_1', date: '2025-06-10', examType: 'champ_visuel', cv_od: 'Déficit supéro-nasal', cv_conclusion: 'Aspect glaucomateux' },
    { id: 'it_2', patientId: 'pt_1', date: '2025-06-10', examType: 'pio_pachymetrie', pio_od_x: '24', commentaire: 'PIO élevée' }
  ],
  comptesRendusOp: [{ id: 'op_1', patientId: 'pt_1', date: '2025-08-01', type: 'Cataracte', oeil: 'OD', implant: '21 D', indication: 'Cataracte', deroulement: 'Sans complication' }],
  explorations: [{ id: 'ex_1', patientId: 'pt_1', date: '2025-06-10', examens: ['Champ Visuel Automatisé', 'OCT FNR et CCG'], renseignement: 'Suspicion de glaucome' }],
  bilansBiologiques: [{ id: 'bb_1', patientId: 'pt_2', date: '2025-07-01', examens: ['Nfs'], autresExamens: 'CRP' }],
  bulletinsRadio: [],
  bulletinsOphtalmo: [{ id: 'bo_1', patientId: 'pt_1', date: '2025-06-10', specialite: 'Cardiologie', renseignement: 'HTA découverte' }],
  photosDossier: [{ id: 'pd_1', patientId: 'pt_1', date: '2025-06-10', dataUrl: 'data:image/png;base64,' + PNG, motif: 'Rétinophotographie', oeil: 'OD' },
    { id: 'pd_2', patientId: 'pt_1', date: '2025-06-10', dataUrl: 'data:image/png;base64,QUJDREVG' }],
  fondOeilSchemas: [{ id: 'fo_1', patientId: 'pt_1', date: '2025-06-10', commentaireOD: 'Excavation 0,7', markersOD: [{ x: 1, y: 2 }] }],
  rdv: [{ id: 'rv_1', patientId: 'pt_1', date: demain, motif: 'Suivi glaucome', statut: 'Planifié' }, { id: 'rv_2', patientId: 'pt_1', date: '2024-01-01', motif: 'Ancien' }],
  medecins: [{ nom: 'Dr Ophta' }], stock: [{ nom: 'Timoptol' }], tarifsExamens: {}
};

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-reprise-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('ophta', 'medecin', 'Ophtalmologie'); compte('cardio', 'medecin', 'Cardiologie'); compte('caisse', 'caisse'); compte('accueil', 'accueil');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [ophta, cardio, caisse, accueil] = await Promise.all(['ophta', 'cardio', 'caisse', 'accueil'].map(l => client().login(l)));
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Reprise OphtaSuite : réservée aux médecins habilités, analyse avant import', async () => {
  assert.equal((await caisse.post('/api/reprise/ophtasuite/analyse', sauvegarde)).status, 403);
  assert.equal((await cardio.post('/api/reprise/ophtasuite/analyse', sauvegarde)).status, 403);
  assert.equal((await ophta.post('/api/reprise/ophtasuite/analyse', { nimporte: 'quoi' })).status, 400);
  const a = await ophta.post('/api/reprise/ophtasuite/analyse', sauvegarde);
  assert.equal(a.status, 200);
  assert.deepEqual(a.data.patients, { rapproches: 1, nouveaux: 1, deja_repris: 0 }, 'KOUASSI déjà connue de MSI');
  assert.equal(a.data.collections.consultations.a_reprendre, 3);
  assert.equal(a.data.rdv_passes, 1);
});

test('Reprise OphtaSuite : tout est repris fidèlement, sans bon de caisse, historique figé', async () => {
  const bons = n('bons'), patients = n('patients');
  const r = await ophta.post('/api/reprise/ophtasuite/import', sauvegarde);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const b = r.data;
  assert.equal(b.patients_crees, 1); assert.equal(b.patients_rapproches, 1);
  assert.equal(b.consultations, 2, 'la fiche orpheline est écartée');
  assert.equal(b.documents, 12); assert.equal(b.photos, 1); assert.equal(b.rdv, 1);
  assert.ok(b.ignores.some(x => x.includes('cs_x')) && b.ignores.some(x => x.includes('pd_2')), 'fiche orpheline et photo illisible signalées');
  assert.equal(n('bons'), bons, 'aucun bon de caisse créé');
  assert.equal(n('patients'), patients + 1);
  const kouassi = db.prepare("SELECT id FROM patients WHERE nom = 'KOUASSI' AND fusionne_dans IS NULL ORDER BY id").get().id;
  const d = (await ophta.get('/api/dossiers/' + kouassi)).data;
  const c = d.consultations.find(x => x.donnees.reprise === 'OphtaSuite');
  assert.equal(c.donnees.to.OD, '24'); assert.equal(c.donnees.av_loin_sc.OD, '4/10'); assert.equal(c.donnees.porte_verres, 'Oui');
  assert.equal(c.donnees.medecin_origine, 'Dr Ophta'); assert.ok(c.valide_le, 'consultation reprise validée');
  assert.throws(() => db.prepare('UPDATE consultations SET diagnostic = ? WHERE id = ?').run('x', c.id), /non modifiable/);
  const lun = d.documents.find(x => x.type === 'lunettes');
  assert.equal(lun.donnees.od.sphere, '-2.00'); assert.match(lun.donnees.remarques, /Vision de près/);
  assert.match(d.documents.find(x => x.donnees.champs && x.donnees.champs.texte && x.donnees.champs.texte.includes('pio_od_x')).donnees.champs.texte, /pio_od_x : 24/);
  assert.equal(d.documents.find(x => x.type === 'compte_rendu' && x.donnees.cle === 'champ_visuel').donnees.champs.cv_od, 'Déficit supéro-nasal');
  assert.equal(d.pieces.length, 1);
  const img = await ophta.get('/api/pieces/' + d.pieces[0].id);
  assert.equal(img.type, 'image/png'); assert.equal(img.data.toString('base64'), PNG);
  assert.equal((await caisse.get('/api/pieces/' + d.pieces[0].id)).status, 403, 'photo couverte par le secret médical');
  const rdv = (await accueil.get(`/api/rdv?du=${demain}&au=${demain}`)).data;
  assert.ok(rdv.some(x => x.motif === 'Suivi glaucome'), 'rendez-vous à venir repris');
});

test('Reprise OphtaSuite : relancer l’import ne crée aucun doublon', async () => {
  const avant = ['patients', 'consultations', 'documents', 'pieces', 'rdv'].map(n);
  const r = await ophta.post('/api/reprise/ophtasuite/import', sauvegarde);
  assert.equal(r.status, 200);
  assert.deepEqual([r.data.patients_crees, r.data.consultations, r.data.documents, r.data.photos, r.data.rdv], [0, 0, 0, 0, 0]);
  assert.deepEqual(['patients', 'consultations', 'documents', 'pieces', 'rdv'].map(n), avant);
  assert.equal((await ophta.post('/api/reprise/ophtasuite/analyse', sauvegarde)).data.collections.consultations.a_reprendre, 1, 'seule la fiche orpheline reste');
});

test('Photos et documents scannés : format contrôlé, habilitation, secret médical', async () => {
  const v = await accueil.post('/api/passages', { patient_id: db.prepare("SELECT id FROM patients WHERE nom = 'DIABATÉ'").get().id, type: 'urgence' });
  const c = await ophta.post('/api/consultations', { passage_id: v.data.id, specialite: 'Ophtalmologie' });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  const ok = await ophta.post('/api/pieces', { consultation_id: c.data.id, mime: 'image/png', nom: 'fond-oeil.png', contenu: PNG, legende: 'Rétinophotographie OD' });
  assert.equal(ok.status, 200);
  assert.equal((await ophta.post('/api/pieces', { consultation_id: c.data.id, mime: 'image/png', nom: 'x.png', contenu: Buffer.from('pas une image').toString('base64') })).status, 400);
  assert.equal((await ophta.post('/api/pieces', { consultation_id: c.data.id, mime: 'application/zip', nom: 'x.zip', contenu: PNG })).status, 400);
  assert.equal((await cardio.post('/api/pieces', { consultation_id: c.data.id, mime: 'image/png', nom: 'x.png', contenu: PNG })).status, 403);
  assert.throws(() => db.prepare('DELETE FROM pieces').run(), /interdite/);
  const f = await ophta.post('/api/documents', { type: 'conseils', consultation_id: c.data.id, donnees: { codes: ['general'] } });
  assert.equal(f.status, 200, JSON.stringify(f.data));
  const doc = (await ophta.get('/api/documents/' + f.data.id)).data;
  assert.ok(doc.donnees.fiches[0].items.length >= 5, 'texte de la fiche figé dans le document');
  assert.equal((await ophta.post('/api/documents', { type: 'conseils', consultation_id: c.data.id, donnees: { codes: ['inexistante'] } })).status, 400);
});
