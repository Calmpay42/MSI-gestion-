'use strict';
/* Recette de la version 1.8 : ressources humaines (personnel, planning des gardes et des consultations, paie, avances). */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, rh, dir1, raf, med, inf2;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, nom) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le) VALUES (?,?,?,?,0,?)')
  .run(login, nom || login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString()).lastInsertRowid;
const idDe = login => db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(login).id;
const jour = n => { const d = new Date(); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const periode = new Date().toISOString().slice(0, 7);
const fiche = extra => ({ nom: 'AGENT', prenoms: 'Test', sexe: 'F', fonction: 'Aide-soignant', contrat: 'CDI', embauche_le: '2025-01-06', salaire_base: 0, ...extra });
const notifs = async qui => (await qui.get('/api/etat')).data.notifications;

let adm;
test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v18-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  compte('rh', 'rh'); compte('dir1', 'direction'); compte('raf', 'raf'); compte('med', 'medecin', 'Dr TEST Medecin'); compte('inf', 'infirmier'); compte('inf2', 'infirmier');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [rh, dir1, raf, med, inf2] = await Promise.all(['rh', 'dir1', 'raf', 'med', 'inf2'].map(l => client().login(l)));
  compte('adm', 'admin'); adm = await client().login('adm');
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Personnel : matricule, contrôles, compte lié, modification tracée, archivage ; accès réservé', async () => {
  assert.equal((await med.post('/api/rh/employes', fiche())).status, 403);
  assert.equal((await med.get('/api/rh')).status, 403, 'le médecin n’accède pas aux RH');
  assert.equal((await raf.get('/api/rh')).status, 200, 'le RAF consulte les RH');
  const r = await rh.post('/api/rh/employes', fiche({ nom: 'YAO', prenoms: 'Serge', sexe: 'M', fonction: 'Infirmier', salaire_base: 220000, taux_garde: 12000, utilisateur_id: idDe('inf'), telephone: '0707070707' }));
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.match(r.data.matricule, /^EMP-\d{4}$/);
  assert.equal((await rh.post('/api/rh/employes', fiche({ contrat: 'CDD' }))).status, 400, 'CDD sans date de fin');
  assert.equal((await rh.post('/api/rh/employes', fiche({ fonction: 'Astronaute' }))).status, 400);
  assert.equal((await rh.post('/api/rh/employes', fiche({ utilisateur_id: idDe('inf') }))).status, 409, 'compte déjà lié');
  const e = (await rh.get('/api/rh')).data.employes.find(x => x.id === r.data.id);
  assert.equal(e.telephone, '07 07 07 07 07');
  assert.equal(e.compte, 'INF');
  assert.equal((await rh.put('/api/rh/employes/' + r.data.id, { ...fiche({ nom: 'YAO', prenoms: 'Serge', fonction: 'Infirmier', utilisateur_id: idDe('inf') }), salaire_base: 250000, taux_garde: 12000 })).status, 200);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Employé modifié' AND detail LIKE '%salaire_base%'").get(), 'changement de salaire tracé');
  const a = await rh.post('/api/rh/employes', fiche({ nom: 'PARTANT' }));
  assert.equal((await rh.post(`/api/rh/employes/${a.data.id}/archivage`, { motif: 'Fin de mission' })).status, 200);
  assert.equal((await rh.post(`/api/rh/employes/${a.data.id}/archivage`, { motif: 'Fin de mission' })).status, 409);
  assert.throws(() => db.prepare('DELETE FROM employes WHERE id = ?').run(a.data.id), /archivez/);
});

test('Planning : garde de nuit, chevauchements refusés, garde de 24 h, mon planning, notification, annulation, recopie', async () => {
  const e = (await rh.post('/api/rh/employes', fiche({ nom: 'KOUASSI', fonction: 'Infirmier', utilisateur_id: idDe('inf2') }))).data.id;
  const creneau = (j, type, debut, fin) => rh.post('/api/rh/planning', { employe_id: e, jour: j, type, debut, fin });
  const g = await creneau(jour(1), 'garde', '18:00', '08:00');
  assert.equal(g.status, 200, JSON.stringify(g.data));
  const c = await creneau(jour(2), 'consultation', '07:00', '09:00');
  assert.equal(c.status, 409, 'chevauche la fin de garde à 08:00');
  assert.match(c.data.erreur, /Chevauchement avec garde/);
  assert.equal((await creneau(jour(2), 'consultation', '08:00', '13:00')).status, 200, 'enchaînement bord à bord accepté');
  assert.equal((await creneau(jour(4), 'garde', '08:00', '08:00')).status, 200, 'garde de 24 heures');
  assert.equal((await creneau(jour(5), 'permanence', '07:00', '09:00')).status, 409);
  assert.equal((await creneau(jour(6), 'garde', '25:00', '08:00')).status, 400);
  assert.equal((await med.post('/api/rh/planning', { employe_id: e, jour: jour(6), type: 'garde', debut: '18:00', fin: '08:00' })).status, 403);
  const moi = (await inf2.get('/api/rh/mon-planning')).data;
  assert.equal(moi.lie, true);
  assert.equal(moi.creneaux.length, 3);
  assert.ok((await notifs(inf2)).some(n => /^Planning : garde le/.test(n.titre)), 'l’employé est prévenu de sa garde');
  assert.equal((await rh.post(`/api/rh/planning/${g.data.id}/annulation`)).status, 403, 'les RH demandent, l’administrateur annule');
  assert.equal((await adm.post(`/api/rh/planning/${g.data.id}/annulation`)).status, 200);
  assert.equal((await adm.post(`/api/rh/planning/${g.data.id}/annulation`)).status, 409);
  assert.equal((await inf2.get('/api/rh/mon-planning')).data.creneaux.length, 2);
  assert.throws(() => db.prepare('DELETE FROM planning WHERE id = ?').run(g.data.id), /annulez le créneau/);
  const lundi = (await rh.get('/api/rh')).data.lundi;
  const prec = new Date(lundi + 'T00:00:00Z'); prec.setUTCDate(prec.getUTCDate() - 6);
  assert.equal((await creneau(prec.toISOString().slice(0, 10), 'permanence', '08:00', '18:00')).status, 200);
  const rc = await rh.post('/api/rh/planning/recopie', { lundi });
  assert.equal(rc.status, 200, JSON.stringify(rc.data));
  assert.ok(rc.data.copies >= 1);
});

test('Paie : 300 000 de base, 3 gardes et une avance, ITS manuel, validation par la direction, bulletin figé, paiement', async () => {
  const e = (await rh.post('/api/rh/employes', fiche({ nom: 'BAMBA', prenoms: 'Paul', fonction: 'Médecin', salaire_base: 300000, taux_garde: 15000 }))).data.id;
  for (const d of ['05', '12', '19']) assert.equal((await rh.post('/api/rh/planning', { employe_id: e, jour: `${periode}-${d}`, type: 'garde', debut: '18:00', fin: '08:00' })).status, 200);
  assert.equal((await rh.post('/api/rh/avances', { employe_id: e, montant: 50000, motif: 'Frais de scolarité' })).status, 200);
  const p = await rh.post('/api/rh/paies/preparation', { periode });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const b = p.data.prepares.find(x => x.employe === 'BAMBA Paul');
  assert.ok(b, JSON.stringify(p.data));
  const lu = () => db.prepare('SELECT * FROM paies WHERE id = ?').get(b.id);
  const lignes = JSON.parse(lu().lignes);
  assert.deepEqual(lignes.map(l => [l.code, l.montant]), [['BASE', 300000], ['GARDES', 45000], ['CNPS', 21735], ['CMU', 500], ['AVANCE', 50000]]);
  assert.equal(lu().net, 272765);
  assert.equal(db.prepare('SELECT paie_id FROM avances_salaire WHERE employe_id = ?').get(e).paie_id, b.id, 'avance déduite et rattachée');
  assert.ok(!(await rh.post('/api/rh/paies/preparation', { periode })).data.prepares.some(x => x.id === b.id), 'pas de second bulletin pour le même mois');
  const sansIts = await dir1.post('/api/rh/paies/validation', { id: b.id });
  assert.equal(sansIts.status, 409, 'pas de validation d’un salarié sans ITS');
  assert.match(sansIts.data.erreur, /ITS non saisi pour BAMBA Paul/);
  const m = await raf.put(`/api/rh/paies/${b.id}/lignes`, { its: 12000 });
  assert.equal(m.status, 200, JSON.stringify(m.data));
  assert.equal(lu().net, 260765);
  assert.equal((await rh.post('/api/rh/paies/validation', { id: b.id })).status, 403, 'seule la direction valide');
  assert.equal((await raf.post(`/api/rh/paies/${b.id}/paiement`, { mode: 'Virement' })).status, 409, 'pas de paiement avant validation');
  assert.equal((await dir1.post('/api/rh/paies/validation', { id: b.id })).status, 200);
  assert.equal((await raf.put(`/api/rh/paies/${b.id}/lignes`, { lignes: [] })).status, 409, 'bulletin validé figé');
  assert.throws(() => db.prepare('UPDATE paies SET net = 1 WHERE id = ?').run(b.id), /ne se modifie plus/);
  assert.equal((await raf.post(`/api/rh/paies/${b.id}/paiement`, { mode: 'Virement', reference: 'VIR-2026-10' })).status, 200);
  assert.equal(lu().statut, 'paye');
  assert.equal((await raf.post(`/api/rh/paies/${b.id}/paiement`, { mode: 'Virement' })).status, 409);
  assert.equal((await adm.post(`/api/rh/paies/${b.id}/annulation`, { motif: 'Erreur' })).status, 409, 'un bulletin payé ne s’annule plus');
});

test('Annulation : avance libérée puis redéduite ; paie à valider et fin de CDD notifiées ; paramètres réservés à la direction', async () => {
  const e = (await rh.post('/api/rh/employes', fiche({ nom: 'TRAORE', salaire_base: 200000 }))).data.id;
  await rh.post('/api/rh/avances', { employe_id: e, montant: 30000 });
  const b = (await rh.post('/api/rh/paies/preparation', { periode, employe_id: e })).data.prepares[0];
  assert.ok((await notifs(dir1)).some(n => n.titre === 'Paie à valider'), 'direction prévenue');
  assert.equal((await rh.post(`/api/rh/paies/${b.id}/annulation`, { motif: 'Salaire de base à corriger' })).status, 403);
  assert.equal((await adm.post(`/api/rh/paies/${b.id}/annulation`, { motif: 'Salaire de base à corriger' })).status, 200);
  assert.equal(db.prepare('SELECT paie_id FROM avances_salaire WHERE employe_id = ?').get(e).paie_id, null, 'avance libérée');
  const b2 = (await rh.post('/api/rh/paies/preparation', { periode, employe_id: e })).data.prepares[0];
  assert.ok(b2 && b2.id !== b.id);
  assert.ok(JSON.parse(db.prepare('SELECT lignes FROM paies WHERE id = ?').get(b2.id).lignes).some(l => l.code === 'AVANCE'), 'avance redéduite');
  await rh.post('/api/rh/employes', fiche({ nom: 'TEMPORAIRE', contrat: 'CDD', fin_contrat: jour(10) }));
  assert.ok((await notifs(rh)).some(n => n.titre === 'Fin de CDD dans moins de 30 jours' && /TEMPORAIRE/.test(n.message)));
  assert.equal((await rh.put('/api/rh/parametres', { taux_cnps: '6,3', plafond_cnps: 1647315, cmu: 500 })).status, 403);
  assert.equal((await dir1.put('/api/rh/parametres', { taux_cnps: '45', plafond_cnps: 1647315, cmu: 500 })).status, 400);
  assert.equal((await dir1.put('/api/rh/parametres', { taux_cnps: '6,3', plafond_cnps: 1647315, cmu: 500, cnps_employeur: '1234567' })).status, 200);
  assert.equal((await rh.get('/api/rh')).data.parametres.cnps_employeur, '1234567');
});

test('Reprise des comptes existants en employés', async () => {
  const r = await rh.post('/api/rh/reprise-comptes');
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.crees >= 1);
  assert.equal(db.prepare('SELECT fonction FROM employes WHERE utilisateur_id = ?').get(idDe('med')).fonction, 'Médecin');
  assert.equal((await rh.post('/api/rh/reprise-comptes')).data.crees, 0, 'rien à reprendre une seconde fois');
});

test('Garde-fou ITS : zéro saisi accepté, vacataire validé sans ITS, lignes libres conservées', async () => {
  const cdi = (await rh.post('/api/rh/employes', fiche({ nom: 'KONE', prenoms: 'Awa', salaire_base: 70000 }))).data.id;
  const vac = (await rh.post('/api/rh/employes', fiche({ nom: 'DIALLO', prenoms: 'Moussa', fonction: 'Médecin', contrat: 'Vacataire', taux_vacation: 25000 }))).data.id;
  assert.equal((await rh.post('/api/rh/planning', { employe_id: vac, jour: `${periode}-08`, type: 'consultation', debut: '09:00', fin: '13:00' })).status, 200);
  const p = (await rh.post('/api/rh/paies/preparation', { periode })).data.prepares;
  const bc = p.find(x => x.employe === 'KONE Awa'), bv = p.find(x => x.employe === 'DIALLO Moussa');
  assert.ok(bc && bv, JSON.stringify(p));
  assert.equal((await rh.put(`/api/rh/paies/${bc.id}/lignes`, { lignes: [{ type: 'gain', libelle: 'Prime de transport', montant: 25000 }] })).status, 200);
  assert.equal((await rh.put(`/api/rh/paies/${bc.id}/lignes`, { its: 0 })).status, 200);
  const l = JSON.parse(db.prepare('SELECT lignes FROM paies WHERE id = ?').get(bc.id).lignes);
  assert.ok(l.some(x => x.code === 'MANUEL' && x.montant === 25000), 'la prime saisie avant l’ITS est conservée');
  assert.ok(l.some(x => x.code === 'ITS' && x.montant === 0), 'ITS à zéro, explicite');
  assert.equal((await rh.put(`/api/rh/paies/${bc.id}/lignes`, { its: -5 })).status, 400);
  assert.equal((await dir1.post('/api/rh/paies/validation', { id: bc.id })).status, 200, 'ITS à zéro accepté');
  assert.equal((await dir1.post('/api/rh/paies/validation', { id: bv.id })).status, 200, 'vacataire : pas d’ITS exigé');
  const etat = (await rh.get('/api/rh?periode=' + periode)).data.paies.find(x => x.id === bc.id);
  assert.equal(etat.contrat, 'CDI');
});

test('Cotisation retraite recalculée : une prime saisie après la préparation entre dans l’assiette, une indemnité hors cotisations non', async () => {
  const e = (await rh.post('/api/rh/employes', fiche({ nom: 'TRAORE', prenoms: 'Ali', salaire_base: 400000 }))).data.id;
  assert.ok(e);
  const b = (await rh.post('/api/rh/paies/preparation', { periode, employe_id: e })).data.prepares[0];
  const cnps = () => JSON.parse(db.prepare('SELECT lignes FROM paies WHERE id = ?').get(b.id).lignes).find(l => l.code === 'CNPS').montant;
  assert.equal(cnps(), 25200, '6,3 % de 400 000');
  const r = await raf.put(`/api/rh/paies/${b.id}/lignes`, { its: 30000, lignes: [{ type: 'gain', libelle: 'Prime de rendement', montant: 20000 }, { type: 'gain', libelle: 'Indemnité de transport', montant: 25000, non_soumis: true }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(cnps(), 26460, '6,3 % de 420 000 : la prime est soumise, le transport ne l’est pas');
  assert.equal(r.data.net, 445000 - 26460 - 500 - 30000);
  assert.equal((await raf.put(`/api/rh/paies/${b.id}/lignes`, { lignes: [] })).status, 200);
  assert.equal(cnps(), 25200, 'retour à l’assiette de départ quand la prime est retirée');
});
